﻿namespace Soporte.HerdezV2.Validates.BI
{
    public class ValidateShared : Connect
    {
        public string RutaReproceso(int cia, string serie, long folio)
        {
            string CIA = "";
            switch (cia)
            {
                case 92:
                    CIA = /*this.RutaCia92 +*/ "0920";
                    break;
                case 1:
                    CIA = /*this.RutaCia1 +*/ "0010";
                    break;
                case 60:
                    CIA = /*this.RutaCia60 +*/ "0600";
                    break;
                case 77:
                    CIA = /*this.RutaCia77 +*/ "0770";
                    break;
                case 43:
                    CIA = /*this.RutaCia77 +*/ "0430";
                    break;
                case 102:
                    CIA = /*this.RutaCia77 +*/ "1020";
                    break;
                case 95:
                    CIA = /*this.RutaCia77 +*/ "0950";
                    break;
            }
            return string.Format("{0}{1}{2}.TXT", CIA, serie, folio);
        }
    }
}
