﻿namespace Soporte.HerdezV2.Repositories
{
    using System.Collections.Generic;
    using Models.SP;


    public interface IDetalleRepository
    {
        IEnumerable<DashboardPrincipal> DetallesRep { get; }
    }
}
