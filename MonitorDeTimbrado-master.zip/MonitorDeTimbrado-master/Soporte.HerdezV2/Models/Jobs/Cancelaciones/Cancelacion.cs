﻿namespace Soporte.HerdezV2.Models.Jobs.Cancelaciones
{
    using System;
    using System.Text.RegularExpressions;

    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class Cancelacion
    {
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public long IdSolicitud { get; set; }
        
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string RfcEmisor { get; set; }
        
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string RfcReceptor { get; set; }
        
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Documento { get; set; }
        
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public Guid UuidCancela { get; set; }
        
        [System.Xml.Serialization.XmlIgnore]
        public bool EsDocumentoLocalizado { get; set; }

        [System.Xml.Serialization.XmlIgnore]
        public string EstatusCancelacion { get; set; }

        public Cancelacion() { }

        public string GetLineaLayout()
        {
            return string.Format(
                "CABCAN|{0}|{1}|{2}|{3}|{4}{5}",
                Regex.Replace(this.Documento, "[^a-zA-Z]", string.Empty),
                Regex.Replace(this.Documento, "[^0-9]", string.Empty),
                this.RfcEmisor,
                this.RfcReceptor,
                this.UuidCancela.ToString().ToUpper(),
                Environment.NewLine
                );
        }
    }
}
