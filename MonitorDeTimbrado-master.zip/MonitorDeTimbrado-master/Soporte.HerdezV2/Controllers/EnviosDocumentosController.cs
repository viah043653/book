﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Soporte.HerdezV2.Validates.BI;

namespace Soporte.HerdezV2.Controllers
{
    [Authorize]
    [Produces("application/json")]
    [Route("api/EnviosDocumentos")]    
    public class EnviosDocumentosController : Controller
    {
        // POST api/values
        [Route("~/api/PostEntxFol")]
        [HttpPost]
        public ValidateEnviosDocumentos.Respuesta PostEntxFol(Int32 cia, string serie, Int32 folio)
        {
            ValidateEnviosDocumentos validateentrgaxfolio = new ValidateEnviosDocumentos();
            return validateentrgaxfolio.GetEntXFolio(cia, serie, folio);
        }
    }
}