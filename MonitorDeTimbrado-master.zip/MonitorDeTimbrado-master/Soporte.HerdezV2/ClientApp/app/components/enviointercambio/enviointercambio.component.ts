﻿import { Component, ViewChild, ViewContainerRef, OnInit, OnDestroy } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SwalComponent, SwalDirective } from '@toverux/ngx-sweetalert2';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { EnvioIntercambioService } from './enviointercambio.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/takeUntil';

import swal from 'sweetalert2';

@Component({
    providers: [EnvioIntercambioService, SharedService],
    selector: 'enviointercambio',
    templateUrl: './enviointercambio.component.html',
    styleUrls: ['./enviointercambio.style.css']
})

export class EnvioIntercambioComponent implements OnInit, OnDestroy {

    private VIEW_ID: number = 6;    

    files: any[] = [];//FileList;
    ShowTable: boolean = true;
    isActionButtonsVisible: boolean = false;
    ShowSpinnerTable: boolean = true;
    isSearchCleanVisible: boolean = false;

    displayedColumns= ['isChecked', 'emisor', 'serie', 'folio', 'estatus', 'fechaProceso'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    displayedColumnsArchivos = ['no', 'archivo', 'fechaModificacion', 'accion'];
    dataSourceArchivos = new MatTableDataSource<any>();

    filterValue: string = '';

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;
    @ViewChild('observacionesSwal') private observacionesSwal: SwalComponent;

    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, public _enviointercambioservice: EnvioIntercambioService, public _sharedService: SharedService, private spinnerService: Ng4LoadingSpinnerService, public dialog: MatDialog, public localstorageservice: LocalStorageService) {
        this.ShowTable = true;
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() {
        this.getAllFiles();
        Observable.interval(2000 * 60).takeUntil(this.onDestroy$).subscribe(x => {
            this.getAllFiles();
        });
    }
        
    getFiles(event: any) {
        let cias: string[] = ['0600', '0770', '0010', '0920', '0430', '1020'];
        let errorFiles: any[] = [];

        for (let file of event.target.files) {
            if (cias.indexOf(file.name.substring(0, 4)) != -1)
                this.files.push({ name: file.name, file: file });
            else
                errorFiles.push({ nombreArchivo: file.name, mensaje: 'Formato incorrecto en nombre', claseError: 'fa fa-exclamation bg-yellow' });
        }

        if (this.files.length > 0) {
            this.ShowTable = false;

            this.dataSourceArchivos = new MatTableDataSource(this.files);
            this.dataSourceArchivos.paginator = this.paginator;
            this.dataSourceArchivos.sort = this.sort;
        }

        if (errorFiles.length > 0) {
            var dataDetails = { tipoModal: 'errorFolios', data: { titulo: 'Se ignoraron ' + errorFiles.length + ' archivo(s) con formato incorrecto', foliosError: errorFiles } };

            this.dialog.open(DialogTimeLineComponent, {
                width: '50%',
                height: 'auto',
                data: dataDetails,
                panelClass: 'custom-dialog-container2'
            });
        }
    }

    removeFile(file: any) {
        this.files.splice(this.files.indexOf(file), 1);

        if (this.files.length == 0) {
            this.toastr.info('Se removieron todos los documentos cargados para enviar', 'Sin documentos por enviar');
            this.regresar();
        }
        else {
            this.dataSourceArchivos = new MatTableDataSource(this.files);
            this.dataSourceArchivos.paginator = this.paginator;
            this.dataSourceArchivos.sort = this.sort;
        }
    }

    sendFiles(observaciones: string) {
        if (observaciones.trim() == '') {
            this.toastr.error('Los motivos de reprocesamiento son obligatorios.', 'Error');

            let element: HTMLElement = document.getElementById('btnSend') as HTMLElement;
            element.click();
        }
        else {

            this.spinnerService.show();

            let usuario = this.localstorageservice.GetAuthorizationUser();
            this._enviointercambioservice.PostIntercambio(this.files, observaciones, usuario.toString()).
                subscribe(
                (data) => {
                    debugger
                    if (data.estatus == 'OK') {
                        let procesados: any[] = [];
                        
                        for (let procesado of data.resultados.procesados)
                            procesados.push({ nombreArchivo: procesado, mensaje: 'Archivo procesado, favor de esperar de 5 a 10 minutos para visualizar la respuesta en Seguimiento Entregas', claseError: 'fa fa-check-square-o bg-green' })

                        for (let error of data.resultados.errores)
                            procesados.push({ nombreArchivo: error.archivo, mensaje: error.error, claseError: 'fa fa-bug bg-red' })
                        
                        var dataDetails = { tipoModal: 'errorFolios', data: { titulo: 'Se procesaron ' + procesados.length + ' documentos', foliosError: procesados } };

                        this.dialog.open(DialogTimeLineComponent, {
                            width: '570%',
                            height: 'auto',
                            data: dataDetails,
                            panelClass: 'custom-dialog-container2'
                        });

                        this.regresar();
                    }
                    else
                        this.toastr.error('data.mensaje', 'Error');
                },
                response => {
                    this.files = [];
                    this.spinnerService.hide();
                    this._sharedService.catchHttpResponseError(response);
                },
                () => {
                    this.files = [];
                    this.spinnerService.hide();
                });
        }
    }

    detalleSeguimiento(bitacora: any) {
        let desgloze: any[] = [];
        for (let historico of bitacora.historicoDesgloze)
            desgloze.push({ proceso: historico.proceso, tipoLinea: 1, usuario: historico.usuario, mensaje: historico.observaciones, fechaProceso: historico.fechaProceso, claseError: 'fa fa-cloud-upload bg-blue' })

        let _mensaje = bitacora.mensaje == null ? '' : bitacora.mensaje;

        debugger

        desgloze.push({ proceso: 'Respuesta del PAC', tipoLinea: 2, usuario: bitacora.estatus, mensaje: _mensaje, fechaProceso: bitacora.fechaProceso, claseError: bitacora.estatus.includes('Error') ? 'fa fa-bug bg-red' : bitacora.estatus.includes('Timbrado') ? 'fa fa-check bg-green' : 'fa fa-exclamation-triangle bg-yellow' });
        
        var dataDetails = { tipoModal: 'detalleBitacora', data: { titulo: 'Linea de tiempo de reprocesos ordenada descendentemente', foliosError: this._sharedService.orderDescendingByDate(desgloze, "fechaProceso") } };

        this.dialog.open(DialogTimeLineComponent, {
            width: '570%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }

    regresar() {
        this.files = [];
        this.ShowTable = true;
        this.getAllFiles();
    }

    getAllFiles() {
        this.ShowSpinnerTable = true;
        this.isActionButtonsVisible = false;

        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);

        let procesos: string = "CargaManual";
        this._enviointercambioservice.PostBitacora(procesos).
            subscribe(
            (data) => {
                this.dataSource = new MatTableDataSource(this._sharedService.orderDescendingByDate(data, "fechaProceso"));
                this.dataSource.paginator = this.paginator;
                this.dataSource.sort = this.sort;
                this.selectionCheckBox = new SelectionModel<any>(true, []);

                debugger
                this.dataSource.sortingDataAccessor = (item, property) => {
                    debugger
                    switch (property) {
                        case 'fromDate': return new Date(item.fromDate);
                        default: return item[property];
                    }
                };
            },
            response => {
                this.ShowSpinnerTable = false;
                this._sharedService.catchHttpResponseError(response);
            },
            () => {
                this.ShowSpinnerTable = false;
            });
    }

    descargarCsv() {
        this.spinnerService.show();
        var datosTablaResumen = [];

        datosTablaResumen.push({
            "emisor": "Emisor",
            "serie": "Serie",
            "folio": "Folio",
            "estatus": "Estatus",
            "proceso": "Proceso",
            "fechaProcesamiento": "Fecha Procesamiento",
            "usuario": "Usuario",
            "motivoRetransmision": "Motivo De Retransmisión"
        });


        for (let doc of this.selectionCheckBox.selected) {
            var detalle = '';

            for (let h of doc.historicoDesgloze) {
                datosTablaResumen.push(
                    {
                        "emisor": doc.emisor,
                        "serie": doc.serie,
                        "folio": doc.folio,
                        "estatus": doc.estatus,
                        "proceso": h.proceso,
                        "fechaProcesamiento": h.fechaProceso,
                        "usuario": h.usuario,
                        "motivoRetransmision": h.observaciones
                    }
                );
            }
        }

        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();
    }

    //applyFilter(filterValue: string) {
    //    filterValue = filterValue.trim();
    //    filterValue = filterValue.toLowerCase();
    //    this.dataSource.filter = filterValue;

    //    this.selectionCheckBox = new SelectionModel<any>(true, []);
    //    this.isActionButtonsVisible = false;
    //}

    applyFilter(clearData: boolean/*filterValue: string*/) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}