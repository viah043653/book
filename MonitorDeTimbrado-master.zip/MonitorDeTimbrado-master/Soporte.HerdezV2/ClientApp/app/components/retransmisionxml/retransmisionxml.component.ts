﻿import { Component, ViewChild, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { EnvioIntercambioService } from '../enviointercambio/enviointercambio.service'
import { RetransmisionXmlService } from './retransmisionxml.service';
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/takeUntil';

@Component({
    providers: [SharedService, EnvioIntercambioService, RetransmisionXmlService],
    selector: 'retransmisionxmlcomponent',
    templateUrl: './retransmisionxml.component.html',
    styleUrls: ['./retransmisionxml.style.css']
})

export class RetransmisionXmlComponent implements OnInit, OnDestroy {

    private VIEW_ID: number = 8;

    ShowTable: boolean = true;
    ShowSpinnerTable: boolean = true;
    isSearchCleanVisible: boolean = false;
    ShowCargaDeExcel: boolean = false;

    files: any[] = [];//FileList;

    isActionButtonsVisible: boolean = false;

    displayedColumns = ['isChecked', 'emisor', 'serie', 'folio', 'estatus', 'fechaAlta'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);
    filterValue: string = '';

    displayedColumnsArchivos = ['no', 'archivo', 'fechaModificacion', 'accion'];
    dataSourceArchivos = new MatTableDataSource<any>();

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    clientes: any[] = [{ nombre: 'Soriana, S.A. de C.V.', numero: 1 }];
    _clienteNumber: number;
    _clienteText: string = '';

    switchCargaExcel: boolean = false;

    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService, public sharedservice: SharedService, public localstorageservice: LocalStorageService, public dialog: MatDialog, public enviointercambioservice: EnvioIntercambioService, public retransmisionxmlservice: RetransmisionXmlService) {
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() {
        this.getRetransmisionList();
        Observable.interval(2000 * 60).takeUntil(this.onDestroy$).subscribe(x => {
            this.getRetransmisionList();
        });
    }

    setCliente(cliente: any) {
        debugger
        this._clienteNumber = cliente.numero;
        this._clienteText = cliente.nombre;

        this.ShowCargaDeExcel = this._clienteNumber == 1;
    }

    descargarCsv() {
        this.spinnerService.show();
        var datosTablaResumen = [];

        datosTablaResumen.push({
            "emisor": "Emisor",
            "receptor": "Receptor",
            "serie": "Serie",
            "folio": "Folio",
            "estatus": "Estatus",
            "proceso": "Proceso",
            "fechaProcesamiento": "Fecha Procesamiento",
            "usuario": "Usuario",
            "motivoRetransmision": "Motivo De Retransmisión"
        });

        for (let doc of this.selectionCheckBox.selected) {
            var detalle = '';

            for (let h of doc.historicoDesgloze) {
                datosTablaResumen.push(
                    {
                        "emisor": doc.emisor,
                        "receptor": doc.receptor,
                        "serie": doc.serie,
                        "folio": doc.folio,
                        "estatus": doc.estatus,
                        "proceso": h.proceso,
                        "fechaProcesamiento": h.fechaProceso,
                        "usuario": h.usuario,
                        "motivoRetransmision": h.observaciones
                    }
                );
            }
        }

        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();
    }

    sendFiles(observaciones: string) {
        debugger
        if (observaciones.trim() == '') {
            this.toastr.error('Los motivos de retransmisión son obligatorios.', 'Error');

            let element: HTMLElement = document.getElementById('btnSend') as HTMLElement;
            element.click();
        }
        else {

            this.spinnerService.show();

            let usuario = this.localstorageservice.GetAuthorizationUser();
            this.retransmisionxmlservice.PostRetransmision(this.files, observaciones, usuario.toString(), this.switchCargaExcel).
                subscribe(
                    (data) => {
                        debugger

                        let procesados: any[] = [];

                        for (let p of data) {
                            let faClass = 'fa fa-bug bg-red';

                            if (p.estatus == "ACCEPTED")
                                faClass = 'fa fa-check-square-o bg-green';

                            procesados.push({ nombreArchivo: p.documento, mensaje: p.mensaje, claseError: faClass });
                        }

                        var dataDetails = { tipoModal: 'errorFolios', data: { titulo: 'Se realizo la retransmisión de ' + procesados.length + ' documento(s)', foliosError: procesados } };

                        this.dialog.open(DialogTimeLineComponent, {
                            width: '570%',
                            height: 'auto',
                            data: dataDetails,
                            panelClass: 'custom-dialog-container2'
                        });

                        this.regresar();
                    },
                    response => {
                        this.files = [];
                        this.spinnerService.hide();
                        this.sharedservice.catchHttpResponseError(response);
                    },
                    () => {
                        this.files = [];
                        this.spinnerService.hide();
                    });
        }
    }

    detalleSeguimiento(bitacora: any) {
        let desgloze: any[] = [];
        debugger
        for (let historico of bitacora.historico)
            desgloze.push({ proceso: historico.estatus , tipoLinea: 1, usuario: historico.nombreUsuario, mensaje: historico.observaciones, respuesta: historico.error, fechaProceso: historico.fechaAlta, claseError: historico.estatus == 'REJECT' ? 'fa fa-bug bg-red' : historico.estatus == 'SEND' ? 'fa fa-paper-plane-o bg-blue' : 'fa fa-thumbs-o-up bg-green' });

        let _mensaje = bitacora.mensaje == null ? '' : bitacora.mensaje;
        let _contenido = bitacora.contenido == null ? '' : bitacora.contenido;

        var dataDetails = { tipoModal: 'detalleRetransmision', data: { titulo: 'Linea de tiempo de retransmisiones ordenada descendente', foliosError: this.sharedservice.orderDescendingByDate(desgloze, "fechaProceso") } };

        this.dialog.open(DialogTimeLineComponent, {
            width: '570%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }

    getRetransmisionList() {
        this.ShowSpinnerTable = true;
        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);

        debugger
        let procesos: string = "RetransmisiónXml";
        this.retransmisionxmlservice.GetRetransmisionXmlHistorico().//.enviointercambioservice.PostBitacora(procesos).
            subscribe(
            (data) => {
                debugger
                this.dataSource = new MatTableDataSource(data);
                this.dataSource.paginator = this.paginator;
                this.dataSource.sort = this.sort
                this.selectionCheckBox = new SelectionModel<any>(true, []);
            },
            response => {
                this.ShowSpinnerTable = false;
                this.sharedservice.catchHttpResponseError(response);
            },
            () => {
                this.ShowSpinnerTable = false;
            });
    }
    
    getFiles(event: any) {
        debugger

        var excelCarga = 0, otrasExtensiones = 0;
        for (let file of event.target.files) {
            if (file.name.toUpperCase().includes('.CSV')) excelCarga++;
            if (!file.name.toUpperCase().includes('.XML') && !file.name.toUpperCase().includes('.CSV')) otrasExtensiones++;

            this.files.push({ name: file.name, file: file });
        }

        if (this.switchCargaExcel && (excelCarga == 0 || excelCarga > 1)) {
            this.files = [];
            this.toastr.error('Se debe adjuntar csv', 'Error');
        }
        else if (!this.switchCargaExcel && (excelCarga > 0 || otrasExtensiones > 0)) {
            this.files = [];
            this.toastr.error('Solamente está permitida la carga de archivos Xml', 'Error');
        }
        else if (otrasExtensiones > 0) {
            this.files = [];
            this.toastr.error('Solamente está permitida la carga de archivos Xml y csv', 'Error');
        }
        else if (this._clienteNumber == undefined || this._clienteNumber <= 0) {
            this.files = [];
            this.toastr.error('El cliente es un dato obligatorio', 'Error');
        }
        else {

            if (this.files.length > 0) {
                this.ShowTable = false;

                this.dataSourceArchivos = new MatTableDataSource(this.files);
                this.dataSourceArchivos.paginator = this.paginator;
                this.dataSourceArchivos.sort = this.sort;
            }
            else {
                this.toastr.error('No se cargo ningún documento', 'Error');
            }
        }
    }

    removeFile(file: any) {
        this.files.splice(this.files.indexOf(file), 1);

        if (this.files.length == 0) {
            this.toastr.info('Se removieron todos los documentos cargados para retransmitir', 'Sin documentos por retransmitir');
            this.regresar();
        }
        else {
            this.dataSourceArchivos = new MatTableDataSource(this.files);
            this.dataSourceArchivos.paginator = this.paginator;
            this.dataSourceArchivos.sort = this.sort;
        }
    }

    regresar() {
        this.files = [];
        this.ShowTable = true;
        this.getRetransmisionList();
    }

    applyFilter(clearData: boolean) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}