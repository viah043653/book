﻿namespace MT.Sftp.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Credentials
    {
        public string hostName { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
        public string sshHostKeyFingerprint { get; set; }

        public Credentials(string _hostName, string _userName, string _password, string _sshHostKeyFingerprint)
        {
            this.hostName = _hostName;
            this.userName = _userName;
            this.password = _password;
            this.sshHostKeyFingerprint = _sshHostKeyFingerprint;
        }
    }
}