﻿import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog } from '@angular/material';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { PdfService } from './pdf.service';
import { LocalStorageService } from '../shared/localstorage.service';

@Component({
    providers: [PdfService],
    selector: 'pdf-selector',
    templateUrl: './pdf.component.html',
    styleUrls: ['./pdf.typography.style.css', './pdf.button.style.css', './pdf.googleicons.style.css', './pdf.style.css']
})

export class PdfComponent implements OnInit {

    private VIEW_ID: number = 6;

    constructor(public _pdfservice: PdfService, public localstorageservice: LocalStorageService, public dialog: MatDialog) {
    }

    ngOnInit() { }

    mostrarXmlToPdf() {
        var dataDetails = { tipoModal: 'xlmToPdf' };

        this.dialog.open(DialogTimeLineComponent, {
            width: '70%',
            height: 'auto',
            data: dataDetails
            //panelClass: 'custom-dialog-container1'
            //panelClass: 'custom-dialog-container2'
        });
        
    }
}