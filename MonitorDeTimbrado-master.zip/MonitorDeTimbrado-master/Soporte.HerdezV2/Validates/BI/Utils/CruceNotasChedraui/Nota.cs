﻿using System;
using System.Globalization;

namespace Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui
{
    public class Nota : Folio
    {
        public string TipoDoc { get; set; }
        public string FolioFic { get; set; }
        public string RespuestaPAC { get; set; }
        public string NotaCancela { get; set; }
        public decimal NotaCancelaImporte { get; set; }
        public DateTime? FechaRespuestaPAC { get; set; }

        public Nota(dynamic ncData)
        {
            string[] respuesta = string.IsNullOrEmpty(ncData.RespuestaPAC) ? new string[2] { "", "" } : ncData.RespuestaPAC.Split('@');
            this.TipoDoc = ncData.SerieNC_CV;
            this.FolioFic = "";
            //this.Serie = ncData.SerieNC;
            this.Serie = ncData.SERNC;
            this.Numero = ncData.C25IBO;
            this.Importe = ncData.C25IMP;
            this.FechaProceso = ncData.FechaProceso;
            this.RespuestaPAC = respuesta[0];

            if (!string.IsNullOrEmpty(respuesta[1]))
                this.FechaRespuestaPAC = DateTime.ParseExact(respuesta[1], "dd/MM/yyyy", CultureInfo.CurrentCulture);
            SetName();
        }
    }
}