﻿namespace Soporte.HerdezV2.Controllers
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI.Dashboard;
    using System.Collections;

    [Authorize]
    [Produces("application/json")]
    [Route("api/Seguimiento")]
    public class SeguimientoController : Controller
    {
        ValidateSeguimiento validateSeguimiento = new ValidateSeguimiento();

        [Route("~/api/GetDashboard")]
        [HttpGet]
        public IEnumerable GetDashboardData()
        {
            validateSeguimiento = new ValidateSeguimiento();
            return validateSeguimiento.GetDetalles();
        }

        [Route("~/api/GetDashboardTimbrados")]
        [HttpGet]
        public IEnumerable GetDashboardTimbrados()
        {
            validateSeguimiento = new ValidateSeguimiento();
            return validateSeguimiento.GetTimbradosCiaGrp();
        }

        // POST api/values
        [Route("~/api/PostCiaSerie")]
        [HttpPost]
        public IEnumerable PostCiaSerie(int cia, string serie)
        {
            validateSeguimiento = new ValidateSeguimiento();
            return validateSeguimiento.GetConteoCiaSerie(cia, serie);
        }


        // POST api/values
        [Route("~/api/PostMes")]
        [HttpPost]
        public IEnumerable PostDetalleMes(string anio, string mes, int idCia)
        {
            validateSeguimiento = new ValidateSeguimiento(anio, mes);
            return validateSeguimiento.GetConteoPorMes(idCia);
        }

        [Route("~/api/PostMesEstatus")]
        [HttpPost]
        public IEnumerable PostDetalleEstatusMes(string anio, string mes, int idCia, int idEstatus)
        {
            validateSeguimiento = new ValidateSeguimiento(anio, mes);
            return validateSeguimiento.GetMesEstatus(idCia, idEstatus);
        }
    }
}