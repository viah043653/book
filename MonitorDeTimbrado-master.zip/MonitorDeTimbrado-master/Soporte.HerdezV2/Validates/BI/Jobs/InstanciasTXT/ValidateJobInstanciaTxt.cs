﻿namespace Soporte.HerdezV2.Validates.BI.Jobs.InstanciasTXT
{
    using Dapper;
    using Hangfire;
    using Hangfire.Storage;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;

    public class ValidateJobInstanciaTxt : Connect
    {
        /// <summary>
        /// Obtiene compañías 
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetCias()
        {
            List<dynamic> cias = new List<dynamic>();
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                cias = db.Query<dynamic>("[INTERCAMBIO].[GetCias]", null, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            return cias;
        }

        /// <summary>
        /// Obtiene servidores
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetServidores()
        {
            List<dynamic> servidores = new List<dynamic>();
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                servidores = db.Query<dynamic>("[INTERCAMBIO].[GetServidores]", null, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            return servidores;
        }

        /// <summary>
        /// Obtiene tipos de documento
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetTiposDeDocumento()
        {
            List<dynamic> tiposDeDocumento = new List<dynamic>();
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                tiposDeDocumento = db.Query<dynamic>("[INTERCAMBIO].[GetTiposDeDocumentos]", null, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            return tiposDeDocumento;
        }

        /// <summary>
        /// Obtiene tipos de iteracion
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetTipoIteracion()
        {
            List<dynamic> tiposIteracion = new List<dynamic>();
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                tiposIteracion = db.Query<dynamic>("[INTERCAMBIO].[GetTipoIntervalo]", null, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            return tiposIteracion;
        }

        /// <summary>
        /// Obtiene listado de instancias configuradas
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetInstanciasConfiguradas()
        {
            List<dynamic> instanciasConfiguradas = new List<dynamic>();
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                instanciasConfiguradas = db.Query<dynamic>("[INTERCAMBIO].[GetInstanciasConfiguradas]", null, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            return instanciasConfiguradas;
        }

        /// <summary>
        /// Crea instancia para generación de TXT
        /// </summary>
        public dynamic PostInstancia(Instancia instancia)
        {
            try
            {
                List<int> tiposDePedidos = instancia.GetTiposPedidos();
                if (tiposDePedidos.Count == 0)
                    throw new Exception("Los tipos de pedido deben ser númericos");

                instancia.TiposDePedidos = string.Join(",", tiposDePedidos.Distinct().ToList());

                instancia.ClaveInstancia = string.Format("{0}_{1}_{2}", instancia.Servidor, instancia.Cia.ToString(), instancia.TipoDeDocumentos.ToString());
                instancia.FolderError = System.IO.Path.Combine(instancia.FolderDestino, "Errores", "GeneraTXT", instancia.ClaveInstancia);

                try
                {
                    System.IO.Directory.CreateDirectory(instancia.FolderError);
                }
                catch (Exception ex)
                {
                    throw new Exception("El usuario HDZFAC no tiene permisos para escribir en la ruta de destino");
                }


                var paref = new DynamicParameters();
                paref.Add("@Servidor", instancia.Servidor, DbType.String);
                paref.Add("@Cia", instancia.Cia, DbType.Int64);
                paref.Add("@ClaveTipoDeDocumento", instancia.TipoDeDocumentos, DbType.Int64);
                paref.Add("@IdTipoIteracion", instancia.TipoDeIntervalo, DbType.String);
                paref.Add("@Intervalo", instancia.Intervalo, DbType.Int64);
                paref.Add("@ClaveInstancia", instancia.ClaveInstancia, DbType.String);
                paref.Add("@NombreInstancia", instancia.NombreInstancia, DbType.String);
                paref.Add("@FolderDestino", instancia.FolderDestino, DbType.String);
                paref.Add("@FolderError", instancia.FolderError, DbType.String);
                paref.Add("@TiposDeFactura", instancia.TiposDePedidos, DbType.String);
                paref.Add("@EstatusDocumento", instancia.EstatusDeDocumento, DbType.Int64);
                paref.Add("@IdUsuarioConfigura", instancia.IdUsuario, DbType.Int64);
                paref.Add("@EsInstanciaActiva", instancia.EsInstanciaActiva, DbType.Boolean);
                paref.Add("@EsModificacion", instancia.EsModificacion, DbType.Boolean);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    db.Query("[INTERCAMBIO].[PostInstancia]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260);

                if (instancia.EsInstanciaActiva)
                    ActivarInstancias(instancia.ClaveInstancia, instancia.TipoDeIntervalo, instancia.Intervalo);
                else
                    DesactivarInstancias(instancia.ClaveInstancia);
            
                return new
                {
                    Estatus = "OK",
                    Mensaje = string.Format("Instancia {0} configurada correctamente", instancia.ClaveInstancia)
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    Estatus = "ERROR",
                    Mensaje = ex.Message
                };
            }
        }

        /// <summary>
        /// Activa o desactiva instancias
        /// </summary>
        /// <param name="claveInstancia">Clave de instancia</param>
        /// <param name="idUsuarioModifica"></param>
        /// <returns></returns>
        public dynamic SwitchInstancias(string claveInstancia, int idUsuarioModifica)
        {
            try
            {
                dynamic data = null;
                
                var paref = new DynamicParameters();
                paref.Add("@ClaveInstancia", claveInstancia, DbType.String);
                paref.Add("@IdUsuario", idUsuarioModifica, DbType.Int64);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    data = db.Query<dynamic>("[INTERCAMBIO].[SwitchInstancia]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260).FirstOrDefault();

                if (data.EsInstanciaActiva)
                    ActivarInstancias(claveInstancia, data.IdTipoIteracion, data.Intervalo);
                else
                    DesactivarInstancias(claveInstancia);

                return new
                {
                    Estatus = "OK",
                    Mensaje = string.Format("El cambio de estatus se realizo correctamente para la instancia {0}", claveInstancia)
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    Estatus = "ERROR",
                    Mensaje = ex.Message
                };
            }
        }

        /// <summary>
        /// Elimina instancias que no se encuentran activas
        /// </summary>
        /// <param name="claveInstancia"></param>
        /// <param name="idUsuarioElimina"></param>
        /// <param name="motivosDeEliminacion"></param>
        /// <returns></returns>
        public dynamic EliminarInstancia(string claveInstancia, int idUsuarioElimina, string motivosDeEliminacion)
        {
            try
            {
                var paref = new DynamicParameters();
                paref.Add("@ClaveInstancia", claveInstancia, DbType.String);
                paref.Add("@IdUsuarioElimina", idUsuarioElimina, DbType.Int64);
                paref.Add("@MotivosDeEliminacion", motivosDeEliminacion, DbType.String);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    db.Query("[INTERCAMBIO].[DeleteInstancia]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260);

                return new
                {
                    Estatus = "OK",
                    Mensaje = string.Format("La instancia {0} fue eliminada", claveInstancia)
                };
            }
            catch(Exception ex)
            {
                return new
                {
                    Estatus = "ERROR",
                    Mensaje = ex.Message
                };
            }
        }

        /// <summary>
        /// Elimina instancia
        /// </summary>
        /// <param name="claveInstancia"></param>
        internal void DesactivarInstancias(string claveInstancia)
        {
            RecurringJob.RemoveIfExists(claveInstancia);
            //-- Marca instancia con estatus de finalizada
            this.ControlInstancias(claveInstancia, false);
        }

        /// <summary>
        /// Cambia estatus de instancia
        /// </summary>
        /// <param name="claveInstancia"></param>
        /// <param name="tipoDeIntervalo"></param>
        /// <param name="intervalo"></param>
        internal void ActivarInstancias(string claveInstancia, string tipoDeIntervalo, int intervalo)
        {
            string intervaloDeEjecuciones = "";

            switch (tipoDeIntervalo)
            {
                case "HRS":
                    intervaloDeEjecuciones = Cron.HourInterval(intervalo);
                    break;
                case "MIN":
                    intervaloDeEjecuciones = Cron.MinuteInterval(intervalo);
                    break;
            }

            List<RecurringJobDto> recurringJobs = new List<RecurringJobDto>();
            using (var connection = JobStorage.Current.GetConnection())
            {
                recurringJobs = connection.GetRecurringJobs();
            }

            RecurringJobDto job = recurringJobs.FirstOrDefault(p => p.Id.Equals(claveInstancia, StringComparison.InvariantCultureIgnoreCase));

            RecurringJob.RemoveIfExists(claveInstancia);
            RecurringJob.AddOrUpdate(claveInstancia, () => LecturaDeCabeceros(claveInstancia), intervaloDeEjecuciones, TimeZoneInfo.Local, "instanciatxt_queue_tran");
        }

        /// <summary>
        /// Inicia lectura de documentos pendientes de crear
        /// </summary>
        /// <param name="claveInstancia">Clave de instancia</param>
        public void LecturaDeCabeceros(string claveInstancia)
        {
            List<Cabecero> cabeceros = new List<Cabecero>();

            try
            {
                //--Crea nueva instancia en control de instancias
                int claveControl = this.ControlInstancias(claveInstancia, true);

                if (claveControl == 1001)
                {
                    var paref = new DynamicParameters();
                    paref.Add("@ClaveInstancia", claveInstancia, DbType.String);
                    using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                        cabeceros = db.Query<Cabecero>("[INTERCAMBIO].[GetCabeceros]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 30).ToList();


                    foreach (Cabecero cabecero in cabeceros)
                        EscribeArchivo(claveInstancia, cabecero);
                }
            }
            catch (Exception ex)
            {
                //if (ex.Message.Contains("no se encuentra activa"))
                    this.SaveLog(claveInstancia, "Lectura de cabeceros", ex.Message);
            }
            finally
            {
                //--Marca instancia como finalizada
                this.ControlInstancias(claveInstancia, false);
            }
        }

        /// <summary>
        /// Escribe archivo en servidor y lo marca en AS400
        /// </summary>
        /// <param name="claveInstancia">Clave de instancia</param>
        /// <param name="oCabecero">Objeto cabecero</param>
        internal void EscribeArchivo(string claveInstancia, Cabecero oCabecero)
        {
            List<Detalle> detalleArchivo = new List<Detalle>();

            bool cabeceroActualizado = false;
            try
            {
                string
                    pathBaseTemporal = Path.Combine(this.PathTempotalInstanciasTXT, claveInstancia, DateTime.Now.Year.ToString(), DateTime.Now.Month.ToString("00"), DateTime.Now.Day.ToString("00")),
                    pathTemporal = Path.Combine(pathBaseTemporal, oCabecero.GetNombre()),
                    pathArchivo = Path.Combine(oCabecero.FolderDestino, oCabecero.GetNombre());

                if (!Directory.Exists(pathBaseTemporal))
                    Directory.CreateDirectory(pathBaseTemporal);

                DynamicParameters paref = new DynamicParameters();
                paref.Add("@ClaveInstancia", claveInstancia, DbType.String);
                paref.Add("@Cia", oCabecero.FECIA, DbType.Int32);
                paref.Add("@Sucursal", oCabecero.FESUC, DbType.Int32);
                paref.Add("@Serie", oCabecero.FESER, DbType.String);
                paref.Add("@Folio", oCabecero.FEFAC, DbType.Int64);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    detalleArchivo = db.Query<Detalle>("[INTERCAMBIO].[GetDetalle]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 30).ToList();

                if (detalleArchivo.Count > 0)
                {
                    foreach (Detalle oDetalle in detalleArchivo)
                        oDetalle.SetLinea();

                    if (File.Exists(pathTemporal)) File.Delete(pathTemporal);
                    if (File.Exists(pathArchivo)) File.Delete(pathArchivo);

                    File.WriteAllLines(pathTemporal, detalleArchivo.Select(d => d.Linea), Encoding.GetEncoding(1252));

                    cabeceroActualizado = CambioDeEstatusEnCabecero(claveInstancia, oCabecero, true);

                    if (cabeceroActualizado)
                        File.Move(pathTemporal, pathArchivo);
                    else
                        if (File.Exists(pathTemporal)) File.Delete(pathTemporal);
                }
            }
            catch (Exception ex)
            {
                if (cabeceroActualizado)
                    cabeceroActualizado = CambioDeEstatusEnCabecero(claveInstancia, oCabecero, false);

                this.SaveLog(claveInstancia, string.Format("EscribeArchivo - {0}{1}", oCabecero.FESER, oCabecero.FEFAC.ToString()), string.Format("CabeceroActualizado -> {0}. Error -> {1}", cabeceroActualizado, ex.Message));
            }
        }

        /// <summary>
        /// Actualiza estatus de documentos procesados
        /// </summary>
        /// <param name="claveInstancia">Clave de instancia</param>
        /// <param name="oCabecero">Objeto Cabecero</param>
        /// <param name="marcarDocumento">bandera que indica que estatus se le colocará al cabecero</param>
        /// <returns></returns>
        internal bool CambioDeEstatusEnCabecero(string claveInstancia, Cabecero oCabecero, bool marcarDocumento)
        {
            bool esUpdateOK = false;
            try
            {   
                DynamicParameters paref = new DynamicParameters();
                paref.Add("@ClaveInstancia", claveInstancia, DbType.String);
                paref.Add("@Cia", oCabecero.FECIA, DbType.Int32);
                paref.Add("@Sucursal", oCabecero.FESUC, DbType.Int32);
                paref.Add("@Serie", oCabecero.FESER, DbType.String);
                paref.Add("@Folio", oCabecero.FEFAC, DbType.Int64);
                paref.Add("@EsArchivoCreado", marcarDocumento, DbType.Boolean);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    esUpdateOK = db.Query<bool>("[INTERCAMBIO].[UpdateEstatusAS400]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 30).FirstOrDefault();
                return esUpdateOK;
            }
            catch(Exception ex)
            {
                this.SaveLog(claveInstancia, string.Format("ActualizaEstatus - {0}{1}", oCabecero.FESER, oCabecero.FEFAC.ToString()), ex.Message);
                return esUpdateOK;
            }
        }

        /// <summary>
        /// Control de instancias para evitar que una instancia que aún no finaliza se ejecute nuevamente
        /// </summary>
        /// <param name="claveInstancia">Clave</param>
        /// <param name="marcarEnProceso">Bandera con la que se desea actualizar el estatus de la instancia</param>
        /// <returns>Estatus</returns>
        internal int ControlInstancias(string claveInstancia, bool marcarEnProceso)
        {
            int claveEstatus = 0;
            try
            {
                DynamicParameters paref = new DynamicParameters();
                paref.Add("@ClaveInstancia", claveInstancia, DbType.String);
                paref.Add("@MarcarEnProceso", marcarEnProceso, DbType.Boolean);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    claveEstatus = db.Query<int>("INTERCAMBIO.ControlInstancia", paref, commandType: CommandType.StoredProcedure, commandTimeout: 10).FirstOrDefault();
            }
            catch(Exception ex)
            {
                this.SaveLog(claveInstancia, "ControlInstancias", ex.Message);
            }

            return claveEstatus;
        }

        /// <summary>
        /// Reporta errores por correo
        /// </summary>
        /// <param name="claveInstancia">Instancia que presento la incidencia</param>
        /// <param name="accion">Acción que se mando a llamar por api</param>
        /// <param name="mensaje">Mensaje de error</param>
        internal void SaveLog(string claveInstancia, string accion, string mensaje)
        {
            mensaje = mensaje.Replace("'", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "").Replace(":", "").Replace("\"", "");
            string dataJSON = "{\"data\": [{\"Instancia\": \""+ claveInstancia +"\", \"Acción\": \"" + accion + "\", \"Mensaje\": \"" + mensaje + "\"}]}";

            DynamicParameters paref = new DynamicParameters();
            paref.Add("@IdIntegracion", 12, DbType.Int32);
            paref.Add("@DataJSON", dataJSON, DbType.String);
            paref.Add("@Mensaje", "", DbType.String);
            using (IDbConnection db = new SqlConnection(ConnectionStringServicioCorreos))
                db.Query("[GENERICO].[BI_encolarEnvio]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260);
        }

        public class Cabecero
        {
            public int FECIA { get; set; }
            public int FESUC { get; set; }
            public string FESER { get; set; }
            public string FEFAC { get; set; }
            public string FolderDestino { get; set; }
            public string FolderError { get; set; }

            public string GetNombre()
            {
                return string.Format("{0}{1}{2}{3}.TXT", FECIA == 1 ? "01" : FECIA.ToString("000"), FESUC, FESER, FEFAC);
            }
        }

        public class Detalle
        {
            public string CPO1 { get; set; }
            public string SEC1 { get; set; }
            public string Linea { get; set; }

            public void SetLinea()
            {
                this.Linea = this.CPO1.Replace("\x001A", "É").Replace("#", "Ñ").Replace("¦", "ñ").Replace("¢", "[").Replace("!", "]");
            }
        }

        public class Instancia
        {
            public string NombreInstancia { get; set; }
            public int Cia { get; set; }
            public string Servidor { get; set; }
            public int TipoDeDocumentos { get; set; }
            public string TipoDeIntervalo { get; set; }
            public int Intervalo { get; set; }
            public string FolderDestino { get; set; }
            public string TiposDePedidos { get; set; }
            public bool EsInstanciaActiva { get; set; }
            public int EstatusDeDocumento { get; set; }
            public int IdUsuario { get; set; }
            public bool EsModificacion { get; set; }

            public string ClaveInstancia { get; set; }
            public string FolderError { get; set; }

            public List<int> GetTiposPedidos()
            {
                if (!string.IsNullOrEmpty(this.TiposDePedidos))
                {
                    List<string> tiposSplit = this.TiposDePedidos.Split(',').ToList();
                    return tiposSplit.Select(f =>
                    {
                        string newfolio = Regex.Replace(f, "[^0-9]", "");

                        int outFolio = 0;
                        int.TryParse(newfolio, out outFolio);
                        return outFolio;
                    }).ToList();
                }
                else
                    return new List<int>();
            }
        }
    }
}
