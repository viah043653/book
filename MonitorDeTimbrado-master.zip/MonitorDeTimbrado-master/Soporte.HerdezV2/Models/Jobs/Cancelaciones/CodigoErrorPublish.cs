﻿namespace Soporte.HerdezV2.Models.Jobs.Cancelaciones
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("CodigosErrorPublishCancelacion", Schema = "EDICOM")]
    public class CodigoErrorPublish
    {
        [Key]
        [Required]
        public int Codigo { get; set; }

        [Required]
        [MaxLength(200)]
        public string Error { get; set; }
    }
}
