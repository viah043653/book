﻿import { Injectable } from "@angular/core";
import { NgIf } from '@angular/common';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class RetransmisionXmlService {

    private baseUrl: string = '';

    constructor(private httpClient: HttpClient) {
        this.baseUrl = '/api/';
    }
     
    public PostRetransmision(files: any[], observaciones: string, usuario: string, esCambioACajas: boolean) {
        const frmData = new FormData();

        for (let file of files)
            frmData.append('Files', file.file, file.name);

        frmData.append('Observaciones', observaciones);
        frmData.append('Usuario', usuario);
        frmData.append('EsCambioCajas', esCambioACajas.toString());

        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any[]>(`${this.baseUrl}PostRetransmision`, frmData, { headers: headers });
    }

    public GetRetransmisionXmlHistorico() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.httpClient.get<any[]>(`${this.baseUrl}GetRetransmisionXmlHistorico`, { headers: _headers });
    }
}