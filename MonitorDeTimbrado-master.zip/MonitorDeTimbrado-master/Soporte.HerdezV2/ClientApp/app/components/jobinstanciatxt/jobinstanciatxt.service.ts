﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Headers } from '@angular/http';
import { Observable } from "rxjs";

@Injectable()
export class JobInstanciaTxtService {

    private baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }

    public PostInstancia(data: any) {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.post<any>(`${this.baseUrl}JobInstanciaTxt/PostInstancia`, data, { headers: _headers });
    }

    public PostSwitchInstancia(claveInstancia: string, idUsuario: number) {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.post<any>(`${this.baseUrl}JobInstanciaTxt/PostSwitchInstancia?claveInstancia=${claveInstancia}&idUsuario=${idUsuario}`, { headers: _headers });
    }

    public DeleteInstancia(idUsuario: number, claveInstancia: string, motivosEliminacion: string) {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.delete<any>(`${this.baseUrl}JobInstanciaTxt/Delete?claveInstancia=${claveInstancia}&idUsuario=${idUsuario}&motivo=${motivosEliminacion}`, { headers: _headers });
    }

    public GetCias(){
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.get<any>(`${this.baseUrl}JobInstanciaTxt/GetCias`, { headers: _headers });
    }

    public GetServidores() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.get<any>(`${this.baseUrl}JobInstanciaTxt/GetServidores`, { headers: _headers });
    }

    public GetTiposDeDocumento() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.get<any>(`${this.baseUrl}JobInstanciaTxt/GetTiposDeDocumento`, { headers: _headers });
    }

    public GetTipoIteracion() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.get<any>(`${this.baseUrl}JobInstanciaTxt/GetTipoIteracion`, { headers: _headers });
    }

    public GetInstanciasConfiguradas() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.get<any>(`${this.baseUrl}JobInstanciaTxt/GetInstanciasConfiguradas`, { headers: _headers });
    }
}