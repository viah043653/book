﻿namespace Soporte.HerdezV2.Repositories
{
    using Soporte.HerdezV2.Models.SP;
    using System.Collections.Generic;
    using Validates.BI.Dashboard;

    public class DetalleRepository : IDetalleRepository
    {
        public IEnumerable<DashboardPrincipal> DetallesRep => GetDetalles();

        private IEnumerable<DashboardPrincipal> GetDetalles()
        {
            ValidateSeguimiento seguimientoValidate = new ValidateSeguimiento();
            return seguimientoValidate.GetDetalles();
        }
    }
}