import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from '../shared/localstorage.service';

@Component({
    selector: 'nav-menu',
    templateUrl: './navmenu.component.html',
    styleUrls: ['./navmenu.style.css']
})
export class NavMenuComponent implements OnInit {

    imageUser: string = '';
    puesto: string = '';
    nombre: string = '';
    menuVU: any[] = [];
    menuModulos: any[] = [];

    showModuloPantallas: boolean = false;

    constructor(private localStorageService: LocalStorageService) { }
    
    ngOnInit() {
        debugger
        this.menuVU = [];
        this.menuModulos = [];

        this.showModuloPantallas = false;

        let userData = this.localStorageService.GetAuthorizationData();

        if (userData != null) {
            this.imageUser = userData._userData.ngUser.imagen;
            this.puesto = userData._userData.ngUser.puesto;
            this.nombre = userData._userData.ngUser.nombre;

            for (let opcion of userData._userData.ngViews.vistasUnicas) {
                this.menuVU.push({
                    componente: opcion.componente,
                    icono: opcion.iconoModulo,
                    nombreModulo: opcion.nombreModulo,
                    nombrePantalla: opcion.nombrePantalla
                });
            }

            this.menuModulos = userData._userData.ngViews.modulos;
        }
    }

    closeAcordion() {
        for (let m of this.menuModulos) {
            m.display = "none";
        }
    }

    acordion(menu: any) {
        debugger

        for (let m of this.menuModulos) {
            if (m.modulo != menu.modulo)
                m.display = "none";
        }

        menu.display = menu.display == "none" ? "block" : "none";
    }
}