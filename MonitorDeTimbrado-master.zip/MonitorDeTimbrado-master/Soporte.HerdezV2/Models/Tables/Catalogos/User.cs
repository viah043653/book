﻿namespace Soporte.HerdezV2.Models.Tables.Catalogos
{
    using Soporte.HerdezV2.Models.Tables.BI;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("tblUsuarios")]
    public class User
    {
        [Key]
        public int IdUsuario { get; set; }
        public int IdPerfil { get; set; }
        [MaxLength(50)]
        public string NombreUsuario { get; set; }
        public byte[] PasswordHash { get; set; }
        public byte[] PasswordSalt { get; set; }
        public bool Conectado { get; set; }
        public bool CambioPass { get; set; }
        public DateTime FechaAlta { get; set; }
        public DateTime FechaModificacion { get; set; }
        public Byte IdStatus { get; set; }
    }
}