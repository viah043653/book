﻿namespace Soporte.HerdezV2.Validates.BI
{
    using Dapper;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml;
    using System.Xml.Serialization;

    public class ValidateEnviosClientes : Connect
    {
        /// <summary>
        /// Consulta listado de clientes configurados
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetClientes()
        {
            return this._context.CatClientesRespuestas.
                Where(c => c.IdStatus == 1).
                Select(c => new { c.Rfc, c.Nombre }).
                ToList();
        }

        /// <summary>
        /// Consulta respuestas de clientes por rango de fechas
        /// </summary>
        /// <param name="filtro">Filtro de busqueda</param>
        /// <returns>Lista de respuestas</returns>
        public IEnumerable GetEnvios(FiltroEnvio filtro)
        {
            IEnumerable result;

            string xml = ""; bool esBusquedaXml = false;
            if (filtro.Folios.Count > 0)
            {
                Busqueda busquedaXml = new Busqueda();
                busquedaXml.Documento = new List<Folio>();
                busquedaXml.Documento = filtro.Folios;

                xml = busquedaXml.GetXml<Busqueda>(busquedaXml);

                esBusquedaXml = true;
            }

            var prms = new DynamicParameters();
            prms.Add("@RfcReceptor", filtro.RfcReceptor, DbType.String);
            prms.Add("@FechaInicial", filtro.FechaInicial, DbType.Date);
            prms.Add("@FechaFinal", filtro.FechaFinal, DbType.Date);
            prms.Add("@IndiceInicio", filtro.IndiceInicio, DbType.Int32);
            prms.Add("@EsBusquedaXMl", esBusquedaXml, DbType.Boolean);
            prms.Add("@XmlData", xml, DbType.Xml);

            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                result = db.Query<dynamic>("sp_ConsultaEnviosClientes", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
            return result;
        }

        /// <summary>
        /// Consulta respuestas de cliente por rango de fechas 
        /// </summary>
        /// <param name="filtro">Filtro de busqueda</param>
        /// <returns>Archivo de excel con listado de respuestas</returns>
        public IEnumerable GetZip(FiltroEnvio filtro)
        {
            try
            {
                IEnumerable result;

                var prms = new DynamicParameters();
                prms.Add("@RfcReceptor", filtro.RfcReceptor, DbType.String);
                prms.Add("@FechaInicial", filtro.FechaInicial, DbType.Date);
                prms.Add("@FechaFinal", filtro.FechaFinal, DbType.Date);
                prms.Add("@Ids", filtro.Ids, DbType.String);

                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    result = db.Query<dynamic>("sp_ConsultaReporteDeEntregas", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

                return result;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public class FiltroEnvio
        {
            public string RfcReceptor { get; set; }
            public DateTime FechaInicial { get; set; }
            public DateTime FechaFinal { get; set; }
            public int IndiceInicio { get; set; }
            public string Ids { get; set; }
            public List<Folio> Folios { get; set; } = new List<Folio>();
        }

        /// <remarks/>
        [XmlTypeAttribute(AnonymousType = true)]
        [XmlRootAttribute(Namespace = "", IsNullable = false)]
        public partial class Busqueda
        {
            private List<Folio> documentoField;

            /// <remarks/>
            [XmlElementAttribute("Documento")]
            public List<Folio> Documento
            {
                get { return this.documentoField; }
                set { this.documentoField = value; }
            }

            public string GetXml<T>(T objct)
            {
                string xmlCFDIResultField = string.Empty;
                XmlDocument xmlCFDI = new XmlDocument();
                var xmlSerializer = new XmlSerializer(typeof(T));

                XmlWriterSettings settings = new XmlWriterSettings()
                {
                    Encoding = new UnicodeEncoding(false, false),
                    Indent = false,
                    OmitXmlDeclaration = false
                };

                using (StringWriter sWriter = new StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(sWriter, settings))
                    {
                        xmlSerializer.Serialize(sWriter, objct, null);
                        xmlCFDI.LoadXml(sWriter.ToString());
                    }
                }
                xmlCFDIResultField = xmlCFDI.InnerXml;
                using (MemoryStream mStream = new MemoryStream())
                {
                    using (XmlTextWriter writer = new XmlTextWriter(mStream, Encoding.UTF8))
                    {
                        XmlDocument document = new XmlDocument();
                        document.LoadXml(xmlCFDI.InnerXml);

                        writer.Formatting = System.Xml.Formatting.Indented;

                        document.WriteContentTo(writer);
                        writer.Flush();

                        mStream.Flush();
                        mStream.Position = 0;

                        using (StreamReader sReader = new StreamReader(mStream, Encoding.UTF8))
                            xmlCFDIResultField = sReader.ReadToEnd();
                    }
                }
                return xmlCFDIResultField;
            }
        }

        [XmlTypeAttribute(AnonymousType = true)]
        public partial class Folio
        {
            [XmlAttributeAttribute()]
            public string Serie { get; set; }

            [XmlAttributeAttribute()]
            public long Numero { get; set; }
        }
    }
}