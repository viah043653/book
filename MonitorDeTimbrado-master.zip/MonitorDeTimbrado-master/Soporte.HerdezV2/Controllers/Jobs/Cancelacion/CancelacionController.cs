﻿namespace Soporte.HerdezV2.Controllers.Jobs.Cancelacion
{
    using System;
    using System.Linq;
    using Hangfire;
    using Hangfire.Storage;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI.Jobs.Cancelaciones;

    [Produces("application/json")]
    [Route("apiHangFire/JobCancelacion")]
    public class CancelacionController : ControllerBase
    {
        ValidateCancelaciones valCancelaciones = new ValidateCancelaciones();
        string
            Task = string.Empty,
            MensajeServicioActivo = string.Empty,
            MensajeServicioIniciado = string.Empty,
            MensajeServicioDetenido = string.Empty,
            Queue = "cancelaciones_queue_tran";

        // GET: apiHangFire/JobCancelacion/IniciarCancelaciones
        [HttpGet("IniciarCancelaciones")]
        public IActionResult IniciarTimbrado()
        {
            string mensaje = string.Empty;

            Task = "JobCancelaciones";
            MensajeServicioActivo = "El servicio para cancelaciones masivas ya se encuentra activo";
            MensajeServicioIniciado = "Servicio para cancelaciones masivas iniciado";
            MensajeServicioDetenido = "Servicio para cancelaciones masivas detenido";

            valCancelaciones = new ValidateCancelaciones();

            try
            {
                using (var connection = JobStorage.Current.GetConnection())
                {
                    string lastRunResult = string.Empty;
                    var recurringJobs = connection.GetRecurringJobs();
                    var job = recurringJobs.FirstOrDefault(p => p.Id.Equals(Task, StringComparison.InvariantCultureIgnoreCase));
                    if (job != null)
                        mensaje = string.IsNullOrEmpty(job.LastJobId) ? MensajeServicioIniciado : MensajeServicioActivo;
                    else
                        mensaje = MensajeServicioIniciado;
                }

                if (mensaje == MensajeServicioIniciado)
                {
                    RecurringJob.RemoveIfExists(Task);
                    RecurringJob.AddOrUpdate(Task, () => valCancelaciones.CancelarDocumentosPendientes(), valCancelaciones.SoapEnvCancelaciones.TimerPostCancelacion, TimeZoneInfo.Local, Queue);
                }

                valCancelaciones.CancelarDocumentosPendientes();
            }
            catch (Exception ex)
            {
                mensaje = ex.ToString();
            }

            if (!string.IsNullOrEmpty(valCancelaciones.SoapEnvCancelaciones.TimerPostCancelacion))
                return Ok(string.Format("{0} -> {1}", mensaje, valCancelaciones.SoapEnvCancelaciones.TimerPostCancelacion));
            else
                return Ok(mensaje);
        }

        // GET: apiHangFire/JobCancelacion/IniciarDescargaDeRespuestas
        [HttpGet("IniciarDescargaDeRespuestas")]
        public IActionResult IniciarDescargaDeRespuestas()
        {
            string mensaje = string.Empty;

            Task = "JobRespuestaCancelaciones";
            MensajeServicioActivo = "El servicio para respuesta de cancelaciones masivas ya se encuentra activo";
            MensajeServicioIniciado = "Servicio para respuesta de cancelaciones masivas iniciado";
            MensajeServicioDetenido = "Servicio para respuesta de cancelaciones masivas detenido";

            valCancelaciones = new ValidateCancelaciones();

            try
            {
                using (var connection = JobStorage.Current.GetConnection())
                {
                    string lastRunResult = string.Empty;
                    var recurringJobs = connection.GetRecurringJobs();
                    var job = recurringJobs.FirstOrDefault(p => p.Id.Equals(Task, StringComparison.InvariantCultureIgnoreCase));
                    if (job != null)
                        mensaje = string.IsNullOrEmpty(job.LastJobId) ? MensajeServicioIniciado : MensajeServicioActivo;
                    else
                        mensaje = MensajeServicioIniciado;
                }

                if (mensaje == MensajeServicioIniciado)
                {
                    RecurringJob.RemoveIfExists(Task);
                    RecurringJob.AddOrUpdate(Task, () => valCancelaciones.RequestCancelacionEstatus(), valCancelaciones.SoapEnvCancelaciones.TimerGetRespuestas, TimeZoneInfo.Local, Queue);
                }

                valCancelaciones.RequestCancelacionEstatus();
            }
            catch (Exception ex)
            {
                mensaje = ex.ToString();
            }

            if (!string.IsNullOrEmpty(valCancelaciones.SoapEnvCancelaciones.TimerGetRespuestas))
                return Ok(string.Format("{0} -> {1}", mensaje, valCancelaciones.SoapEnvCancelaciones.TimerGetRespuestas));
            else
                return Ok(mensaje);
        }
    }
}
