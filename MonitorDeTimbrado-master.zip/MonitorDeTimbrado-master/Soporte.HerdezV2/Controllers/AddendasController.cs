﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Soporte.HerdezV2.Controllers
{
    [Produces("application/json")]
    [Route("api/Addendas")]
    public class AddendasController : Controller
    {
        // POST: api/Addendas
        [HttpPost]
        public dynamic Post()
        {
            //var files = HttpContext.Request.Form.Files;
            //string observaciones = HttpContext.Request.Form["Observaciones"];
            //int idUsuario = Convert.ToInt16(HttpContext.Request.Form["Usuario"]);
            //string esCambioCajas = HttpContext.Request.Form["EsCambioCajas"].ToString().ToUpper();

            //_validateArchivosIntercambio = new ValidateArchivosIntercambio();
            //var result = this._validateArchivosIntercambio.PostRetransmision(files, observaciones, idUsuario, esCambioCajas);

            //return result;

            return null;
        }

        //// GET: api/Addendas
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET: api/Addendas/5
        //[HttpGet("{id}", Name = "Get")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST: api/Addendas
        //[HttpPost]
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT: api/Addendas/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE: api/ApiWithActions/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
