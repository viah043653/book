﻿namespace Soporte
{
    using System;

    public class Bitacora
    {
        public long IdBitacora { get; set; }

        public int IdUsuario { get; set; }

        public int Cia { get; set; }
        
        public string Serie { get; set; }

        public long Folio { get; set; }
        
        public string Proceso { get; set; }
        public string Estatus { get; set; }
        public string NombreArchivo { get; set; }
        public string Observaciones { get; set; }
        public DateTime FechaAlta { get; set; }
    }
}