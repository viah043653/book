﻿namespace Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;

    public class ReporteNota : ReporteBase
    {
        public string FolioFicNC { get; set; }
        public DateTime FechaContable { get; set; }
        public string TectoFinancieroNC { get; set; }
        public string ConceptoNC { get; set; }
        public decimal TotalNC { get; set; }
        public decimal IvaNC { get; set; }
        public decimal IepsNC { get; set; }
        public string UuidFactura { get; set; }

        public static List<ReporteNota> GetReporteNotaList(string pathCsv)
        {
            List<string[]> lineasReporteNC = File.ReadAllLines(pathCsv).Select(l => l.Split(',')).ToList();
            lineasReporteNC.RemoveAt(0);
            lineasReporteNC = lineasReporteNC.Where(l => l[11].Contains("A")).ToList();

            var lstRe = new List<ReporteNota>();
            foreach (var l in lineasReporteNC)
            {
                DateTime outDT;

                DateTime.TryParseExact(l[6].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out outDT);

                if(outDT == DateTime.MinValue)
                    DateTime.TryParseExact(l[6].ToString(), "dd/MM/yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out outDT);

                var reporteNota = new ReporteNota();
                reporteNota.FolioFicNC = l[0];
                reporteNota.RfcEmisor = l[3];
                reporteNota.RfcReceptor = l[5];
                reporteNota.FechaContable = outDT;
                reporteNota.TectoFinancieroNC = l[7];
                reporteNota.ConceptoNC = l[8];
                reporteNota.SerieFactura = l[11].Substring(0, 1);
                reporteNota.FolioFactura = Convert.ToInt64(l[11].Replace("A", ""));
                reporteNota.TotalNC = Convert.ToDecimal(l[16]);
                reporteNota.IvaNC = Convert.ToDecimal(l[19]);
                reporteNota.IepsNC = Convert.ToDecimal(l[23]);
                reporteNota.UuidFactura = l[42];

                lstRe.Add(reporteNota);
            }

            return lstRe;
            //return lineasReporteNC.Select(l => new ReporteNota()
            //{
            //    FolioFicNC = l[0],
            //    RfcEmisor = l[3],
            //    RfcReceptor = l[5],
            //    FechaContable = DateTime.ParseExact(l[6].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture), //Convert.ToDateTime(l[6]),
            //    TectoFinancieroNC = l[7],
            //    ConceptoNC = l[8],
            //    SerieFactura = l[11].Substring(0, 1),
            //    FolioFactura = Convert.ToInt64(l[11].Replace("A", "")),
            //    TotalNC = Convert.ToDecimal(l[16]),
            //    IvaNC = Convert.ToDecimal(l[19]),
            //    IepsNC = Convert.ToDecimal(l[23]),
            //    UuidFactura = l[42]
            //}).ToList();
        }
    }
}