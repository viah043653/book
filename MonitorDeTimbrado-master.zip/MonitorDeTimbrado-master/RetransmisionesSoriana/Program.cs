﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetransmisionesSoriana
{
    class Program
    {
        static void Main(string[] args)
        {
            var startTimeSpan = TimeSpan.Zero;
            var periodTimeSpan = TimeSpan.FromMinutes(1);

            //var timer = new System.Threading.Timer((e) =>
            //{
                updateSoriana();
            //}, null, startTimeSpan, periodTimeSpan);

            Console.ReadLine();
        }

        static void updateSoriana()
        {
            List<string> Bitacoras = new List<string>();
            string qyer = "SELECT NombreArchivo FROM biBitacora WHERE Proceso = 'RetransmisiónXml'";
            using (IDbConnection db = new SqlConnection("Server=192.168.200.87;Database=SoporteFacturacion_Produccion; User Id=pruebaFact; Password=PruebasSql$123;MultipleActiveResultSets=true"))
            {
                Bitacoras = db.Query<string>(qyer, null, commandType: CommandType.Text, commandTimeout: 260).ToList();
            }

            //if (Bitacoras.Count > 0)
            //{
            //    Bitacoras
            //        .GroupBy(b => new { b.Cia, b.Serie, b.Folio })
            //        .Select(b => new { b.Key.Cia, b.Key.Serie, b.Key.Folio, b.OrderByDescending( })

            //}

            string rutaSorianaProd = @"C:\Users\SYGNO\Desktop\"; // @"\\HDZFAC001\FacturasDescargadas\Soriana\";

            DirectoryInfo dInfo = new DirectoryInfo(rutaSorianaProd);

            foreach (var file in dInfo.GetFiles("*.txt"))
            {
                if (!Bitacoras.Contains(file.Name))
                {
                    var lineas = File.ReadAllLines(file.FullName);
                    string rfc = lineas[0].Split(':')[1].TrimStart().TrimEnd();
                    string serie = lineas[3].Split(':')[1].TrimStart().TrimEnd();
                    long folio = Convert.ToInt64(lineas[4].Split(':')[1].TrimStart().TrimEnd());
                    string estatus = lineas[6].Split(':')[1].TrimStart();
                    string observaciones = estatus + " - " + lineas[7].Split(':')[1];
                    int cia = 0;

                    switch (rfc)
                    {
                        case "HER8301121X4":
                            cia = 1;
                            break;
                        case "CHE041201L59":
                            cia = 60;
                            break;
                        case "NUT840801733":
                            cia = 77;
                            break;
                        case "OCO160809URA":
                            cia = 92;
                            break;
                    }

                    var prms = new DynamicParameters();
                    prms.Add("@Cia", cia, DbType.Int16);
                    prms.Add("@Serie", serie, DbType.String);
                    prms.Add("@Folio", folio, DbType.Int64);
                    prms.Add("@Estatus", estatus, DbType.String);
                    prms.Add("@NombreArchivo", file.Name, DbType.String);
                    prms.Add("@Observaciones", observaciones, DbType.String);
                    using (IDbConnection db = new SqlConnection("Server=192.168.200.87;Database=SoporteFacturacion_Produccion; User Id=pruebaFact; Password=PruebasSql$123;MultipleActiveResultSets=true"))
                    {
                        Bitacoras = db.Query<string>("sp_RegisterRetransmision", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                    }

                }
            }
        }
    }
}
