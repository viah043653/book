﻿import { Component, OnInit, Inject, ViewContainerRef } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogContent, MatDialog } from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { saveAs } from 'file-saver';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';

import { PdfService } from '../pdf/pdf.service';
import { SharedService } from '../shared/shared.service';

@Component({
    providers: [PdfService, SharedService],
    selector: 'app-my-dialog',
    templateUrl: './dialog.timeline.component.html',
    styleUrls: ['./dialog.timeline.style.css']
})

export class DialogTimeLineComponent implements OnInit {

    historico: any[] = [];
    mensaje: string = '';
    adjuntos: string = '';
    public archivos: any[] = [];

    ciaID: string = '';
    cia: string = '';

    serie : string = '';
    folio: number = 0;
    foliosText: string = '';

    companias: any[] = [
        { rfc: 'CHE041201L59', nombre: 'COMPAÑIA COMERCIAL HERDEZ S.A. DE C.V.', numero: '0600' },
        { rfc: 'NUT840801733', nombre: 'NUTRISA S.A DE C.V.', numero: '0770' },
        { rfc: 'OCO160809URA', nombre: 'OLYEN COFFEE', numero: '0920' },
        { rfc: 'HER8301121X4', nombre: 'HERDEZ S.A DE C.V.', numero: '0010' },
        { rfc: 'HER980609NC1', nombre: 'HERSEA.', numero: '0430' },
        { rfc: 'KSN200902B97', nombre: "KI'TAL SNACKS, S. A. DE C. V.", numero: '0950' },
        { rfc: 'ROC020422UV9', nombre: 'RC OPERADORA DE CAFETERIAS SA DE CV', numero: '1020' }
    ];

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, public _pdfService: PdfService, public dialogRef: MatDialogRef<DialogTimeLineComponent>, public dialog: MatDialog, @Inject(MAT_DIALOG_DATA) public data: any, private spinnerService: Ng4LoadingSpinnerService, public _sharedService: SharedService) {
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnInit() {
        this.adjuntos = '';
        this.archivos = [];
    }

    onCloseConfirm() {
        this.dialogRef.close('Confirm');
    }

    onCloseCancel() {
        this.dialogRef.close('Cancel');
    }

    setCia(_cia: any) {
        this.cia = _cia.rfc;
        this.ciaID = _cia.numero;
    }

    getFiles(event: any) {
        debugger
        this.archivos = [];

        if (event.target.files.length > 15) {
            this.toastr.error('Solo esta permitida la carga de 15s Cfdis', 'Error');
            return false;
        }

        this.adjuntos = '';
        this.adjuntos = event.target.files.length + (event.target.files.length > 1 ? ' archivos seleccionados' : ' archivo seleccionado');

        for (let file of event.target.files)
            this.archivos.push({ name: file.name, file: file });

        if (this.archivos.length > 0) {

            this.spinnerService.show();
            this._pdfService.PostXmlToPdfWithFile(this.archivos).
                subscribe(
                    (data) => {
                        debugger

                        var fileContentResult = data[0].archivo;
                        var respuestas = data[0].respuestas;

                        if (fileContentResult != null) {
                            var dataBlob = this._sharedService.b64toBlob(fileContentResult.fileContents, fileContentResult.contentType);
                            saveAs(dataBlob, fileContentResult.fileDownloadName);
                        }

                        if (respuestas.length > 0) {
                            var dataDetails = { tipoModal: 'errorPdfs', data: { titulo: 'Error en regeneración de ' + respuestas.length + ' pdf(s)', foliosError: respuestas } };
                            this.dialogRef.close();
                            this.dialog.open(DialogTimeLineComponent, {
                                width: '80%',
                                height: 'auto',
                                data: dataDetails,
                                panelClass: 'custom-dialog-container2'
                            });
                        }
                        else
                            this.toastr.success('Se regeneraron un total de ' + (this.archivos.length - respuestas.length) + ' pdf(s)', 'Descarga completa');
                    },
                    response => {
                        this.archivos = [];
                        this.spinnerService.hide();
                        this._sharedService.catchHttpResponseError(response);
                    },
                    () => {
                        this.archivos = [];
                        this.spinnerService.hide();
                    });
        }
        else {
        }
    }

    descargar(esFolioUnico: boolean) {

        debugger
        var folios: any[] = [];

        if (esFolioUnico) {
            if (this.cia != '' && this.serie != '' && this.folio > 0) {

                var serieToUpper = this.serie.toUpperCase();
                //if (serieToUpper == 'A' || serieToUpper == 'B' || serieToUpper == 'C' || serieToUpper == 'D' || serieToUpper == 'P') {
                    folios.push({ Rfc: this.cia, Serie: serieToUpper, Folio: this.folio });
                //}
                //else {
                //    this.toastr.error('La serie no es válida', 'Error');
                //    return false;
                //}
            }
            else {
                this.toastr.error('Todos los datos son obligatorios', 'Error');
                return false;
            }
        }
        else {
            var menorA3 = false;
            let listaFolios = this.foliosText.split("\n");

            var listaFoliosClean = [];
            for (var i = 0; i < listaFolios.length; i++) {
                if (listaFolios[i])
                    listaFoliosClean.push(listaFolios[i]);
            }

            if (listaFoliosClean.length > 0) {

                //if (listaFoliosClean.length > 10) {
                //    this.toastr.error('Solo esta permitido descargar 10 documentos por petición', 'Error');
                //    return false;
                //}

                for (let folio of listaFoliosClean) {
                    var arrayData = folio.split(/\s+/);

                    if (arrayData.length != 3)
                        menorA3 = true;
                    else {
                        folios.push(
                            {
                                Rfc: arrayData[0].trim(),
                                Serie: arrayData[1].trim(),
                                Folio: arrayData[2].trim()
                            });
                    }
                }

                if (menorA3) {
                    this.spinnerService.hide();
                    this.foliosText = '';
                    this.toastr.error('Tiene que colocar la informaci&oacute;n en el formato indicado [ Cia Serie Folio ] ', 'Formato incorrecto');
                    return;
                }
            }
            else {
                this.toastr.error('Tiene que envíar un listado de folios', 'Error');
                return;
            }
        }

        this.convertFiles(folios);
    }

    convertFiles(folios: any[]) {

        this.spinnerService.show();

        this._pdfService.PostXmlToPdf(folios).
            subscribe(
            (data) => {
                debugger
                var fileContentResult = data[0].archivo;
                var respuestas = data[0].respuestas;
                
                if (fileContentResult != null) {
                    var dataBlob = this._sharedService.b64toBlob(fileContentResult.fileContents, fileContentResult.contentType);
                    saveAs(dataBlob, fileContentResult.fileDownloadName);
                }

                if (respuestas.length > 0) {
                    var dataDetails = { tipoModal: 'errorPdfs', data: { titulo: 'Error en regeneración de ' + respuestas.length + ' pdf(s)', foliosError: respuestas } };
                    this.dialogRef.close();
                    this.dialog.open(DialogTimeLineComponent, {
                        width: '80%',
                        height: 'auto',
                        data: dataDetails,
                        panelClass: 'custom-dialog-container2'
                    });
                }
                else
                    this.toastr.success('Se regeneraron un total de ' + (folios.length - respuestas.length) + ' pdf(s)', 'Descarga completa');
            },
            response => {
                this.archivos = [];
                this.adjuntos = '';
                this.spinnerService.hide();
                this._sharedService.catchHttpResponseError(response);
            },
            () => {                
                folios = [];
                this.adjuntos = '';
                this.serie = '';
                this.folio = 0;
                this.foliosText = '';
                this.foliosText = '';
                this.spinnerService.hide();
            });
    }
}