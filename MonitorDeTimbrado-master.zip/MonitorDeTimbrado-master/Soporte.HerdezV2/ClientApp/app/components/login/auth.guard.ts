﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { LocalStorageService } from '../shared/localstorage.service';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router, private localStorageService: LocalStorageService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {

        let authorization = this.localStorageService.GetAuthorizationData();
        if (authorization != null)
            return true;
        
        this.router.navigate([''], { queryParams: { returnUrl: state.url } });
        return false;
    }
}