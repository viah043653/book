﻿namespace Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui
{
    using System;

    public class ReporteEntrega
    {
        public Int64 Factura { get; set; }
        public string FolioFic { get; set; }
        public string TextoFinanciero { get; set; }
        public decimal TotalNC { get; set; }
        
        public string FolioFicXml { get; set; } = "";
        public string SerieNC { get; set; } = "";
        public Int64 FolioNC { get; set; } = 0;
        public decimal TotalNcAS400 { get; set; } = 0;
        public string RespuestaPAC { get; set; } = "";
        public DateTime? FechaRespuesta { get; set; }

        public string FolioCancela { get; set; }
        public decimal ImporteCancela { get; set; }
    }
}
