﻿namespace Soporte.HerdezV2.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Threading.Tasks;
    using Hangfire;
    using Hangfire.Storage;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui;

    [Produces("application/json")]
    [Route("api/Utils")]
    public class UtilsController : Controller
    {
        // GET: api/Utils/CruceNotasChedraui
        [HttpGet("CruceNotasChedraui")]
        public IActionResult CruceNotasChedraui()
        {
            ValidateCruceNotasChedraui validateCruceNC = new ValidateCruceNotasChedraui();
            dynamic archivo = validateCruceNC.Get();

            return File(archivo.Contenido, "application/vnd.ms-excel", archivo.NombreArchivo);
        }
    }
}
