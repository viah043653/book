﻿namespace Soporte.HerdezV2.Models.Generic
{
    using System;

    public class Mensaje : IDisposable
    {
        private bool disposedValue = false;

        public String Descripcion { get; set; }

        public String Exception { get; set; }

        public DateTime FechaAlta { get; set; } = DateTime.Now;

        public Object _data { get; set; }

        #region IDisposable Support

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                Descripcion = String.Empty;
                disposedValue = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}