﻿import { Component, ViewChild, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel, DataSource } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { DistribucionXmlService } from './distribucionxml.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { EnvioIntercambioService } from '../enviointercambio/enviointercambio.service'
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/takeUntil';
import { getAllDebugNodes, DebugNode } from '@angular/core/src/debug/debug_node';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { PropertyRead } from '@angular/compiler';
import { forEach } from '@angular/router/src/utils/collection';


@Component({
    providers: [DistribucionXmlService, SharedService, EnvioIntercambioService],
    selector: 'distribucionxml',
    templateUrl: './distribucionxml.component.html',
    styleUrls: ['./distribucionxml.style.css']
})

export class DistribucionXmlComponent implements OnInit, OnDestroy {
    private VIEW_ID: number = 12;

    
    cia: string= '';
    serie: string = '';


    consultaLista: any[] = [];
    folios: string = '';
    estatu: string = '';
    isActionButtonsVisible: boolean = false;
    ShowSpinnerTable: boolean = true;
    isSearchCleanVisible: boolean = false;

    showCheckInTable: boolean = true;

    isTableVisble: boolean = false;
    interval: any;

    displayedColumns = ['isChecked', 'cliente', 'nombre', 'correo'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    filterValue: string = '';

    companias: any[] = [
        { rfc: 'CHE041201L59', nombre: 'COMPAÑIA COMERCIAL HERDEZ S.A. DE C.V.', numero: '60' },
        { rfc: 'NUT840801733', nombre: 'NUTRISA S.A DE C.V.', numero: '77' },
        { rfc: 'OCO160809URA', nombre: 'OLYEN COFFEE', numero: '92' },
        { rfc: 'HER8301121X4', nombre: 'HERDEZ S.A DE C.V.', numero: '1' }
    ];

    

    httpBusqueda: Observable<any[]>;

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    private _busquedaser: DistribucionXmlService;
    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, busquedaService: DistribucionXmlService, private spinnerService: Ng4LoadingSpinnerService, public distribucionxmlservice: DistribucionXmlService, public sharedservice: SharedService, public localstorageservice: LocalStorageService, public enviointercambioservice: EnvioIntercambioService, public dialog: MatDialog) {
        this.toastr.setRootViewContainerRef(vcr);
        this._busquedaser = busquedaService;
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() {
        this.getRegeneracionList();
        Observable.interval(2000 * 60).takeUntil(this.onDestroy$).subscribe(x => {
            this.getRegeneracionList();
        });
    }

    

   

    detalleSeguimiento(bitacora: any) {
        let desgloze: any[] = [];
        for (let historico of bitacora.historicoDesgloze)
            desgloze.push({ proceso: historico.proceso, tipoLinea: 1, usuario: historico.usuario, mensaje: historico.observaciones, fechaProceso: historico.fechaProceso, claseError: 'fa fa-repeat bg-blue' })

        let _mensaje = bitacora.mensaje == null ? '' : bitacora.mensaje;
        let _contenido = bitacora.contenido == null ? '' : bitacora.contenido;

        desgloze.push({ proceso: 'Respuesta del PAC', tipoLinea: 2, usuario: bitacora.estatus, mensaje: _mensaje + ' ' + _contenido, fechaProceso: bitacora.fechaProceso, claseError: bitacora.estatus.includes('Error') ? 'fa fa-bug bg-red' : bitacora.estatus.includes('Timbrado') ? 'fa fa-check bg-green' : 'fa fa-exclamation-triangle bg-yellow' });

        var dataDetails = { tipoModal: 'detalleBitacora', data: { titulo: 'Linea de tiempo de regeneraciónes ordenada descendente', foliosError: this.sharedservice.orderDescendingByDate(desgloze, "fechaProceso") } };

        this.dialog.open(DialogTimeLineComponent, {
            width: '570%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }

    regenerarArchivo() {
         

        //this.httpBusqueda = this.consultaservice.GetEntrxFoli(this.ciaID, this.serieID, this.folio);
        
        //this.httpBusqueda.subscribe(

        //    (status) => {

        //        var condicion = status;
                
        //        debugger


               
                    
                

        //    },
        //    response => {
        //        this.ShowSpinnerTable = false;
        //        this.sharedservice.catchHttpResponseError(response);
        //    },
        //    () => {
        //        this.ShowSpinnerTable = false;
        //    }
        //);
    
    }
          
    

    getRegeneracionList() {

        this.ShowSpinnerTable = true
        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);


        this.distribucionxmlservice.GetFitimbrado().
            subscribe(
            (data) => {
                    debugger
                    this.dataSource = new MatTableDataSource(data);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;
                    this.selectionCheckBox = new SelectionModel<any>(true, []);
                },
                response => {
                    this.ShowSpinnerTable = false;
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                    this.ShowSpinnerTable = false;
                });
    }

    actualizarestatus() {

        this.consultaLista = this.selectionCheckBox.selected;

        


        this.distribucionxmlservice.GetCamEst(this.consultaLista);

    }


    

    descargarCsv() {
        this.spinnerService.show();
        var datosTablaResumen = [];

        datosTablaResumen.push({
           
            "serie": "Serie",
            "folio": "Folio",
            "estatus": "Estatus",
            
        });


        for (let doc of this.selectionCheckBox.selected) {
            var detalle = '';
            
            for (let h of doc.historicoDesgloze) {
                
                datosTablaResumen.push(
                    {
                       
                        "serie": doc.serie,
                        "folio": doc.folio,
                        "estatus": doc.estatus
                        
                    }
                );
        }
     }

        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();
    }

    


    regresar() {
        this.isTableVisble = false;
    }

   

    //applyFilter(filterValue: string) {
    //    filterValue = filterValue.trim();
    //    filterValue = filterValue.toLowerCase();
    //    this.dataSource.filter = filterValue;

    //    this.selectionCheckBox = new SelectionModel<any>(true, []);
    //    this.isActionButtonsVisible = false;
    //}
    applyFilter(clearData: boolean/*filterValue: string*/) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}