﻿namespace Soporte.HerdezV2.Validates.BI
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class ValidateTiposDeDocumentos : Connect
    {
        public IEnumerable Get()
        {
            return this._context.CatTiposDeDocumentos.Where(c => c.EstatusActivo).Select(x => new { x.Serie, x.Descripcion });
        }
    }
}
