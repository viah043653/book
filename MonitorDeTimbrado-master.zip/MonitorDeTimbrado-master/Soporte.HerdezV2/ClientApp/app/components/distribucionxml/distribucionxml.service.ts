﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Headers } from '@angular/http';

@Injectable()
export class DistribucionXmlService {

    private baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }

    public GetFitimbrado() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostFitimbrado`;

        return this.http.post<any>(postUrl, { headers: _headers });
    }

    public GetCamEst(folios: any[])
    {
        debugger
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.http.post<any[]>(`${this.baseUrl}PostCamEst`, folios, { headers: headers });

    }

   
}