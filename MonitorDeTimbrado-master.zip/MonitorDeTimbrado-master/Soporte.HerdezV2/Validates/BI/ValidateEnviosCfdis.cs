﻿namespace Soporte.HerdezV2.Validates.BI
{
    using Dapper;
    using ExcelDataReader;
    using Microsoft.AspNetCore.Http;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml;
    using System.Xml.Serialization;
    using System.Net.Mail;
    using Microsoft.AspNetCore.Builder;
    using System.Collections.Specialized;
    using System.Xml.XPath;
    using System.Diagnostics;
    using System.Threading;

    public class ValidateEnviosCfdis : Connect
    {
        string RutaTemporal = @"\\hdzfac001\FacturasDescargadas\7Eleven";

        public class Respuesta
        {
            public string Mensajeerror { get; set; }
            public bool Statuss { get; set; }
            public List<string> Listadatos { get; set; }
        }

        public class Respuestafolsev
        {
            public string Mensajeerror { get; set; }
            public bool Statuss { get; set; }
            public List<string> Listadatos { get; set; }
        }


        public class Respuestanomusu
        {
            public string Mensajeerror { get; set; }
            public bool Statuss { get; set; }
            public List<string> Listadatos { get; set; }
        }

        public Respuesta PostEnvioCfdis(int usuario, string clientetext,string dfolio, IFormFile formFile)
        {
            Respuesta generall = new Respuesta();
            Respuestafolsev folioseven = new Respuestafolsev();
            Respuestanomusu nomusuario = new Respuestanomusu();

            string Vrutalog = @"\\hdzfac001\FacturasDescargadas\7Eleven\EnvioPM\Folios.txt";
            string Vrutnoenv = @"\\hdzfac001\FacturasDescargadas\CRA0404041I0\FoliosComercializadora.txt";

            try
            {
             
               if (clientetext == "SEM980701STA")
               {
                    List<string> folios = new List<string>();

                    folios = GetFoliosOnExcel(formFile, dfolio).ToList();

                   for (int i = 1; i < folios.Count; i++)
                   {
                        string[] Vseparacion = folios[i].Split('_');
                        string Vrfcreceptor = Vseparacion[1];
                        string Vserie = Vseparacion[2];
                        string Vfolio = Vseparacion[3];
                        string Vfoldercorreos = "";
                        string Vnomusu = "";
                        string Vfacfdsev = @"\\hdzfac001\FacturasDescargadas\7Eleven\EnvioPM\";

                        generall.Listadatos = new List<string>();

                        var paref = new DynamicParameters();
                        paref.Add("@rfcreceptor", Vrfcreceptor, DbType.String);
                        paref.Add("@serie", Vserie, DbType.String);
                        paref.Add("@folio", Vfolio, DbType.Int32);
                        using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                        {
                            generall.Listadatos = db.Query<string>("sp_ConsultaFolioTransferenciasCFDI", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                        }

                        folioseven.Listadatos = new List<string>();

                        var parcfs = new DynamicParameters();
                        parcfs.Add("@rfcreceptor", Vrfcreceptor, DbType.String);
                        parcfs.Add("@serie", Vserie, DbType.String);
                        parcfs.Add("@folio", Vfolio, DbType.Int32);
                        using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                        {
                            folioseven.Listadatos = db.Query<string>("sp_ConsultaUUIDSProcesados", parcfs, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                        }

                        nomusuario.Listadatos = new List<string>();

                        var parus = new DynamicParameters();
                        parus.Add("@IdUsuario", usuario, DbType.Int32);
                        using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                        {
                            nomusuario.Listadatos = db.Query<string>("sp_ObtenerNombreUsuario", parus, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                        }

                        Vnomusu = nomusuario.Listadatos[0].ToString();

                       if (folioseven.Listadatos.Count == 1)
                       {

                            if (generall.Listadatos.Count == 1)
                            {
                               Vfoldercorreos = generall.Listadatos[0].ToString();

                                if (File.Exists(Vfoldercorreos))
                                {
                                    if (dfolio == "ENVIO SIN CORRECION")
                                    {
                                        Enviosincorrecion(Vfoldercorreos, Vfacfdsev, Vrfcreceptor, Vserie, Vfolio, Vnomusu, dfolio);
                                    }
                                    if (dfolio == "CORRECCION TIENDA")
                                    {
                                        string Vnuetie = Vseparacion[5];

                                        CorrecionTienda(Vfoldercorreos, Vnuetie, Vfacfdsev, Vrfcreceptor, Vserie, Vfolio, Vnomusu, dfolio);
                                    }
                                    if (dfolio == "CORRECCION FOLIO DE RECEPCION")
                                    {
                                        string Vnuefol = Vseparacion[5];
                                        
                                        CorrecionFolRec(Vfoldercorreos, Vnuefol, Vfacfdsev, Vrfcreceptor, Vserie, Vfolio, Vnomusu, dfolio);
                                    }
                                    if (dfolio == "CORRECCION TIENDA Y FOLIO")
                                    {
                                        string Vnuetied = Vseparacion[5];
                                        string Vnuefold = Vseparacion[6];

                                        CorrecionTieFol(Vfoldercorreos, Vnuetied, Vnuefold, Vfacfdsev, Vrfcreceptor, Vserie, Vfolio, Vnomusu, dfolio);
                                    }
                                }
                                else
                                {
                                    if (!File.Exists(Vrutalog))
                                    {
                                        using (StreamWriter creatxt = File.AppendText(Vrutalog))
                                        {
                                            creatxt.Dispose();
                                            creatxt.Close();
                                }
                                    }
                                    if (File.Exists(Vrutalog))
                                    {
                                        using (StreamWriter Leetxt = new StreamWriter(Vrutalog, true))
                                        {
                                            //se agrega información al documento
                                            Leetxt.WriteLine("No se encontro el xml para su envio:" + Vfolio);
                                            //Leetxt.Write("\n");
                                            Leetxt.Close();
                                        }

                                    }
                                }
                            }
                            else
                            {
                                if (!File.Exists(Vrutalog))
                                {
                                    using (StreamWriter creatxt = File.AppendText(Vrutalog))
                                    {
                                        creatxt.Dispose();
                                        creatxt.Close();
                                    }
                                }
                                if (File.Exists(Vrutalog))
                                {
                                    using (StreamWriter Leetxt = new StreamWriter(Vrutalog, true))
                                    {
                                        //se agrega información al documento
                                        Leetxt.WriteLine("Validar que el folio este timbrado:" + Vfolio);

                                        //Leetxt.Write("\n");
                                        Leetxt.Close();
                                    }

                                }
                            }
                       }
                       else
                       {
                            if (!File.Exists(Vrutalog))
                            {
                                using (StreamWriter creatxt = File.AppendText(Vrutalog))
                                {
                                    creatxt.Dispose();
                                    creatxt.Close();
                                }
                            }
                            if (File.Exists(Vrutalog))
                            {
                                using (StreamWriter Leetxt = new StreamWriter(Vrutalog, true))
                                {
                                    //se agrega información al documento
                                    Leetxt.WriteLine("Validar que el folio pertenezca a seven:" + Vfolio);

                                    //Leetxt.Write("\n");
                                    Leetxt.Close();
                                }

                            }
                       }

                   }
                   
                    ProcessStartInfo info = new ProcessStartInfo();

                    info.UseShellExecute = true;
                    info.FileName = "Pruebaconjexionseven.exe";
                    info.WorkingDirectory = @"\\hdzfac001\FacturasDescargadas\7Eleven\EnvioPM\Envio";

                    Process.Start(info);

                    ProcessStartInfo infod = new ProcessStartInfo();

                    infod.UseShellExecute = true;
                    infod.FileName = "enviacorreoparafoliosnoenviadosdeseven.exe";
                    infod.WorkingDirectory = @"\\hdzfac001\FacturasDescargadas\7Eleven\EnvioPM\Enviocorreo";

                    Process.Start(infod);
                   
               }

                if (clientetext == "CRA0404041I0")
                {
                    List<string> folios = new List<string>();

                    folios = GetFoliosOnExcel(formFile, dfolio).ToList();

                    for (int i = 1; i < folios.Count; i++)
                    {
                        string[] Vseparacion = folios[i].Split('_');
                        string Vrfcreceptor = Vseparacion[1];
                        string Vserie = Vseparacion[2];
                        string Vfolio = Vseparacion[3];
                        string Vfecha = Vseparacion[4];
                        string Vfoldercorreos = "";
                        string Vnomusu = "";
                        string Vfacfdsev = @"\\hdzfac001\FacturasDescargadas\CRA0404041I0";


                        generall.Listadatos = new List<string>();

                        var paref = new DynamicParameters();
                        paref.Add("@rfcreceptor", Vrfcreceptor, DbType.String);
                        paref.Add("@serie", Vserie, DbType.String);
                        paref.Add("@folio", Vfolio, DbType.Int32);
                        using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                        {
                            generall.Listadatos = db.Query<string>("sp_ConsultaFolioSeguimientoCFDI", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                        }

                        nomusuario.Listadatos = new List<string>();

                        var parus = new DynamicParameters();
                        parus.Add("@IdUsuario", usuario, DbType.Int32);
                        using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                        {
                            nomusuario.Listadatos = db.Query<string>("sp_ObtenerNombreUsuario", parus, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                        }

                        Vnomusu = nomusuario.Listadatos[0].ToString();

                        if (generall.Listadatos.Count == 1)
                        {
                            DateTime _fechaDt = DateTime.ParseExact(Vfecha.Trim(), "dd/MM/yyyy", null);
                            //string[] separa = Vfecha.Split('/');
                            string Vyearse = _fechaDt.Year.ToString(); //separa[2].Substring(0,4);
                            string Vmont = _fechaDt.Month.ToString("00");// separa[1];
                            string Vday = _fechaDt.Day.ToString("00"); //separa[0];
                            string Vfehcaruta = Vyearse + Vmont + Vday;
                            string Vfechanxml = Vday + Vmont + Vyearse;
                            string Vnommon = "";


                            if (Vmont == "01")
                            {
                                Vnommon = "enero";
                            }
                            if (Vmont == "02")
                            {
                                Vnommon = "febrero";
                            }
                            if (Vmont == "03")
                            {
                                Vnommon = "marzo";
                            }
                            if (Vmont == "04")
                            {
                                Vnommon = "abril";
                            }
                            if (Vmont == "05")
                            {
                                Vnommon = "mayo";
                            }
                            if (Vmont == "06")
                            {
                                Vnommon = "junio";
                            }
                            if (Vmont == "07")
                            {
                                Vnommon = "julio";
                            }
                            if (Vmont == "08")
                            {
                                Vnommon = "agosto";
                            }
                            if (Vmont == "09")
                            {
                                Vnommon = "septiembre";
                            }
                            if (Vmont == "10")
                            {
                                Vnommon = "octubre";
                            }
                            if (Vmont == "11")
                            {
                                Vnommon = "noviembre";
                            }
                            if (Vmont == "12")
                            {
                                Vnommon = "diciembre";
                            }

                            string Varchivo = @"\\hdzfac001\FolderCorreos\" + Vyearse + @"\" + Vmont + " - " + Vnommon + @"\" + Vfehcaruta + @"\CRA0404041I0_" + Vserie+"_" + Vfolio + "_774956_" + Vfechanxml + ".xml";

                            if (File.Exists(Varchivo))
                            {


                                if (File.Exists(Vfacfdsev + @"\CRA0404041I0_" + Vserie + "_" + Vfolio + "_774956_" + Vfechanxml + ".xml"))
                                {
                                    File.Delete(Vfacfdsev + @"\CRA0404041I0_" + Vserie + "_" + Vfolio + "_774956_" + Vfechanxml + ".xml");
                                    File.Copy(Varchivo, Vfacfdsev + @"\CRA0404041I0_" + Vserie + "_" + Vfolio + "_774956_" + Vfechanxml + ".xml");
                                }
                                else
                                {
                                    File.Copy(Varchivo, Vfacfdsev + @"\CRA0404041I0_" + Vserie + "_" + Vfolio + "_774956_" + Vfechanxml + ".xml");
                                }

                                XmlDocument _xmlc = new XmlDocument();
                                _xmlc.Load(Vfacfdsev + @"\CRA0404041I0_" + Vserie + "_" + Vfolio + "_774956_" + Vfechanxml + ".xml");

                                /*Elimina Adenda Plana*/
                                XmlNodeList nodosAdendad = _xmlc.GetElementsByTagName("cfdi:Addenda");
                                for (int idt = 0; idt < nodosAdendad.Count; idt++)
                                    if (nodosAdendad[idt].InnerXml.Contains("lev1add:EDCINVOICE"))
                                        nodosAdendad[idt].ParentNode.RemoveChild(nodosAdendad[idt]);

                                _xmlc.Save(Vfacfdsev + @"\CRA0404041I0_" + Vserie + "_" + Vfolio + "_774956_" + Vfechanxml + ".xml");


                                var insenv = new DynamicParameters();
                                insenv.Add("@Rfc_Receptor", Vrfcreceptor, DbType.String);
                                insenv.Add("@Serie", Vserie, DbType.String);
                                insenv.Add("@Folio", Vfolio, DbType.Int32);
                                insenv.Add("@Usuario", Vnomusu, DbType.String);
                                insenv.Add("@Motivo", dfolio, DbType.String);
                                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                                {
                                    db.Query<string>("sp_InsertaEnvios", insenv, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                                }

                            }
                            else
                            {
                                if (!File.Exists(Vrutnoenv))
                                {
                                    using (StreamWriter creatxt = File.AppendText(Vrutnoenv))
                                    {
                                        creatxt.Dispose();
                                        creatxt.Close();
                                    }
                                }
                                if (File.Exists(Vrutnoenv))
                                {
                                    using (StreamWriter Leetxt = new StreamWriter(Vrutnoenv, true))
                                    {
                                        //se agrega información al documento
                                        Leetxt.WriteLine(string.Format("Validar que el folio tenga la fecha correcta: {0}, {1}, Fecha: {2}", Vfolio, Varchivo, Vfecha));

                                        //Leetxt.Write("\n");
                                        Leetxt.Close();
                                    }

                                }
                            }


                        }
                        else
                        {
                            if (!File.Exists(Vrutnoenv))
                            {
                                using (StreamWriter creatxt = File.AppendText(Vrutnoenv))
                                {
                                    creatxt.Dispose();
                                    creatxt.Close();
                                }
                            }
                            if (File.Exists(Vrutnoenv))
                            {
                                using (StreamWriter Leetxt = new StreamWriter(Vrutnoenv, true))
                                {
                                    //se agrega información al documento
                                    Leetxt.WriteLine("Validar que el folio este timbrado:" + Vfolio);

                                    //Leetxt.Write("\n");
                                    Leetxt.Close();
                                }

                            }
                        }
                    }

                    ProcessStartInfo infod = new ProcessStartInfo();

                    infod.UseShellExecute = true;
                    infod.FileName = "EnvioerroresComercializadora.exe";
                    infod.WorkingDirectory = @"\\hdzfac001\FacturasDescargadas\CRA0404041I0\Envios\Envioerror";

                    Process.Start(infod);

                    ProcessStartInfo info = new ProcessStartInfo();

                    info.UseShellExecute = true;
                    info.FileName = "EnvioComercializadora.exe";
                    info.WorkingDirectory = @"\\hdzfac001\FacturasDescargadas\CRA0404041I0\Envios\Enviocorrecto";

                    Process.Start(info);
                }

                generall.Statuss = true;
            }
            catch (Exception ex)
            {
                generall.Statuss = false;
                generall.Mensajeerror = ex.Message;
            }

            return generall;

        }


        private IEnumerable<string> GetFoliosOnExcel(IFormFile formFile, string dfolio)
        {
            List<string> folios = new List<string>();
            try
            {
                byte[] fileByteArray = null;
                using (MemoryStream ms = new MemoryStream())
                {
                    formFile.OpenReadStream().CopyTo(ms);
                    fileByteArray = ms.ToArray();
                }

                string archivoTemporal = Path.Combine(this.RutaTemporal, formFile.FileName);
                if (File.Exists(archivoTemporal))
                    File.Delete(archivoTemporal);

                File.WriteAllBytes(archivoTemporal, fileByteArray);

                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                using (var stream = System.IO.File.Open(archivoTemporal, FileMode.Open, FileAccess.Read))
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        if (dfolio == "ENVIO SIN CORRECION")
                        {
                           while (reader.Read())
                           folios.Add(reader.GetValue(0).ToString() + "_" + reader.GetValue(1).ToString() + "_" + reader.GetValue(2).ToString() + "_" + reader.GetValue(3).ToString() + "_" + reader.GetValue(4).ToString());
                        }

                        if (dfolio == "CORRECCION TIENDA")
                        {
                           while (reader.Read())
                           folios.Add(reader.GetValue(0).ToString() + "_" + reader.GetValue(1).ToString() + "_" + reader.GetValue(2).ToString() + "_" + reader.GetValue(3).ToString() + "_" + reader.GetValue(4).ToString() + "_" + reader.GetValue(5).ToString());

                        }

                        if (dfolio == "CORRECCION FOLIO DE RECEPCION")
                        {
                           while (reader.Read())
                           folios.Add(reader.GetValue(0).ToString() + "_" + reader.GetValue(1).ToString() + "_" + reader.GetValue(2).ToString() + "_" + reader.GetValue(3).ToString() + "_" + reader.GetValue(4).ToString() + "_" + reader.GetValue(6).ToString());
                        }

                        if (dfolio == "CORRECCION TIENDA Y FOLIO")
                        {
                           while (reader.Read())
                           folios.Add(reader.GetValue(0).ToString() + "_" + reader.GetValue(1).ToString() + "_" + reader.GetValue(2).ToString() + "_" + reader.GetValue(3).ToString() + "_" + reader.GetValue(4).ToString() + "_" + reader.GetValue(5).ToString() + "_" + reader.GetValue(6).ToString());
                        }

                        if (dfolio == "ENVIO COMERCIALIZADORA")
                        {
                            while (reader.Read())
                                folios.Add(reader.GetValue(0).ToString() + "_" + reader.GetValue(1).ToString() + "_" + reader.GetValue(2).ToString() + "_" + reader.GetValue(3).ToString() + "_" + reader.GetValue(4).ToString());
                        }
                    }
                }

                try { File.Delete(archivoTemporal); }
                catch (Exception ex) { }
            }
            catch (Exception ex)
            {
                if (dfolio == "ENVIO SIN CORRECION")
                {
                    throw new Exception("Error en lectura de archivo, favor de validar que tenga el formato correcto y no tenga celdas vacias en la columna folio serie y rfcReceptor");
                }
                if (dfolio == "CORRECCION TIENDA")
                {
                    throw new Exception("Error en lectura de archivo, favor de validar que tenga el formato correcto y no tenga celdas vacias en la columna tienda");
                }
                if (dfolio == "CORRECCION FOLIO DE RECEPCION")
                {
                    throw new Exception("Error en lectura de archivo, favor de validar que tenga el formato correcto y no tenga celdas vacias en la columna folio");
                }
                if (dfolio == "CORRECCION TIENDA Y FOLIO")
                {
                    throw new Exception("Error en lectura de archivo, favor de validar que tenga el formato correcto y no tenga celdas vacias en la columna tienda y folio");
                }
                if (dfolio == "ENVIO COMERCIALIZADORA")
                {
                    throw new Exception("Error en lectura de archivo, favor de validar que tenga el formato correcto y no tenga celdas vacias en la columna folio, serie, rfcReceptor y fecha");
                }
            }

            return folios;
        }

        void Enviosincorrecion(string Vfoldercorreos,string Vfacfdsev, string Vrfcreceptor, string Vserie, string Vfolio, string Vnomusu, string dfolio)
        {
            string[] Vnomxml = Vfoldercorreos.Split('\\');
            string Vnomxmld = Vnomxml[7];

            if (File.Exists(Vfacfdsev + Vnomxmld))
            {
                File.Delete(Vfacfdsev + Vnomxmld);
                File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);
            }
            else
            {
                File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);
            }

            XmlDocument _xml = new XmlDocument();
            _xml.Load(Vfacfdsev + Vnomxmld);

            /*Elimina Adenda Plana*/
            XmlNodeList nodosAdenda = _xml.GetElementsByTagName("cfdi:Addenda");
            for (int idd = 0; idd < nodosAdenda.Count; idd++)
                if (nodosAdenda[idd].InnerXml.Contains("lev1add:EDCINVOICE"))
                    nodosAdenda[idd].ParentNode.RemoveChild(nodosAdenda[idd]);

            _xml.Save(Vfacfdsev + Vnomxmld);


            var insenv = new DynamicParameters();
            insenv.Add("@Rfc_Receptor", Vrfcreceptor, DbType.String);
            insenv.Add("@Serie", Vserie, DbType.String);
            insenv.Add("@Folio", Vfolio, DbType.Int32);
            insenv.Add("@Usuario", Vnomusu, DbType.String);
            insenv.Add("@Motivo", dfolio, DbType.String);
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
            {
                db.Query<string>("sp_InsertaEnvios", insenv, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
            }
        }

        void CorrecionTienda(string Vfoldercorreos,string Vnuetie, string Vfacfdsev, string Vrfcreceptor, string Vserie, string Vfolio, string Vnomusu, string dfolio)
        {
            string valorTienda = "";

            XmlDocument _xml = new XmlDocument();
            _xml.Load(Vfoldercorreos);

            foreach (XmlElement recepcion in _xml.GetElementsByTagName("cfdi:Recepciones")[0])
            {
                valorTienda = recepcion.Attributes["tienda"].Value;
                recepcion.SetAttribute("tienda", Vnuetie);
            }

            _xml.Save(Vfoldercorreos);

            string[] Vnomxml = Vfoldercorreos.Split('\\');
            string Vnomxmld = Vnomxml[7];

            if (File.Exists(Vfacfdsev + Vnomxmld))
            {
                File.Delete(Vfacfdsev + Vnomxmld);
                File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);
            }
            else
            {
                File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);
            }

            XmlDocument _xmld = new XmlDocument();
            _xmld.Load(Vfacfdsev + Vnomxmld);
        
            /*Elimina Adenda Plana*/
            XmlNodeList nodosAdendad = _xmld.GetElementsByTagName("cfdi:Addenda");
            for (int idt = 0; idt < nodosAdendad.Count; idt++)
                if (nodosAdendad[idt].InnerXml.Contains("lev1add:EDCINVOICE"))
                    nodosAdendad[idt].ParentNode.RemoveChild(nodosAdendad[idt]);

            _xmld.Save(Vfacfdsev + Vnomxmld);


            var instie = new DynamicParameters();
            instie.Add("@Rfc_Receptor", Vrfcreceptor, DbType.String);
            instie.Add("@Serie", Vserie, DbType.String);
            instie.Add("@Folio", Vfolio, DbType.Int32);
            instie.Add("@Usuario", Vnomusu, DbType.String);
            instie.Add("@Motivo", dfolio, DbType.String);
            instie.Add("@TiendaAnterior", valorTienda, DbType.String);
            instie.Add("@TiendaNueva", Vnuetie, DbType.String);

            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
            {
                db.Query<string>("sp_InsertaEnviosCorTie", instie, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
            }
        }

        void CorrecionFolRec(string Vfoldercorreos, string Vnuefol, string Vfacfdsev, string Vrfcreceptor, string Vserie, string Vfolio, string Vnomusu, string dfolio)
        { 
            string valorFolio = "";

            XmlDocument _xmlt = new XmlDocument();
            _xmlt.Load(Vfoldercorreos);
             
            foreach (XmlElement recepcion in _xmlt.GetElementsByTagName("cfdi:Recepciones")[0])
            {
                valorFolio = recepcion.Attributes["folio"].Value;
                recepcion.SetAttribute("folio", Vnuefol);
            }

            _xmlt.Save(Vfoldercorreos);

            string[] Vnomxml = Vfoldercorreos.Split('\\');
            string Vnomxmld = Vnomxml[7];

            if (File.Exists(Vfacfdsev + Vnomxmld))
            {
                File.Delete(Vfacfdsev + Vnomxmld);
                File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);
            }
            else
            {
                File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);
            }

            XmlDocument _xmlc = new XmlDocument();
            _xmlc.Load(Vfacfdsev + Vnomxmld);

            /*Elimina Adenda Plana*/
            XmlNodeList nodosAdendad = _xmlc.GetElementsByTagName("cfdi:Addenda");
            for (int idt = 0; idt < nodosAdendad.Count; idt++)
                if (nodosAdendad[idt].InnerXml.Contains("lev1add:EDCINVOICE"))
                    nodosAdendad[idt].ParentNode.RemoveChild(nodosAdendad[idt]);

            _xmlc.Save(Vfacfdsev + Vnomxmld);


            var insfor = new DynamicParameters();
            insfor.Add("@Rfc_Receptor", Vrfcreceptor, DbType.String);
            insfor.Add("@Serie", Vserie, DbType.String);
            insfor.Add("@Folio", Vfolio, DbType.Int32);
            insfor.Add("@Usuario", Vnomusu, DbType.String);
            insfor.Add("@Motivo", dfolio, DbType.String);
            insfor.Add("@FolioAnterior", valorFolio, DbType.String);
            insfor.Add("@FolioNuevo", Vnuefol, DbType.String);

            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
            {
                db.Query<string>("sp_InsertaEnviosCorFol", insfor, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
            }
        }

        void CorrecionTieFol(string Vfoldercorreos, string Vnuetied, string Vnuefold, string Vfacfdsev, string Vrfcreceptor, string Vserie, string Vfolio, string Vnomusu, string dfolio)
        {
            string valorTienda = "";
            string valorFolio = "";

            XmlDocument _xml = new XmlDocument();
            _xml.Load(Vfoldercorreos);

            foreach (XmlElement recepcion in _xml.GetElementsByTagName("cfdi:Recepciones")[0])
            {
                valorTienda = recepcion.Attributes["tienda"].Value;
                recepcion.SetAttribute("tienda", Vnuetied);
                valorFolio = recepcion.Attributes["folio"].Value;
                recepcion.SetAttribute("folio", Vnuefold);
            }

            _xml.Save(Vfoldercorreos);

            string[] Vnomxml = Vfoldercorreos.Split('\\');
            string Vnomxmld = Vnomxml[7];

            if (File.Exists(Vfacfdsev + Vnomxmld))
            {
                File.Delete(Vfacfdsev + Vnomxmld);
                File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);
            }
            else
            {
                File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);
            }

            XmlDocument _xmld = new XmlDocument();
            _xmld.Load(Vfacfdsev + Vnomxmld);

            /*Elimina Adenda Plana*/
            XmlNodeList nodosAdendad = _xmld.GetElementsByTagName("cfdi:Addenda");
            for (int idt = 0; idt < nodosAdendad.Count; idt++)
                if (nodosAdendad[idt].InnerXml.Contains("lev1add:EDCINVOICE"))
                    nodosAdendad[idt].ParentNode.RemoveChild(nodosAdendad[idt]);

            _xmld.Save(Vfacfdsev + Vnomxmld);


            var instiefol = new DynamicParameters();
            instiefol.Add("@Rfc_Receptor", Vrfcreceptor, DbType.String);
            instiefol.Add("@Serie", Vserie, DbType.String);
            instiefol.Add("@Folio", Vfolio, DbType.Int32);
            instiefol.Add("@Usuario", Vnomusu, DbType.String);
            instiefol.Add("@Motivo", dfolio, DbType.String);
            instiefol.Add("@TiendaAnterior", valorTienda, DbType.String);
            instiefol.Add("@TiendaNueva", Vnuetied, DbType.String);
            instiefol.Add("@FolioAnterior", valorFolio, DbType.String);
            instiefol.Add("@FolioNuevo", Vnuefold, DbType.String);

            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
            {
                db.Query<string>("sp_InsertaEnviosCorTieFol", instiefol, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
            }
        }

    }
}
