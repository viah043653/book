﻿namespace Soporte.HerdezV2.Models.SP
{
    using System;

    public class Documento
    {
        public Int64 IdArchivo { get; set; }
        public string Serie { get; set; }
        public Int64 Folio { get; set; }
        public DateTime FechaAlta { get; set; }
        public int ClaveEstatus { get; set; }
        public String DescripcionEstatus { get; set; }
        public DateTime FechaProceso { get; set; }
        public String Mensaje { get; set; }
        public String Contenido { get; set; }
    }
}