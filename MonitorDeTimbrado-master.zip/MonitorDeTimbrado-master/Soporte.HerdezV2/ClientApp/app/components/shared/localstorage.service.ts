﻿import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class LocalStorageService {

    private lsKeyValue = "_keyLS";
    private localStorageKey: any = localStorage.getItem(this.lsKeyValue);

    constructor(private router: Router) { }
    
    public SetAuthorizationData(auth: any): void {
        this.localStorageKey = new Date().toISOString().split('T')[1].replace(':', '').replace('.', '');
        localStorage.setItem(this.lsKeyValue, this.localStorageKey)

        localStorage.setItem(this.localStorageKey, JSON.stringify(auth));
        //this.router.navigate(['/monitor']);
    }

    public RemoveAuthorizationData(): void {        
        localStorage.removeItem(this.lsKeyValue);
        localStorage.removeItem(this.localStorageKey);
        //this.router.navigate(['']);
        window.location.reload();
    }

    public RemoveFromStorage(): void {
        localStorage.removeItem(this.lsKeyValue);
        localStorage.removeItem(this.localStorageKey);
    }

    public GetAuthorizationData(): any {
        let localStorageString: any = localStorage.getItem(this.localStorageKey);
        return JSON.parse(localStorageString);
    }

    public GetAuthorizationUser(): number {
        let data = this.GetAuthorizationData();
        if (data == null)
            this.router.navigate(['/monitor']);

        if (data._userData.ngUser.numU == undefined)
            this.router.navigate(['/monitor']);

        return data._userData.ngUser.numU;
    }

    public GetActions(viewId: number): any[] {
        let authData = this.GetAuthorizationData();

        if (authData == null)
            this.router.navigate(['']);

        let _acciones: any[] = [];
        for (let _modulo of authData._userData.ngViews.modulos) {
            for (let _pantalla of _modulo.pantallas) {
                if (_pantalla.pantalla == viewId)
                    _acciones = JSON.parse(_pantalla.acciones);
            }
        }

        if (_acciones.length == 0) {
            for (let _pantalla of authData._userData.ngViews.vistasUnicas) {
                if (_pantalla.idPantalla == viewId)
                    _acciones = JSON.parse(_pantalla.acciones);
            }
        }

        return _acciones;
    }
}