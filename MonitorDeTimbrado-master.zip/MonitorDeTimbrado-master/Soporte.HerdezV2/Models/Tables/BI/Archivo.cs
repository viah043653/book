﻿namespace Soporte.HerdezV2.Models.Tables.BI
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("biArchivos")]
    public class Archivo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long IdArchivo { get; set; }
        [Required]
        public int Cia { get; set; }
        [Required]
        public int Sucursal { get; set; }
        //[Required]
        //[MaxLength(12)]
        //public String Rfc { get; set; }
        [Required]
        [MaxLength(1)]
        public String Serie { get; set; }
        [Required]
        public long Folio { get; set; }
        public Guid Uuid { get; set; }
        [Required]
        public DateTime FechaAlta { get; set; }
        public DateTime FechaTimbre { get; set; }
    }
}