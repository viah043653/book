﻿namespace MT.Sftp.Models
{
    public enum estatus
    {
        OK,
        ERROR
    }

    public class Result
    {
        public estatus Estatus { get; set; }
        public string Mensaje { get; set; }
    }
}
