﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Headers } from '@angular/http';

@Injectable()
export class ActualizaTxtRfcGenericoService {

    private baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }

    public PostActualizaRfcGenerico(cia: string, serie: string, folio: number, usuario: number, observaciones: string) {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostActualizaIntercambioRfcGenerico?cia=${cia}&serie=${serie}&folio=${folio}&usuario=${usuario}&observaciones=${observaciones}`;
        
        return this.http.post<any>(postUrl, { headers: _headers });
    }
}