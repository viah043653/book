﻿using Dapper;
using Soporte.HerdezV2.Models.Tables.BI;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Soporte.HerdezV2.Validates
{
    public class ValidateActualizaArchivoIntercambioRfc : Connect
    {
        public class ErrorRfc
        {
            public string RfcEmisor { get; set; }
            public string RfcReceptor { get; set; }
            public DateTime FechaProceso { get; set; }
        }

        public class Linea
        {
            public int Indice { get; set; }
            public string Contenido { get; set; }
        }

        public dynamic PostRegeneracion(string cia, string serie, long folio, int usuario, string observaciones)
        {
            try
            {
                ErrorRfc respuesta = null;
                var prms = new DynamicParameters();
                prms.Add("@cia", cia, DbType.String);
                prms.Add("@serie", serie, DbType.String);
                prms.Add("@folio", folio, DbType.Int64);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    respuesta = db.Query<ErrorRfc>("sp_ConsultaDocumentoErrorEnRfc", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).FirstOrDefault();

                if (respuesta != null)
                {
                    string nombreArchivo = string.Format("{0}{1}{2}.TXT", cia, serie, folio);

                    respuesta.FechaProceso = respuesta.FechaProceso.AddDays(-1);

                    string fullPathArchivoIntercambio = string.Empty;
                    for (int i = 0; i < 2; i++)
                    {
                        string carpetaEDICOM33 = Path.Combine(this.PathEdicomTrabajo, respuesta.RfcEmisor, "Procesado", "TXTUniversal", respuesta.FechaProceso.Year.ToString(), respuesta.FechaProceso.Month.ToString("00"), respuesta.FechaProceso.Day.ToString("00"));
                        fullPathArchivoIntercambio = Path.Combine(carpetaEDICOM33, nombreArchivo);

                        if (File.Exists(fullPathArchivoIntercambio))
                            break;
                    }

                    if (File.Exists(fullPathArchivoIntercambio))
                    {
                        var lineasArchivo = File.ReadAllLines(fullPathArchivoIntercambio).Select((o, i) => new Linea { Contenido = o, Indice = i }).ToList();

                        var ReceptorFiscal = lineasArchivo.Where(l => l.Contenido.Contains("[ReceptorFiscal]")).FirstOrDefault();
                        string[] columnasReceptor = ReceptorFiscal.Contenido.Split('|');
                        columnasReceptor[1] = this.RfcGenerico;

                        lineasArchivo[ReceptorFiscal.Indice].Contenido = string.Join("|", columnasReceptor);

                        List<string> lineasUpdt = lineasArchivo.Select(l => l.Contenido).ToList();

                        string pathInsumosCfdi = Path.Combine(this.PathInsumosCFDI, nombreArchivo);
                        File.WriteAllLines(pathInsumosCfdi, lineasUpdt);

                        int _numCia = int.Parse(cia.Substring(0, 3));
                        SaveBitacora(_numCia, folio, "", observaciones, serie, usuario, "InsertaRfc", false, "");

                        return new
                        {
                            estatus = "OK"
                        };
                    }
                    else
                    {
                        return new
                        {
                            estatus = "ERROR",
                            mensaje = "No se encontró ningun archivo de intercambio relacionado al folio ingresado"
                        };
                    }
                }
                else
                {
                    return new
                    {
                        estatus = "ERROR",
                        mensaje = "No se encontraron registros con error en Rfc del folio ingresado"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    estatus = "ERROR",
                    mensaje = ex.Message
                };
            }
        }

        public void SaveBitacora(int cia, long folio, string nombreArchivo, string observaciones, string serie, int idUsuario, string proceso, bool esRetransmisionXml, string estatus, string error = "")
        {
            Bitacora oBitacora = new Bitacora();
            oBitacora.Cia = cia;
            oBitacora.FechaAlta = DateTime.Now;
            oBitacora.Folio = folio;
            oBitacora.NombreArchivo = nombreArchivo;
            oBitacora.Observaciones = observaciones;
            oBitacora.Serie = serie;
            oBitacora.IdUsuario = idUsuario;
            oBitacora.Proceso = proceso;
            if (esRetransmisionXml)
                oBitacora.Estatus = estatus;

            if (!string.IsNullOrEmpty(error))
                oBitacora.Error = error;

            this._context.Bitacora.Add(oBitacora);
            this._context.SaveChanges();
        }
    }
}
