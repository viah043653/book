﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Soporte.HerdezV2.Validates.BI;

namespace Soporte.HerdezV2.Controllers
{
    [Authorize]
    [Produces("application/json")]
    [Route("api/EnviosTiendas")]    
    public class EnviosTiendasController : Controller
    {
        // POST api/values
        [Route("~/api/PostEntTie")]
        [HttpPost]
        public ValidateEnviosTiendas.Respuesta PostEntTie(string folio)
        {
            ValidateEnviosTiendas validateenttie = new ValidateEnviosTiendas();
            return validateenttie.GetEntTie(folio);
        }
    }
}