﻿namespace Soporte.HerdezV2.Models.Generic
{
    using System;
    using System.IO;
    using System.Security.Cryptography;
    using System.Text;
    
    public class Autenticacion
    {
        public string Salt { get; set; }
        public string Hash { get; set; }

        internal string DecryptedUser { get; private set; }
        internal string DecryptedPassword { get; private set; }

        internal const string _key = "9889276456839648";
        internal const string _iv = "9889276456839648";

        /// <summary>
        /// Descifra usuario y contraseña
        /// </summary>
        public void Decrypt()
        {
            this.DecryptedUser = this.DecryptStringAES(this.Salt);
            this.DecryptedPassword = this.DecryptStringAES(this.Hash);
        }

        /// <summary>
        /// Descifra cadena
        /// </summary>
        /// <param name="cipherText"></param>
        /// <returns></returns>
        private string DecryptStringAES(string cipherText)
        {
            var keybytes = Encoding.UTF8.GetBytes(_key);
            var iv = Encoding.UTF8.GetBytes(_iv);

            var encrypted = Convert.FromBase64String(cipherText);
            var decriptedFromJavascript = DecryptStringFromBytes(encrypted, keybytes, iv);
            return string.Format(decriptedFromJavascript);
        }

        /// <summary>
        /// Descifra arreglo de bytes con key
        /// </summary>
        /// <param name="cipherText"></param>
        /// <param name="key"></param>
        /// <param name="iv"></param>
        /// <returns></returns>
        private string DecryptStringFromBytes(byte[] cipherText, byte[] key, byte[] iv)
        {
            string plaintext = null;
            
            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (key == null || key.Length <= 0)
                throw new ArgumentNullException("key");
            if (iv == null || iv.Length <= 0)
                throw new ArgumentNullException("key");

            using (var rijAlg = new RijndaelManaged())
            {
                rijAlg.Mode = CipherMode.CBC;
                rijAlg.Padding = PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;
                rijAlg.Key = key;
                rijAlg.IV = iv;

                using (var msDecrypt = new MemoryStream(cipherText))
                {
                    using (var csDecrypt = new CryptoStream(msDecrypt, rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV), CryptoStreamMode.Read))
                    {
                        using (var srDecrypt = new StreamReader(csDecrypt))
                            plaintext = srDecrypt.ReadToEnd();
                    }
                }
            }

            return plaintext;
        }
    }
}
