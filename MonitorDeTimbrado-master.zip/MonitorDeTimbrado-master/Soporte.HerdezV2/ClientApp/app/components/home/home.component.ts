﻿import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';

import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';

@Component({
    providers: [SharedService],
    selector: 'home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.style.css']
})
export class HomeComponent implements OnInit {

    pacs: number[] = [1];
    //public pacsStatus: any[] = [];
    height: string = '';

    message: string;
    mostrarPdfs: boolean = false;

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private router: Router, public sharedservice: SharedService, private localStorageService: LocalStorageService) {
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnInit() {
        debugger
        let userData = this.localStorageService.GetAuthorizationData();

        this.mostrarPdfs = false;

        let vistasUnicas = userData._userData.ngViews.vistasUnicas;
        if (vistasUnicas.length > 0) {
            for (let vista of vistasUnicas) {
                if (vista.idPantalla === 1) {
                    let _acciones = JSON.parse(vista.acciones);
                    for (let _accion of _acciones) {
                        if (_accion.nombreAccion == "PostPDF")
                            this.mostrarPdfs = true;
                    }
                }
            }
        }

        this.router.navigate(['/monitor/dashboard']);
        this.setStyles();
    }

    setStyles() {
        let minHeight = window.screen.height - 133;
        this.height = minHeight.toString() + 'px';
    }
}