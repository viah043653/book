﻿namespace Soporte.HerdezV2.Controllers
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Authorization;
    using System.Collections;
    using Soporte.HerdezV2.Validates.BI;

    [Authorize]
    [Produces("application/json")]
    [Route("api/Bitacora")]
    public class BitacoraController : Controller
    {
        ValidateBitacora validateBitacora = new ValidateBitacora();

        [Route("~/api/GetRetransmisionXmlHistorico")]
        [HttpGet]
        public IEnumerable GetRetransmisionXmlHistorico()
        {
            validateBitacora = new ValidateBitacora();
            var result = this.validateBitacora.GetRetransmisionClienteHistorico();

            return result;
        }

        [Route("~/api/PostBitacoraHistorico")]
        [HttpPost]
        public IEnumerable PostBitacoraHistorico()
        {
            string proceso = HttpContext.Request.Form["Procesos"];

            validateBitacora = new ValidateBitacora();
            var result = this.validateBitacora.PostBitacoraHistorico(proceso);

            return result;
        }
    }
}