﻿//------------------------------------------------------------------------------
// <generado automáticamente>
//     Este código fue generado por una herramienta.
//     //
//     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
//     se vuelve a generar el código.
// </generado automáticamente>
//------------------------------------------------------------------------------

namespace wsSoriana
{
    
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.ServiceModel.ServiceContractAttribute(Namespace="http://www.sci-grupo.com.mx/", ConfigurationName="wsSoriana.wseDocReciboSoap")]
    public interface wseDocReciboSoap
    {
        
        [System.ServiceModel.OperationContractAttribute(Action="http://www.sci-grupo.com.mx/RecibeCFD", ReplyAction="*")]
        System.Threading.Tasks.Task<wsSoriana.RecibeCFDResponse> RecibeCFDAsync(wsSoriana.RecibeCFDRequest request);
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class RecibeCFDRequest
    {
        
        [System.ServiceModel.MessageBodyMemberAttribute(Name="RecibeCFD", Namespace="http://www.sci-grupo.com.mx/", Order=0)]
        public wsSoriana.RecibeCFDRequestBody Body;
        
        public RecibeCFDRequest()
        {
        }
        
        public RecibeCFDRequest(wsSoriana.RecibeCFDRequestBody Body)
        {
            this.Body = Body;
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.Runtime.Serialization.DataContractAttribute(Namespace="http://www.sci-grupo.com.mx/")]
    public partial class RecibeCFDRequestBody
    {
        
        [System.Runtime.Serialization.DataMemberAttribute(EmitDefaultValue=false, Order=0)]
        public string XMLCFD;
        
        public RecibeCFDRequestBody()
        {
        }
        
        public RecibeCFDRequestBody(string XMLCFD)
        {
            this.XMLCFD = XMLCFD;
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class RecibeCFDResponse
    {
        
        [System.ServiceModel.MessageBodyMemberAttribute(Name="RecibeCFDResponse", Namespace="http://www.sci-grupo.com.mx/", Order=0)]
        public wsSoriana.RecibeCFDResponseBody Body;
        
        public RecibeCFDResponse()
        {
        }
        
        public RecibeCFDResponse(wsSoriana.RecibeCFDResponseBody Body)
        {
            this.Body = Body;
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.Runtime.Serialization.DataContractAttribute(Namespace="http://www.sci-grupo.com.mx/")]
    public partial class RecibeCFDResponseBody
    {
        
        [System.Runtime.Serialization.DataMemberAttribute(EmitDefaultValue=false, Order=0)]
        public string RecibeCFDResult;
        
        public RecibeCFDResponseBody()
        {
        }
        
        public RecibeCFDResponseBody(string RecibeCFDResult)
        {
            this.RecibeCFDResult = RecibeCFDResult;
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    public interface wseDocReciboSoapChannel : wsSoriana.wseDocReciboSoap, System.ServiceModel.IClientChannel
    {
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    public partial class wseDocReciboSoapClient : System.ServiceModel.ClientBase<wsSoriana.wseDocReciboSoap>, wsSoriana.wseDocReciboSoap
    {
        
    /// <summary>
    /// Implemente este método parcial para configurar el punto de conexión de servicio.
    /// </summary>
    /// <param name="serviceEndpoint">El punto de conexión para configurar</param>
    /// <param name="clientCredentials">Credenciales de cliente</param>
    static partial void ConfigureEndpoint(System.ServiceModel.Description.ServiceEndpoint serviceEndpoint, System.ServiceModel.Description.ClientCredentials clientCredentials);
        
        public wseDocReciboSoapClient(EndpointConfiguration endpointConfiguration) : 
                base(wseDocReciboSoapClient.GetBindingForEndpoint(endpointConfiguration), wseDocReciboSoapClient.GetEndpointAddress(endpointConfiguration))
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public wseDocReciboSoapClient(EndpointConfiguration endpointConfiguration, string remoteAddress) : 
                base(wseDocReciboSoapClient.GetBindingForEndpoint(endpointConfiguration), new System.ServiceModel.EndpointAddress(remoteAddress))
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public wseDocReciboSoapClient(EndpointConfiguration endpointConfiguration, System.ServiceModel.EndpointAddress remoteAddress) : 
                base(wseDocReciboSoapClient.GetBindingForEndpoint(endpointConfiguration), remoteAddress)
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public wseDocReciboSoapClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) : 
                base(binding, remoteAddress)
        {
        }
        
        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        System.Threading.Tasks.Task<wsSoriana.RecibeCFDResponse> wsSoriana.wseDocReciboSoap.RecibeCFDAsync(wsSoriana.RecibeCFDRequest request)
        {
            return base.Channel.RecibeCFDAsync(request);
        }
        
        public System.Threading.Tasks.Task<wsSoriana.RecibeCFDResponse> RecibeCFDAsync(string XMLCFD)
        {
            wsSoriana.RecibeCFDRequest inValue = new wsSoriana.RecibeCFDRequest();
            inValue.Body = new wsSoriana.RecibeCFDRequestBody();
            inValue.Body.XMLCFD = XMLCFD;
            return ((wsSoriana.wseDocReciboSoap)(this)).RecibeCFDAsync(inValue);
        }
        
        public virtual System.Threading.Tasks.Task OpenAsync()
        {
            return System.Threading.Tasks.Task.Factory.FromAsync(((System.ServiceModel.ICommunicationObject)(this)).BeginOpen(null, null), new System.Action<System.IAsyncResult>(((System.ServiceModel.ICommunicationObject)(this)).EndOpen));
        }
        
        public virtual System.Threading.Tasks.Task CloseAsync()
        {
            return System.Threading.Tasks.Task.Factory.FromAsync(((System.ServiceModel.ICommunicationObject)(this)).BeginClose(null, null), new System.Action<System.IAsyncResult>(((System.ServiceModel.ICommunicationObject)(this)).EndClose));
        }
        
        private static System.ServiceModel.Channels.Binding GetBindingForEndpoint(EndpointConfiguration endpointConfiguration)
        {
            if ((endpointConfiguration == EndpointConfiguration.wseDocReciboSoap))
            {
                System.ServiceModel.BasicHttpBinding result = new System.ServiceModel.BasicHttpBinding();
                result.MaxBufferSize = int.MaxValue;
                result.ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max;
                result.MaxReceivedMessageSize = int.MaxValue;
                result.AllowCookies = true;
                return result;
            }
            if ((endpointConfiguration == EndpointConfiguration.wseDocReciboSoap12))
            {
                System.ServiceModel.Channels.CustomBinding result = new System.ServiceModel.Channels.CustomBinding();
                System.ServiceModel.Channels.TextMessageEncodingBindingElement textBindingElement = new System.ServiceModel.Channels.TextMessageEncodingBindingElement();
                textBindingElement.MessageVersion = System.ServiceModel.Channels.MessageVersion.CreateVersion(System.ServiceModel.EnvelopeVersion.Soap12, System.ServiceModel.Channels.AddressingVersion.None);
                result.Elements.Add(textBindingElement);
                System.ServiceModel.Channels.HttpTransportBindingElement httpBindingElement = new System.ServiceModel.Channels.HttpTransportBindingElement();
                httpBindingElement.AllowCookies = true;
                httpBindingElement.MaxBufferSize = int.MaxValue;
                httpBindingElement.MaxReceivedMessageSize = int.MaxValue;
                result.Elements.Add(httpBindingElement);
                return result;
            }
            throw new System.InvalidOperationException(string.Format("No se pudo encontrar un punto de conexión con el nombre \"{0}\".", endpointConfiguration));
        }
        
        private static System.ServiceModel.EndpointAddress GetEndpointAddress(EndpointConfiguration endpointConfiguration)
        {
            if ((endpointConfiguration == EndpointConfiguration.wseDocReciboSoap))
            {
                return new System.ServiceModel.EndpointAddress("http://serviciosweb.soriana.com/RecibeCfd/wseDocRecibo.asmx");
            }
            if ((endpointConfiguration == EndpointConfiguration.wseDocReciboSoap12))
            {
                return new System.ServiceModel.EndpointAddress("http://serviciosweb.soriana.com/RecibeCfd/wseDocRecibo.asmx");
            }
            throw new System.InvalidOperationException(string.Format("No se pudo encontrar un punto de conexión con el nombre \"{0}\".", endpointConfiguration));
        }
        
        public enum EndpointConfiguration
        {
            
            wseDocReciboSoap,
            
            wseDocReciboSoap12,
        }
    }
}
