﻿namespace AddendaPlanaCS
{
    using System;
    using System.Configuration;
    using System.IO;
    using System.Xml;
    using System.Xml.Xsl;

    class Program
    {
        static void Main(string[] args)
        {
            string
                xsltString = File.ReadAllText(ConfigurationManager.AppSettings["xsltPath"], System.Text.Encoding.UTF8),
                pathXmlUniversal = args[0];

            string xmlUniversal = File.ReadAllText(pathXmlUniversal);

            XsltSettings settings = new XsltSettings();
            settings.EnableScript = true;

            XslCompiledTransform transform = new XslCompiledTransform();
            using (XmlReader reader = XmlReader.Create(new StringReader(xsltString)))
                transform.Load(reader, settings, null);

            StringWriter results = new StringWriter();
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlUniversal)))
                transform.Transform(reader, null, results);
            Console.WriteLine(results.ToString());
        }
    }
}
