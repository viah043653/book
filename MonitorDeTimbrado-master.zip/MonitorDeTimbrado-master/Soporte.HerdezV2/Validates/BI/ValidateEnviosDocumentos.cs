﻿namespace Soporte.HerdezV2.Validates.BI
{
    using Dapper;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml;
    using System.Xml.Serialization;

    public class ValidateEnviosDocumentos : Connect
    {
        public class Respuesta
        {
            public string Mensajeerror { get; set; }
            public bool Statuss { get; set; }
            public List<dynamic> Listadatos { get; set; }
        }

        public Respuesta GetEntXFolio(Int32 cia, string serie, Int32 folio)
        {
            Respuesta generall = new Respuesta();
            try
            {

                generall.Listadatos = new List<dynamic>();

                var paref = new DynamicParameters();
                paref.Add("@cia", cia, DbType.Int32);
                paref.Add("@serie", serie, DbType.String);
                paref.Add("@folio", folio, DbType.Int32);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                {
                    generall.Listadatos = db.Query<dynamic>("sp_ConsultaEntregasPorFolio", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                }
                generall.Statuss = true;


            }
            catch (Exception ex)
            {
                generall.Statuss = false;
                generall.Mensajeerror = ex.Message;
            }
            return generall;

        }
    }
}
