﻿namespace Soporte.HerdezV2.Models.Generic
{
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Xml;
    using System.Xml.Serialization;

    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class Busqueda
    {
        private List<BusquedaDocumento> documentoField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Documento")]
        public List<BusquedaDocumento> Documento
        {
            get
            {
                return this.documentoField;
            }
            set
            {
                this.documentoField = value;
            }
        }

        public string GetXml<T>(T objct)
        {
            string xmlCFDIResultField = string.Empty;
            XmlDocument xmlCFDI = new XmlDocument();
            var xmlSerializer = new XmlSerializer(typeof(T));

            XmlWriterSettings settings = new XmlWriterSettings()
            {
                Encoding = new UnicodeEncoding(false, false),
                Indent = false,
                OmitXmlDeclaration = false
            };

            using (StringWriter sWriter = new StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(sWriter, settings))
                {
                    xmlSerializer.Serialize(sWriter, objct, null);
                    xmlCFDI.LoadXml(sWriter.ToString());
                }
            }
            xmlCFDIResultField = xmlCFDI.InnerXml;
            using (MemoryStream mStream = new MemoryStream())
            {
                using (XmlTextWriter writer = new XmlTextWriter(mStream, Encoding.UTF8))
                {
                    XmlDocument document = new XmlDocument();
                    document.LoadXml(xmlCFDI.InnerXml);

                    writer.Formatting = System.Xml.Formatting.Indented;

                    document.WriteContentTo(writer);
                    writer.Flush();

                    mStream.Flush();
                    mStream.Position = 0;

                    using (StreamReader sReader = new StreamReader(mStream, Encoding.UTF8))
                        xmlCFDIResultField = sReader.ReadToEnd();
                }
            }
            return xmlCFDIResultField;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class BusquedaDocumento
    {

        private string serieField;

        private int ciaField;

        private long folioField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Serie
        {
            get
            {
                return this.serieField;
            }
            set
            {
                this.serieField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public int Cia
        {
            get
            {
                return this.ciaField;
            }
            set
            {
                this.ciaField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public long Folio
        {
            get
            {
                return this.folioField;
            }
            set
            {
                this.folioField = value;
            }
        }
    }

    public partial class BusquedaCamest
    {

        private string serieField;

        private int folioField;

        private int estatusField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Serie
        {
            get
            {
                return this.serieField;
            }
            set
            {
                this.serieField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public int Folio
        {
            get
            {
                return this.folioField;
            }
            set
            {
                this.folioField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public int Estatus
        {
            get
            {
                return this.estatusField;
            }
            set
            {
                this.estatusField = value;
            }
        }
    }
}