﻿namespace Soporte.HerdezV2.Controllers.HangFire
{
    using System;
    using System.Linq;
    using Hangfire;
    using Hangfire.Storage;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.HangFire;

    [Produces("application/json")]
    [Route("apiHangFire/LecturaXml")]
    public class LecturaXmlController : Controller
    {
        private const string taskLectura = "TSKLecturaXml";

        // GET: apiHangFire/LecturaXml/Iniciar
        [HttpGet("Iniciar")]
        public IActionResult StartLectura()
        {
            string mensaje = string.Empty;

            //using (var connection = JobStorage.Current.GetConnection())
            //{
            //    string lastRunResult = string.Empty;
            //    var recurringJobs = connection.GetRecurringJobs();
            //    var job = recurringJobs.FirstOrDefault(p => p.Id.Equals(taskLectura, StringComparison.InvariantCultureIgnoreCase));
            //    if (job != null)
            //        mensaje = string.IsNullOrEmpty(job.LastJobId) ? "Servicio para lectura de Xml iniciado" : "El servicio para lectura de Xml ya se encuentra activo";
            //    else
            //        mensaje = "Servicio para lectura de Xml iniciado";
            //}

            //if (mensaje == "Servicio para lectura de Xml iniciado")
            //{
            //    RecurringJob.RemoveIfExists(taskLectura);
            //    ValidateHfLecturaXml validateStart = new ValidateHfLecturaXml();
            //    RecurringJob.AddOrUpdate(taskLectura, () => validateStart.StartLecturaXml(), Cron.MinuteInterval(15));
            //}

            ValidateHfLecturaXml validateStart = new ValidateHfLecturaXml();
            validateStart.StartLecturaXml();

            return Ok(mensaje);
        }

        // GET: apiHangFire/LecturaXml/Detener
        [HttpGet("Detener")]
        public IActionResult StopProcess()
        {
            RecurringJob.RemoveIfExists(taskLectura);
            return Ok("Servicio para lectura de Xml detenido");
        }
    }
}