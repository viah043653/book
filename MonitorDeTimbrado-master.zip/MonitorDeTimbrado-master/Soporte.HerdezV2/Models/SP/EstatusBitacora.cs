﻿namespace Soporte.HerdezV2.Models.SP
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class BitacoraSp
    {
        public string Rfc { get; set; }
        public string Serie { get; set; }
        public long Folio { get; set; }
        public string Proceso { get; set; }
        public string NombreArchivo { get; set; }
        public string Estatus { get; set; }
        public string Observaciones { get; set; }
        public string Error { get; set; }
        public DateTime FechaAlta { get; set; }
        public string NombreUsuario { get; set; }
    }

    public class EstatusBitacora
    {
        public string Emisor { get; set; }
        public string Receptor { get; set; }
        public string Serie { get; set; }
        public Int64 Folio { get; set; }
        public string Estatus { get; set; }
        public string Mensaje { get; set; }
        public string Contenido { get; set; }
        public DateTime FechaProceso { get; set; }
        public string HistorialBitacora { get; set; }

        public IEnumerable<HistoricoBitacora> GetBitacora()
        {
            List<string> registros = this.HistorialBitacora.Split(new string[] { "$*" }, StringSplitOptions.None).ToList();
            foreach (string registro in registros)
            {
                string[] columnas = registro.Split('|');
                yield return new HistoricoBitacora()
                {
                    Proceso = columnas[0].TrimStart(),
                    Observaciones = columnas[1],
                    FechaProceso = /*string.IsNullOrEmpty(columnas[2]) ? null : */Convert.ToDateTime(columnas[2]),
                    Usuario = columnas[3]
                };
            }
        }
    }

    public class HistoricoBitacora
    {
        public string Proceso { get; set; }
        public string Observaciones { get; set; }
        public DateTime? FechaProceso { get; set; }
        public string Usuario { get; set; }
    }
}