﻿namespace Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui
{
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Xml;

    public class Factura : Folio
    {
        public string RfcEmisor { get; set; }
        public int Cia { get; set; }
        public List<Nota> Notas { get; set; }

        public Factura(dynamic facData)
        {
            this.RfcEmisor = facData.RFC_Emisor;
            this.Cia = facData.Cia;
            this.Serie = facData.Serie;
            this.Numero = facData.Folio;
            this.Importe = facData.C25IMP == null ? 0 : facData.C25IMP;
            this.FechaProceso = facData.MxFechaProceso;
            this.Uuid = facData.MxMensaje;

            SetName();
        }

        public static List<Factura> GetFacturaRelacionada(List<dynamic> facturasRelacionadasNc)
        {
            List<Factura> FacturasGrpAS400 = facturasRelacionadasNc.
                GroupBy(f => new { f.Cia, f.Serie, f.Folio }).
                Select(f =>
                {
                    Factura factura = new Factura(f.Where(x => x.SerieNC_CV == "FACTURA" || x.SerieNC_CV == null).FirstOrDefault());
                    factura.Notas = f.Where(x => x.SerieNC_CV != "FACTURA").Select(x => new Nota(x)).ToList();
                    return factura;
                }).ToList();

            foreach (Factura f in FacturasGrpAS400)
            {
                foreach (Nota n in f.Notas)
                {
                    if (n._Estatus == Folio.Estatus.Timbrado)// && n.Serie != "D")
                    {
                        string fullPathNC = string.Format("{0}{1}", n.PathXml, n.NombreArchivoXml);
                        if (File.Exists(fullPathNC))
                        {
                            XmlDocument xmlNC = new XmlDocument();
                            xmlNC.Load(fullPathNC);

                            string fic = ReadAdenda(xmlNC.GetElementsByTagName("cfdi:Addenda"));
                            n.FolioFic = fic;

                            n.Uuid = ((XmlElement)xmlNC.GetElementsByTagName("tfd:TimbreFiscalDigital")[0]).GetAttribute("UUID");

                            n._EstatusLecturaXml = EstatusLecturaXml.Localizado;
                        }
                        else
                            n._EstatusLecturaXml = EstatusLecturaXml.NoLocalizado;
                    }
                }
            }

            return FacturasGrpAS400;
        }

        static string ReadAdenda(XmlNodeList nodosAdenda)
        {
            for (int i = 0; i < nodosAdenda.Count; i++)
                if (nodosAdenda[i].InnerXml.Contains("lev1add:EDCINVOICE"))
                    nodosAdenda[i].ParentNode.RemoveChild(nodosAdenda[i]);

            if (nodosAdenda[0].InnerXml.Contains("<requestForPayment "))
                return GetFic(nodosAdenda[0].ChildNodes[0].ChildNodes);

            return string.Empty;
        }

        static string GetFic(XmlNodeList adendaNodos)
        {
            foreach (XmlElement x in adendaNodos)
                if (x.Name == "orderIdentification")
                    return x.GetElementsByTagName("referenceIdentification")[0].InnerText;

            return string.Empty;
        }
    }
}
