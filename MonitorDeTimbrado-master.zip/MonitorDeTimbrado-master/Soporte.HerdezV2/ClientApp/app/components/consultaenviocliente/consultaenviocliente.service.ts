﻿import { Injectable } from "@angular/core";
import { NgIf } from '@angular/common';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class ConsultaEnvioClienteService {

    private baseUrl: string = '';

    constructor(private httpClient: HttpClient) {
        this.baseUrl = '/api/';
    }

    public GetClientes() {
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.get<any[]>(`${this.baseUrl}GetClientesEnvios`, { headers: headers });
    }

    public GetEnvios(filtro: any) {
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any[]>(`${this.baseUrl}PostEnviosClientes`, filtro, { headers: headers });
    }

    public GetDatosExcel(filtro: any) {
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any[]>(`${this.baseUrl}DescargarReporteEntregas`, filtro, { headers: headers });
    }
}
