﻿import { Component, ViewChild, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { RefacturacionesService } from './refacturaciones.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { EnvioIntercambioService } from '../enviointercambio/enviointercambio.service'
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';
import { animate, state, style, transition, trigger } from '@angular/animations';

import 'rxjs/add/operator/takeUntil';

@Component({
    providers: [RefacturacionesService, SharedService, EnvioIntercambioService],
    selector: 'refacturaciones',
    templateUrl: './refacturaciones.component.html',
    styleUrls: ['./refacturaciones.style.css'],
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
            state('expanded', style({ height: '*', visibility: 'visible' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ]
})

export class RefacturacionesComponent implements OnInit, OnDestroy {

    private VIEW_ID: number = 17;

    cia: string = '';
    serie: string = '';
    folio: number = 0;

    motivoCancelacion: string = '';
    motivoCancelacionID: number = 0;

    ciaID: string = '';
    serieID: string = '';

    isActionButtonsVisible: boolean = false;
    ShowSpinnerTable: boolean = true;
    ShowSpinnerDetalleSolicitud: boolean = false;
    isSearchCleanVisible: boolean = false;

    displayedColumns = ['Solicitud', 'RfcEmisor', 'NombreUsuarioSolicitante', 'DescripcionMotivosCancelacion', 'CantidadDeDocumentos', 'DocumentosProcesados', 'FechaAlta', 'EstatusSolicitud', 'Botones'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
    expandedElement: any;

    displayedColumnsDocNoEncontrados = ['RfcCia', 'Serie', 'Folio']
    dataSourceDocNoEncontrados = new MatTableDataSource<any>();

    displayedColumnsFacConDocRelacionado = ['RfcCia', 'Factura', 'DocumentoRelacionado']
    dataSourceFacConDocRelacionado = new MatTableDataSource<any>();

    displayedColumnsDocEnProceso = ['RfcCia', 'Folio', 'Serie', 'FechaProceso', 'SolicitudActiva', 'EstatusDocumento']
    dataSourceDocEnProceso = new MatTableDataSource<any>();

    displayedColumnsDocExcesoDeCancelaciones = ['RfcCia', 'Serie', 'Folio', 'SolicitudDeCancelaciones']
    dataSourceDocExcesoDeCancelaciones = new MatTableDataSource<any>();

    displayedColumnsDocCancelados = ['RfcCia', 'Serie', 'Folio']
    dataSourceDocCancelados = new MatTableDataSource<any>();

    displayedColumnsDetalleSolicitud = ['Documento', 'UuidCancela', 'Estatus', 'FechaModificacion', 'ProgresBar', 'Botones']
    dataSourceDetalleSolicitud = new MatTableDataSource<any>();

    switchPreparaBD: boolean = false;
    switchCancelaEDIWIN: boolean = false;

    showMasiva: boolean = false;
    showResultadosSolicitudMasiva: boolean = false;
    showDetalleSolicitud: boolean = false;

    solicitudDetalle: any = {
        Numero: '',
        FechaSolicitud: '',
        Emisor: '',
        CantidadDeDocumentos: 0
    };

    filterValue: string = '';

    archivoExcel: any = {
        NombreArchivo: '',
        Archivo: null
    };

    solicitudRespuesta: any = {
        EsSolicitudCreada: false,
        MensajeEstatusSolicitud: 'Solicitud creada',
        DocumentosNoEncotrados: [],
        DocumentosEnProceso: [],
        FoliosExcesoCancelacion: [],
        FoliosCancelados: [],
        FoliosInsertados: 0,
        IdSolicitud: 0,
        IdSolicitudString: '',
        FacturasConDocumentoRelacionado: []
    };

    companias: any[] = [
        { rfc: 'CHE041201L59', nombre: 'COMPAÑIA COMERCIAL HERDEZ S.A. DE C.V.', numero: '60' },
        { rfc: 'NUT840801733', nombre: 'NUTRISA S.A DE C.V.', numero: '77' },
        { rfc: 'OCO160809URA', nombre: 'OLYEN COFFEE', numero: '92' },
        { rfc: 'HER8301121X4', nombre: 'HERDEZ S.A DE C.V.', numero: '1' },
        { rfc: 'HER980609NC1', nombre: 'HERSEA', numero: '43' },
        { rfc: 'KSN200902B97', nombre: "KI'TAL SNACKS, S. A. DE C. V.", numero: '95' },
        { rfc: 'ROC020422UV9', nombre: 'RC OPERADORA DE CAFETERIAS SA DE CV', numero: '102' }
    ];

    solicitudes: any[] = [];

    mostrarAcciones: boolean = false;
    accionRefacturacion: boolean = false;
    accionCancelacion: boolean = false;
    accionesConfiguradas: boolean = false;

    tiposDeDocumentos: any[] = [];
    motivosDeCancelacion: any[] = [];

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService, public refacturacionesService: RefacturacionesService, public sharedservice: SharedService, public localstorageservice: LocalStorageService, public enviointercambioservice: EnvioIntercambioService, public dialog: MatDialog) {
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() {

        debugger
        this.motivoCancelacion = '';

        this.tiposDeDocumentos = [];
        this.motivosDeCancelacion = [];
        this.refacturacionesService.GetMotivosDeCancelacion().
            subscribe(
                (data) => {
                    debugger
                    this.tiposDeDocumentos = data;
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {});

        
        //this.sharedservice.GetTiposDeDocumentos().
        //    subscribe(
        //        (data) => {
        //            debugger
        //            this.tiposDeDocumentos = data;
        //        },
        //        response => {
        //            this.sharedservice.catchHttpResponseError(response);
        //        },
        //        () => {
        //            this.spinnerService.hide();
        //        });

        this.mostrarAcciones = false;
        this.accionCancelacion = false;
        this.accionRefacturacion = false;
        this.accionesConfiguradas = false;

        this.switchCancelaEDIWIN = false;
        this.switchPreparaBD = false;

        let dataActions = this.localstorageservice.GetActions(this.VIEW_ID)

        for (let action of dataActions) {
            switch (action.numeroAccion) {
                case 22:
                    this.accionRefacturacion = true;
                    this.switchPreparaBD = true;
                    break;
                case 23:
                    this.accionCancelacion = true;
                    this.switchCancelaEDIWIN = true;
                    break;
            }
        }

        this.mostrarAcciones = this.accionCancelacion && this.accionRefacturacion;
        this.accionesConfiguradas = this.accionCancelacion || this.accionRefacturacion;

        if (this.mostrarAcciones) {
            this.switchPreparaBD = true;
            this.switchCancelaEDIWIN = false;
        }

        this.getRegeneracionList();
        Observable.interval(2000 * 60).takeUntil(this.onDestroy$).subscribe(x => {
            this.getRegeneracionList();
        });
    }

    setCia(_cia: any) {
        this.cia = _cia.rfc + " - " + _cia.nombre;
        this.ciaID = _cia.rfc;
    }

    setSerie(data: any) {
        debugger;
        this.serie = data.Serie + ' - ' + data.Descripcion;
        this.serieID = data.Serie;

        this.motivosDeCancelacion = [];

        this.motivosDeCancelacion = JSON.parse(data.MotivosDeCancelacion).Motivos;
        this.motivoCancelacion = this.motivosDeCancelacion[0].Descripcion;
        this.motivoCancelacionID = this.motivosDeCancelacion[0].IdMotivoDeCancelacion;
    }

    setMotivoDeCancelacion(_motivo: any) {
        debugger;
        this.motivoCancelacion = _motivo.Descripcion;
        this.motivoCancelacionID = _motivo.IdMotivoDeCancelacion;
    }

    getExcelFile(event: any) {
        debugger
        var file = event.target.files[0];

        this.archivoExcel = {
            NombreArchivo: file.name,
            Archivo: file
        };
    }

    limpiarInputFile() {
        let inpFileElement: HTMLInputElement = document.getElementById('inpFileExcel') as HTMLInputElement;
        inpFileElement.value = '';

        this.archivoExcel = {
            NombreArchivo: '',
            Archivo: null
        };
    }

    setAccion(idAccion: number) {
        switch (idAccion) {
            case 1:
                this.switchCancelaEDIWIN = this.switchPreparaBD;
                break;
            case 2:
                this.switchPreparaBD = this.switchCancelaEDIWIN;
                break;
        }
    }

    copyToClipboard(data: string) {
        var newTextArea = document.createElement('textarea');

        document.body.appendChild(newTextArea);

        newTextArea.value = data;
        newTextArea.select();

        document.execCommand('copy');

        this.toastr.info(data, 'Texto copiado al Portapapeles');

        document.body.removeChild(newTextArea);
    }

    mostrarDocumentosRelacionados(element: any) {
        debugger
        this.ShowSpinnerDetalleSolicitud = true;
        this.showDetalleSolicitud = true;

        this.solicitudDetalle = {
            Numero: element.SolicitudString,
            FechaSolicitud: element.FechaAlta,
            Emisor: element.Rfc_Serie.split('-')[0],
            CantidadDeDocumentos: element.CantidadDeDocumentos,
            IdStatusSolicitud: element.IdStatusSolicitud,
            DescripcionStatusSolicitud: element.DescripcionStatusSolicitud,
            CantidadDeDocumentosPendientes: 0,
            CantidadDeDocumentosCancelados: 0,
            CantidadDeDocumentosRechazados: 0,
            CantidadDeDocumentosNoCancelables: 0
        };

        this.refacturacionesService.
            GetDocumentosPorSolicitud(element.Solicitud).
            subscribe(
                (data) => {
                    debugger

                    if (data.estatus == 'OK') {

                        let dataResult: any[] = [];
                        for (let dat of data.documentos) {
                            var datDocument = dat;
                            datDocument.JsonAcuse = datDocument.Acuse == null ? null : JSON.parse(datDocument.Acuse);

                            if (dat.IdStatus == 1004)
                                this.solicitudDetalle.CantidadDeDocumentosCancelados = this.solicitudDetalle.CantidadDeDocumentosCancelados + 1;
                            else if (dat.IdStatus == 1005)
                                this.solicitudDetalle.CantidadDeDocumentosRechazados = this.solicitudDetalle.CantidadDeDocumentosRechazados + 1;
                            else if (dat.IdStatus == 1006)
                                this.solicitudDetalle.CantidadDeDocumentosNoCancelables = this.solicitudDetalle.CantidadDeDocumentosNoCancelables + 1;
                            else
                                this.solicitudDetalle.CantidadDeDocumentosPendientes = this.solicitudDetalle.CantidadDeDocumentosPendientes + 1;

                            dataResult.push(datDocument);
                        }

                        this.dataSourceDetalleSolicitud = new MatTableDataSource(dataResult);
                        this.dataSourceDetalleSolicitud.paginator = this.paginator;
                        this.dataSourceDetalleSolicitud.sort = this.sort;

                    }
                    else {
                        this.toastr.error(data.mensaje, 'Error');
                    }
                },
                response => {
                    this.ShowSpinnerDetalleSolicitud = false;
                    this.sharedservice.catchHttpResponseError(response);
                },
                () =>
                {
                    this.ShowSpinnerDetalleSolicitud = false;
                });
    }

    detalleSeguimiento(bitacora: any) {
        debugger
        let desgloze: any[] = [];

        desgloze.push(
            {
                IdStatus: 1001,
                UuidCancela: bitacora.UuidCancela,
                CssStyle: 'fa fa-lock bg-black',
                SolicitudesDeCancelacion: bitacora.SolicitudesDeCancelacion,
                FechaProceso: this.solicitudDetalle.FechaSolicitud,
                DescripcionStatus: 'En espera de procesamiento'//bitacora.DescripcionStatus
            });

        switch (bitacora.IdStatus) {
            case 1002:
                desgloze.push(
                    {
                        IdStatus: 1002,
                        CssStyle: 'fa fa-send bg-blue',
                        FechaProceso: bitacora.FechaEnvioEdicom,
                        CodigoEDICOM: bitacora.CodigoEDICOM,
                        DescripcionStatus: 'Solicitud enviada a EDICOM'
                    });
                break;
            case 1003:
                desgloze.push(
                    {
                        IdStatus: 1002,
                        CssStyle: 'fa fa-send bg-blue',
                        FechaProceso: bitacora.FechaEnvioEdicom,
                        CodigoEDICOM: bitacora.CodigoEDICOM,
                        DescripcionStatus: 'Solicitud enviada a EDICOM'
                    });
                desgloze.push(
                    {
                        IdStatus: 1003,
                        CssStyle: 'fa fa-file bg-orange',
                        FechaProceso: bitacora.FechaRecepcionAcuse,
                        DescripcionStatus: 'Recepción de acuse',
                        Detalles: JSON.parse(bitacora.AcuseRecepcionSAT)
                    });
                break;
            case 1004:
                desgloze.push(
                    {
                        IdStatus: 1002,
                        CssStyle: 'fa fa-send bg-blue',
                        FechaProceso: bitacora.FechaEnvioEdicom,
                        CodigoEDICOM: bitacora.CodigoEDICOM,
                        DescripcionStatus: 'Solicitud enviada a EDICOM'
                    });

                if (bitacora.AcuseRecepcionSAT != null) {
                    desgloze.push(
                        {
                            IdStatus: 1003,
                            CssStyle: 'fa fa-file bg-orange',
                            FechaProceso: bitacora.FechaRecepcionAcuse,
                            DescripcionStatus: 'Recepción de acuse',
                            Detalles: JSON.parse(bitacora.AcuseRecepcionSAT)
                        });
                }

                desgloze.push(
                    {
                        IdStatus: 1004,
                        CssStyle: 'fa fa-recycle bg-green',
                        FechaProceso: bitacora.FechaCancelacion,
                        DescripcionStatus: 'Documento cancelado',
                        Detalles: JSON.parse(bitacora.AcuseRespuestaSAT)
                    });
                break;
            case 1005:
                desgloze.push(
                    {
                        IdStatus: 1002,
                        CssStyle: 'fa fa-send bg-blue',
                        FechaProceso: bitacora.FechaEnvioEdicom,
                        CodigoEDICOM: bitacora.CodigoEDICOM,
                        DescripcionStatus: 'Solicitud enviada a EDICOM'
                    });

                if (bitacora.AcuseRecepcionSAT != null) {
                    desgloze.push(
                        {
                            IdStatus: 1003,
                            CssStyle: 'fa fa-file bg-orange',
                            FechaProceso: bitacora.FechaRecepcionAcuse,
                            DescripcionStatus: 'Recepción de acuse',
                            Detalles: JSON.parse(bitacora.AcuseRecepcionSAT)
                        });
                }

                desgloze.push(
                    {
                        IdStatus: 1005,
                        CssStyle: 'fa fa-exclamation-triangle bg-red',
                        FechaProceso: bitacora.FechaModificacion,
                        DescripcionStatus: 'Solicitud denegada',
                        Detalles: JSON.parse(bitacora.AcuseRespuestaSAT)
                    });
                break;
            case 1006:
                desgloze.push(
                    {
                        IdStatus: 1002,
                        CssStyle: 'fa fa-send bg-blue',
                        FechaProceso: bitacora.FechaEnvioEdicom,
                        CodigoEDICOM: bitacora.CodigoEDICOM,
                        DescripcionStatus: 'Solicitud enviada a EDICOM'
                    });

                if (bitacora.AcuseRecepcionSAT != null) {
                    desgloze.push(
                        {
                            IdStatus: 1003,
                            CssStyle: 'fa fa-file bg-orange',
                            FechaProceso: bitacora.FechaRecepcionAcuse,
                            DescripcionStatus: 'Recepción de acuse',
                            Detalles: JSON.parse(bitacora.AcuseRecepcionSAT)
                        });
                }

                desgloze.push(
                    {
                        IdStatus: 1006,
                        CssStyle: 'fa fa-exclamation-triangle bg-red',
                        FechaProceso: bitacora.FechaModificacion,
                        DescripcionStatus: 'No cancelable',
                        Detalles: JSON.parse(bitacora.AcuseRespuestaSAT)
                    });
                break;
        }

        

        var dataDetails = { tipoModal: 'detalleBitacoraCancelacion', data: { RfcEmisor: bitacora.RfcEmisor, Documento: bitacora.Documento, foliosError: this.sharedservice.orderDescendingByDate(desgloze, "FechaProceso") } };

        this.dialog.open(DialogTimeLineComponent, {
            width: '80%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }


    refacturarDocumento() {
        debugger

        let banderaActiva: boolean = this.switchPreparaBD || this.switchCancelaEDIWIN;

        if (this.serieID == '' || this.ciaID == '') {
            this.toastr.error('Todos los datos son obligatorios', 'Error');
            return;
        }

        if (this.showMasiva) {

            if (this.archivoExcel.NombreArchivo == '' || this.archivoExcel.Archivo == null) {
                this.toastr.error('Al habilitar la carga masiva es necesario subir un archivo de excel con la lista de folios a cancelar', 'Error');
                return;
            }
        }
        else {
            if (this.folio <= 0) {
                this.toastr.error('El folio del documento tiene que ser mayor a 0', 'Error');
                return;
            }
        }

        if (!banderaActiva) {
            this.toastr.error('Por lo menos debe activar una acción', 'Error');
            return;
        }

        if (this.motivoCancelacion == '') {
            this.toastr.error('El motivo de cancelación es un dato obligatorio.', 'Error');
            return;
        }

        this.spinnerService.show();

        let usuario = this.localstorageservice.GetAuthorizationUser();
        this.refacturacionesService.
            PostRefactura(this.ciaID, this.serieID, this.folio.toString(), this.motivoCancelacion, this.switchPreparaBD, this.switchCancelaEDIWIN, usuario, this.motivoCancelacionID, this.showMasiva, this.archivoExcel).
            subscribe(
                (data) => {
                    debugger
                    let dataDetails: any = {};
                    let desgloze: any[] = [];

                    if (data.estatus == 'DocumentosRelacionados') {

                        if (data.cantidadDeFacturas > 1) {
                            this.solicitudRespuesta = {
                                EsSolicitudCreada: false,
                                MensajeEstatusSolicitud: 'La solicitud no fue creada',
                                DocumentosNoEncotrados: [],
                                DocumentosEnProceso: [],
                                FoliosExcesoCancelacion: [],
                                FoliosCancelados: [],
                                FoliosInsertados: 0,
                                IdSolicitud: 0,
                                IdSolicitudString: '',
                                FacturasConDocumentoRelacionado: data.documentosRelacionados
                            };

                            this.dataSourceFacConDocRelacionado = new MatTableDataSource(this.solicitudRespuesta.FacturasConDocumentoRelacionado);
                            this.dataSourceFacConDocRelacionado.paginator = this.paginator;
                            this.dataSourceFacConDocRelacionado.sort = this.sort;

                            this.solicitudRespuesta.DocumentosEnProceso.Folios = [];
                            this.solicitudRespuesta.DocumentosNoEncotrados.Folios = [];
                            this.solicitudRespuesta.FoliosExcesoCancelacion.Folios = [];
                            this.solicitudRespuesta.FoliosCancelados.Folios = [];

                            this.showResultadosSolicitudMasiva = true;
                        }
                        else {
                            dataDetails = { tipoModal: 'cancelacionDocsRelacionados', data: { Serie: this.serieID, Folio: data.documentosRelacionados[0].factura.split('-')[1], DocumentosRelacionados: data.documentosRelacionados } };

                            this.dialog.open(DialogTimeLineComponent, {
                                width: '470%',
                                height: 'auto',
                                data: dataDetails,
                                panelClass: 'custom-dialog-container2'
                            });

                            this.limpiar();
                        }
                    }
                    else if (data.estatus == 'OK') {
                        //if (data.mensaje.PreparaBD == true) {
                        //    desgloze.push(
                        //        {
                        //            proceso: 'Solicitud de cancelación',
                        //            tipoLinea: 1,
                        //            mensaje: data.mensaje.EstatusCancelacion,
                        //            localizadoEnFE090F: data.mensaje.DocumentoLocalizadoEnFE090F,
                        //            localizadoEnUuidsProcesados: data.mensaje.DocumentoLocalizadoEnUuidsProcesados,
                        //            claseError: data.mensaje.EstatusCancelacion.includes('El documento fue marcado para ser cancelado') ? 'fa fa-check bg-green' : 'fa fa-bug bg-red'
                        //        });
                        //}
                        //else
                        //    desgloze.push(
                        //        {
                        //            proceso: 'Solicitud de cancelación',
                        //            tipoLinea: 2,
                        //            mensaje: data.mensaje.EstatusCancelacion,
                        //            claseError: data.mensaje.EstatusCancelacion.includes('El documento fue marcado para ser cancelado') ? 'fa fa-check bg-green' : 'fa fa-bug bg-red'
                        //        });

                        //dataDetails = { tipoModal: 'responseCancelacion', data: { foliosError: desgloze } };

                        //this.dialog.open(DialogTimeLineComponent, {
                        //    width: '470%',
                        //    height: 'auto',
                        //    data: dataDetails,
                        //    panelClass: 'custom-dialog-container2'
                        //});

                        //if (this.showMasiva) {
                        if (data.mensaje.TipoMensaje == 1) {
                            if (!data.mensaje.EsFolioUnico) {
                                this.solicitudRespuesta = {
                                    EsSolicitudCreada: false,
                                    MensajeEstatusSolicitud: 'La solicitud no fue creada',
                                    DocumentosNoEncotrados: JSON.parse(data.mensaje.Mensaje),
                                    DocumentosEnProceso: [],
                                    FoliosExcesoCancelacion: [],
                                    FoliosCancelados: [],
                                    FoliosInsertados: 0,
                                    IdSolicitud: 0,
                                    IdSolicitudString: '',
                                    FacturasConDocumentoRelacionado: []
                                };
                                this.dataSourceDocNoEncontrados = new MatTableDataSource(this.solicitudRespuesta.DocumentosNoEncotrados.Folios);
                                this.dataSourceDocNoEncontrados.paginator = this.paginator;
                                this.dataSourceDocNoEncontrados.sort = this.sort;

                                this.solicitudRespuesta.DocumentosEnProceso.Folios = [];
                                this.solicitudRespuesta.FoliosExcesoCancelacion.Folios = [];
                                this.solicitudRespuesta.FoliosCancelados.Folios = [];

                                this.showResultadosSolicitudMasiva = true;
                            }
                            else {
                                this.toastr.error(data.mensaje.Mensaje, 'Error');
                            }
                        }
                        else if (data.mensaje.TipoMensaje == 2) {
                            this.solicitudRespuesta = {
                                EsSolicitudCreada: data.mensaje.EsSolicitudCreada,
                                MensajeEstatusSolicitud: data.mensaje.EsSolicitudCreada ? 'Solicitud creada' : 'La solicitud no fue creada',
                                DocumentosNoEncotrados: data.mensaje.DocumentosNoEncontrados == '' ? [] : JSON.parse(data.mensaje.DocumentosNoEncontrados),
                                DocumentosEnProceso: data.mensaje.DocumentosEnProceso == '' ? [] : JSON.parse(data.mensaje.DocumentosEnProceso),
                                FoliosExcesoCancelacion: data.mensaje.FoliosExcesoCancelacion == '' ? [] : JSON.parse(data.mensaje.FoliosExcesoCancelacion),
                                FoliosCancelados: data.mensaje.FoliosCancelados == '' ? [] : JSON.parse(data.mensaje.FoliosCancelados),
                                FoliosInsertados: data.mensaje.FoliosInsertados,
                                IdSolicitud: data.mensaje.IdSolicitud,
                                IdSolicitudString: data.mensaje.IdSolicitudString,
                                FacturasConDocumentoRelacionado: []
                            };

                            if (this.solicitudRespuesta.DocumentosEnProceso.Folios.length > 0) {
                                this.dataSourceDocEnProceso = new MatTableDataSource(this.solicitudRespuesta.DocumentosEnProceso.Folios);
                                this.dataSourceDocEnProceso.paginator = this.paginator;
                                this.dataSourceDocEnProceso.sort = this.sort;
                            }

                            if (this.solicitudRespuesta.DocumentosNoEncotrados.Folios.length > 0) {
                                this.dataSourceDocNoEncontrados = new MatTableDataSource(this.solicitudRespuesta.DocumentosNoEncotrados.Folios);
                                this.dataSourceDocNoEncontrados.paginator = this.paginator;
                                this.dataSourceDocNoEncontrados.sort = this.sort;
                            }

                            if (this.solicitudRespuesta.FoliosExcesoCancelacion.Folios.length > 0) {
                                this.dataSourceDocExcesoDeCancelaciones = new MatTableDataSource(this.solicitudRespuesta.FoliosExcesoCancelacion.Folios);
                                this.dataSourceDocExcesoDeCancelaciones.paginator = this.paginator;
                                this.dataSourceDocExcesoDeCancelaciones.sort = this.sort;
                            }

                            if (this.solicitudRespuesta.FoliosCancelados.Folios.length > 0) {
                                this.dataSourceDocCancelados = new MatTableDataSource(this.solicitudRespuesta.FoliosCancelados.Folios);
                                this.dataSourceDocCancelados.paginator = this.paginator;
                                this.dataSourceDocCancelados.sort = this.sort;
                            }

                            if (data.documentosRelacionados.length > 0) {
                                this.solicitudRespuesta.FacturasConDocumentoRelacionado = data.documentosRelacionados;

                                this.dataSourceFacConDocRelacionado = new MatTableDataSource(this.solicitudRespuesta.FacturasConDocumentoRelacionado);
                                this.dataSourceFacConDocRelacionado.paginator = this.paginator;
                                this.dataSourceFacConDocRelacionado.sort = this.sort;
                            }

                            if (this.solicitudRespuesta.DocumentosEnProceso.Folios.length == 0
                                && this.solicitudRespuesta.DocumentosNoEncotrados.Folios.length == 0
                                && this.solicitudRespuesta.FoliosExcesoCancelacion.Folios.length == 0
                                && this.solicitudRespuesta.FoliosCancelados.Folios.length == 0
                                && data.documentosRelacionados.length == 0) {
                                this.toastr.success('Solicitud [' + this.solicitudRespuesta.IdSolicitudString + '] creada correctamente');
                                this.limpiar();
                            }
                            else
                                this.showResultadosSolicitudMasiva = true;
                        }
                    }
                    else {
                        this.toastr.error(data.mensaje, 'Error en proceso de cancelación');
                    }
                },
                response => {
                    this.spinnerService.hide();
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                    this.spinnerService.hide();
                });
    }

    isGroup(index: number, item: any): boolean {
        return item.detailRow;
    }

    getRegeneracionList() {

        this.ShowSpinnerTable = true;
        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);

        this.refacturacionesService.GetHistorico().
            subscribe(
                (data) => {
                    debugger
                    if (data.estatus == 'OK') {

                        this.solicitudes = [];
                        data.solicitudes.forEach((element: any) => this.solicitudes.push(element, { detailRow: true, element: { IdNivelAprobador: element.IdNivelAprobador, IdStatusSolicitud: element.IdStatusSolicitud, historico: JSON.parse(element.HistoricoAprobadores), lineaAprobadores: element.LineaAprobadores == null ? null : JSON.parse(element.LineaAprobadores) } }));

                        this.dataSource = new MatTableDataSource(this.solicitudes);
                        this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;
                        this.selectionCheckBox = new SelectionModel<any>(true, []);
                    }
                },
                response => {
                    this.ShowSpinnerTable = false;
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                    this.ShowSpinnerTable = false;
                });
    }

    descargarCsv() {
        debugger
        this.spinnerService.show();
        var datosTablaResumen = [];

        datosTablaResumen.push({
            "emisor": "Emisor",
            "documento": "Documento",
            "usuario": "Usuario",
            "estatus": "Estatus",
            "accion": "Acción",
            "fechaProcesamiento": "Fecha Procesamiento",
            "comentarios": "Comentarios",
            "uuidCancela": "UuidCancela"
        });

        for (let doc of this.selectionCheckBox.selected) {

            //if(doc.IdStatus
            datosTablaResumen.push(
                {
                    "emisor": doc.RfcEmisor,
                    "documento": doc.Serie + '-' + doc.Folio,
                    "usuario": doc.Nombre,
                    "estatus": doc.EstatusCancelacion,
                    "accion": doc.Motivos,
                    "fechaProcesamiento": doc.FechaProceso,
                    "comentarios": doc.Comentarios,
                    "uuidCancela": doc.UuidCancela
                }
            );
        }

        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen de cancelaciones');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();
    }

    limpiar() {
        this.ciaID = '';
        this.serieID = '';

        this.cia = '';
        this.serie = '';
        this.folio = 0;
        this.motivoCancelacion = ''
        this.motivoCancelacionID = 0;

        this.showMasiva = false;
        this.archivoExcel = {
            NombreArchivo: '',
            Archivo: null
        };
        this.showResultadosSolicitudMasiva = false;
        this.showDetalleSolicitud = false;
        this.ShowSpinnerDetalleSolicitud = false;

        this.solicitudRespuesta = {
            EsSolicitudCreada: false,
            MensajeEstatusSolicitud: '',
            DocumentosNoEncotrados: [],
            DocumentosEnProceso: [],
            FoliosExcesoCancelacion: [],
            FoliosCancelados: [],
            FoliosInsertados: 0,
            IdSolicitud: 0,
            IdSolicitudString: '',
            FacturasConDocumentoRelacionado: []
        };

        this.dataSourceDocNoEncontrados = new MatTableDataSource<any>();
        this.dataSourceFacConDocRelacionado = new MatTableDataSource<any>();
        this.dataSourceDocEnProceso = new MatTableDataSource<any>();
        this.dataSourceDocExcesoDeCancelaciones = new MatTableDataSource<any>();
        this.dataSourceDocCancelados = new MatTableDataSource<any>();
        this.dataSourceDetalleSolicitud = new MatTableDataSource<any>();

        this.solicitudes = [];

        this.motivosDeCancelacion = [];

        this.getRegeneracionList();
    }

    applyFilter(clearData: boolean/*filterValue: string*/) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}