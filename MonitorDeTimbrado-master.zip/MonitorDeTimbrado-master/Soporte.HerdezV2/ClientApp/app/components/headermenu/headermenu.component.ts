﻿import { Component} from '@angular/core';
import { LocalStorageService } from '../shared/localstorage.service';

@Component({
    selector: 'header-menu',
    templateUrl: './headermenu.component.html',
    styleUrls: ['./headermenu.style.css']
})

export class HeaderMenuComponent {

    //imageUser: string = '';
    //puesto: string = '';
    //nombre: string = '';

    constructor(private localStorageService: LocalStorageService) { }

    //ngOnInit() {
    //    let userData = this.localStorageService.GetAuthorizationData();
    //    this.imageUser = userData._userData.ngUser.imagen;
    //    this.puesto = userData._userData.ngUser.puesto;
    //    this.nombre = userData._userData.ngUser.nombre;
    //}

    get DataLS(): any {
        return localStorage.getItem("lastUpdate");
    }

    logOut() {
        this.localStorageService.RemoveAuthorizationData();
    }
}