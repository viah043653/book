﻿namespace Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui
{
    using System.Collections.Generic;
    using System.Linq;

    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public class ReporteBase
    {
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string RfcEmisor { get; set; }
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string RfcReceptor { get; set; }
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string SerieFactura { get; set; }
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public long FolioFactura { get; set; }

        public static List<ReporteBase> GetReporteBase(List<ReporteNota> reporteNotasDeCredito)
        {
            return reporteNotasDeCredito.
                GroupBy(g => new { g.RfcEmisor, g.RfcReceptor, g.SerieFactura, g.FolioFactura }).
                Select(g =>
                {
                    var reporte = g.FirstOrDefault();
                    return new ReporteBase() { FolioFactura = reporte.FolioFactura, RfcEmisor = reporte.RfcEmisor, RfcReceptor = reporte.RfcReceptor, SerieFactura = reporte.SerieFactura };
                }).ToList();
        }
    }
}