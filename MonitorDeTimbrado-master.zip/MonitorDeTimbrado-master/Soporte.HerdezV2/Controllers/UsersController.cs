﻿namespace Soporte.HerdezV2.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Authorization;
    using Validates.Self;
    using System.IdentityModel.Tokens.Jwt;
    using System.Text;
    using Microsoft.IdentityModel.Tokens;
    using System.Security.Claims;
    using Soporte.HerdezV2.Models.Generic;

    [Authorize]
    [Produces("application/json")]
    [Route("api/User")]
    public class UsersController : Controller
    {
        IValidateUser _validateUser;

        public UsersController(IValidateUser validateUser)
        {
            this._validateUser = validateUser;
        }

        [AllowAnonymous]
        [Route("~/api/authentication")] 
        [HttpPost]
        //public IActionResult Authenticate(dynamic Usuario, dynamic Password)
        public IActionResult Authenticate([FromBody] Autenticacion _user)
        {
            try
            {
                var user = this._validateUser.Authenticate(_user);

                if (user == null)
                    return Unauthorized();

                var tokenHandler = new JwtSecurityTokenHandler();
                string s = Startup.initSecret;
                var key = Encoding.ASCII.GetBytes(Startup.initSecret);

                DateTime expiresDate = DateTime.Now.AddHours(8);

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                        new Claim(ClaimTypes.Name, user.ngUser.usuario)
                    }),
                    Expires = expiresDate,
                    NotBefore = DateTime.Now,
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);
                var tokenString = tokenHandler.WriteToken(token);

                return Ok(new
                {
                    _userData = user,
                    _token = tokenString,
                    _expireDate = expiresDate
                });

                throw new Exception();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [AllowAnonymous]
        [Route("~/api/changePassword")]
        [HttpPost]
        public IActionResult ChangePassword(string Usuario, string OldPassword, string NewPassword)
        {
            try
            {
                return Ok(this._validateUser.ChangePassword(Usuario, OldPassword, NewPassword));
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
    }
}