﻿namespace Soporte.HerdezV2.Controllers
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization; 
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI;

    [Authorize]
    [Produces("application/json")]
    [Route("api/EnviosClientes")]
    public class EnviosClientesController : Controller
    {
        ValidateEnviosClientes validateEnvios = new ValidateEnviosClientes();

        [Route("~/api/GetClientesEnvios")]
        [HttpGet]
        public IEnumerable GetClientes()
        {
            validateEnvios = new ValidateEnviosClientes();
            var result = validateEnvios.GetClientes();

            return result;
        }

        // POST api/values
        [Route("~/api/PostEnviosClientes")]
        [HttpPost]
        public IEnumerable PostEnvios([FromBody]ValidateEnviosClientes.FiltroEnvio filtro)
        {
            validateEnvios = new ValidateEnviosClientes();
            return validateEnvios.GetEnvios(filtro);
        }

        // POST api/values
        [Route("~/api/DescargarReporteEntregas")]
        [HttpPost]
        public IEnumerable DescargarReporteEntregas([FromBody]ValidateEnviosClientes.FiltroEnvio filtro)
        {
            validateEnvios = new ValidateEnviosClientes();

            return validateEnvios.GetZip(filtro);
        }
    }
}