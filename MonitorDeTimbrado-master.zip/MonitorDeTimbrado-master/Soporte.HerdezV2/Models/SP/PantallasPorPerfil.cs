﻿namespace Soporte.HerdezV2.Models.SP
{
    public class PantallasPorPerfil
    {
        public int IdPantalla { get; set; }
        public int IdModulo { get; set; }
        public string NombrePantalla { get; set; }
        public string Componente { get; set; }
        public string NombreModulo { get; set; }
        public string IconoPantalla { get; set; }
        public string IconoModulo { get; set; }
        public string Acciones { get; set; }
    }
}