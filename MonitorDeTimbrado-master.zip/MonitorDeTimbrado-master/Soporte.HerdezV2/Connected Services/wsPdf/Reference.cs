﻿//------------------------------------------------------------------------------
// <generado automáticamente>
//     Este código fue generado por una herramienta.
//     //
//     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
//     se vuelve a generar el código.
// </generado automáticamente>
//------------------------------------------------------------------------------

namespace wsPdf
{
    using System.Runtime.Serialization;
    
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.Runtime.Serialization.DataContractAttribute(Name="DataRequestPdf", Namespace="http://schemas.datacontract.org/2004/07/wcfXmlToPdf.Model")]
    public partial class DataRequestPdf : object
    {
        
        private string nombreXmlField;
        
        private string passwordField;
        
        private string usuarioField;
        
        private string xmlField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string nombreXml
        {
            get
            {
                return this.nombreXmlField;
            }
            set
            {
                this.nombreXmlField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string password
        {
            get
            {
                return this.passwordField;
            }
            set
            {
                this.passwordField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string usuario
        {
            get
            {
                return this.usuarioField;
            }
            set
            {
                this.usuarioField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string xml
        {
            get
            {
                return this.xmlField;
            }
            set
            {
                this.xmlField = value;
            }
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.Runtime.Serialization.DataContractAttribute(Name="DataResponsePdf", Namespace="http://schemas.datacontract.org/2004/07/wcfXmlToPdf.Model")]
    public partial class DataResponsePdf : object
    {
        
        private wsPdf.DataError ErrorField;
        
        private wsPdf.Status EstatusField;
        
        private string NombrePdfField;
        
        private byte[] PdfField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public wsPdf.DataError Error
        {
            get
            {
                return this.ErrorField;
            }
            set
            {
                this.ErrorField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public wsPdf.Status Estatus
        {
            get
            {
                return this.EstatusField;
            }
            set
            {
                this.EstatusField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string NombrePdf
        {
            get
            {
                return this.NombrePdfField;
            }
            set
            {
                this.NombrePdfField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public byte[] Pdf
        {
            get
            {
                return this.PdfField;
            }
            set
            {
                this.PdfField = value;
            }
        }
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.Runtime.Serialization.DataContractAttribute(Name="DataError", Namespace="http://schemas.datacontract.org/2004/07/wcfXmlToPdf.Model")]
    public partial class DataError : object
    {
        
        private long IdErrorField;
        
        private string MensajeField;
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public long IdError
        {
            get
            {
                return this.IdErrorField;
            }
            set
            {
                this.IdErrorField = value;
            }
        }
        
        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Mensaje
        {
            get
            {
                return this.MensajeField;
            }
            set
            {
                this.MensajeField = value;
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.Runtime.Serialization.DataContractAttribute(Name="Status", Namespace="http://schemas.datacontract.org/2004/07/wcfXmlToPdf.Model")]
    public enum Status : int
    {
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Ok = 0,
        
        [System.Runtime.Serialization.EnumMemberAttribute()]
        Error = 1,
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.ServiceModel.ServiceContractAttribute(ConfigurationName="wsPdf.IPdf")]
    public interface IPdf
    {
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IPdf/ConvertToPdf", ReplyAction="http://tempuri.org/IPdf/ConvertToPdfResponse")]
        System.Threading.Tasks.Task<wsPdf.DataResponsePdf[]> ConvertToPdfAsync(wsPdf.DataRequestPdf dataRequest);
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    public interface IPdfChannel : wsPdf.IPdf, System.ServiceModel.IClientChannel
    {
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    public partial class PdfClient : System.ServiceModel.ClientBase<wsPdf.IPdf>, wsPdf.IPdf
    {
        
    /// <summary>
    /// Implemente este método parcial para configurar el punto de conexión de servicio.
    /// </summary>
    /// <param name="serviceEndpoint">El punto de conexión para configurar</param>
    /// <param name="clientCredentials">Credenciales de cliente</param>
    static partial void ConfigureEndpoint(System.ServiceModel.Description.ServiceEndpoint serviceEndpoint, System.ServiceModel.Description.ClientCredentials clientCredentials);
        
        public PdfClient() : 
                base(PdfClient.GetDefaultBinding(), PdfClient.GetDefaultEndpointAddress())
        {
            this.Endpoint.Name = EndpointConfiguration.BasicHttpBinding_IPdf.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public PdfClient(EndpointConfiguration endpointConfiguration) : 
                base(PdfClient.GetBindingForEndpoint(endpointConfiguration), PdfClient.GetEndpointAddress(endpointConfiguration))
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public PdfClient(EndpointConfiguration endpointConfiguration, string remoteAddress) : 
                base(PdfClient.GetBindingForEndpoint(endpointConfiguration), new System.ServiceModel.EndpointAddress(remoteAddress))
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public PdfClient(EndpointConfiguration endpointConfiguration, System.ServiceModel.EndpointAddress remoteAddress) : 
                base(PdfClient.GetBindingForEndpoint(endpointConfiguration), remoteAddress)
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }
        
        public PdfClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) : 
                base(binding, remoteAddress)
        {
        }
        
        public System.Threading.Tasks.Task<wsPdf.DataResponsePdf[]> ConvertToPdfAsync(wsPdf.DataRequestPdf dataRequest)
        {
            return base.Channel.ConvertToPdfAsync(dataRequest);
        }
        
        public virtual System.Threading.Tasks.Task OpenAsync()
        {
            return System.Threading.Tasks.Task.Factory.FromAsync(((System.ServiceModel.ICommunicationObject)(this)).BeginOpen(null, null), new System.Action<System.IAsyncResult>(((System.ServiceModel.ICommunicationObject)(this)).EndOpen));
        }
        
        public virtual System.Threading.Tasks.Task CloseAsync()
        {
            return System.Threading.Tasks.Task.Factory.FromAsync(((System.ServiceModel.ICommunicationObject)(this)).BeginClose(null, null), new System.Action<System.IAsyncResult>(((System.ServiceModel.ICommunicationObject)(this)).EndClose));
        }
        
        private static System.ServiceModel.Channels.Binding GetBindingForEndpoint(EndpointConfiguration endpointConfiguration)
        {
            if ((endpointConfiguration == EndpointConfiguration.BasicHttpBinding_IPdf))
            {
                System.ServiceModel.BasicHttpBinding result = new System.ServiceModel.BasicHttpBinding();
                result.MaxBufferSize = int.MaxValue;
                result.ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max;
                result.MaxReceivedMessageSize = int.MaxValue;
                result.AllowCookies = true;
                return result;
            }
            throw new System.InvalidOperationException(string.Format("No se pudo encontrar un punto de conexión con el nombre \"{0}\".", endpointConfiguration));
        }
        
        private static System.ServiceModel.EndpointAddress GetEndpointAddress(EndpointConfiguration endpointConfiguration)
        {
            if ((endpointConfiguration == EndpointConfiguration.BasicHttpBinding_IPdf))
            {
                return new System.ServiceModel.EndpointAddress("http://192.168.200.61:447/Pdf.svc");
            }
            throw new System.InvalidOperationException(string.Format("No se pudo encontrar un punto de conexión con el nombre \"{0}\".", endpointConfiguration));
        }
        
        private static System.ServiceModel.Channels.Binding GetDefaultBinding()
        {
            return PdfClient.GetBindingForEndpoint(EndpointConfiguration.BasicHttpBinding_IPdf);
        }
        
        private static System.ServiceModel.EndpointAddress GetDefaultEndpointAddress()
        {
            return PdfClient.GetEndpointAddress(EndpointConfiguration.BasicHttpBinding_IPdf);
        }
        
        public enum EndpointConfiguration
        {
            
            BasicHttpBinding_IPdf,
        }
    }
}
