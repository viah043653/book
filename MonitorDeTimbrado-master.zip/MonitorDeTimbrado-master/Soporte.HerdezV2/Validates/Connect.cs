﻿namespace Soporte.HerdezV2.Validates
{
    using EF;
    using Soporte.HerdezV2.Models.Generic;
    using Soporte.HerdezV2.Models.Jobs.Cancelaciones;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class Connect
    {
        private string _csSoporteField = Startup.initSoporteConnection;
        private string _csServicioCorreosField = Startup.initServicioCorreosConnection;
        private string _csAdministracionFE = Startup.initAdministracionFEConnection;
        private string _csAS400Desarrollo = Startup.initConnectionStringAS400_Desarrollo;
        private string _csAS400Produccion = Startup.initConnectionStringAS400_Produccion;

        private string _pthRutaTemporal = Startup.initRutaTemporal;
        private string _pthNotasDeCargoChedraui = Startup.initRutaNotasCargoChedraui;
        private string _pthFolderCorreos = Startup.initRutaFolderCorreos;
        private string _pthEdicomTrabajo = Startup.initRutaEdicomTrabajo;
        private string _pthInsumosCfdi = Startup.initRutaInsumosCFDI;
        private string _pthInstanciasTXT = Startup.initTemporalInstanciaTXT;

        private string _rfcGenerico = Startup.initRfcGenerico;
        private List<string> _seriesFactura = Startup.initSeriesFactura;

        private Credenciales _credencialesHDZFAC001 = new Credenciales();
        private string _usuarioDominio = Startup.initUsuarioDominio;
        private string _usuarioNombre = Startup.initUsuarioNombre;
        private string _usuarioPassword = Startup.initUsuarioPassword;

        /*SFTP*/
        private string _pathExeSftp = Startup.initPathExeSftp;
        private string _nombreExeSftp = Startup.initNombreExeSftp;
        private string _responsePathSftp = Startup.initResponsePathSftp;

        /*Carvajal*/
        private string _usuarioSftpCarvajal = Startup.initUsuarioSftpCarvajal;
        public string _passwordSftpCarvajal = Startup.initPasswordSftpCarvajal;
        public string _hostSftpCarvajal = Startup.initHostSftpCarvajal;
        public string _sshHostKeyFingerprintSftpCarvajal = Startup.initSshHostKeyFingerprintSftpCarvajal;

        public string _pthExeAddendaPlanaCS = Startup.initExeAddendaPlanaCS;

        public SoapEnv SoapEnvCancelaciones { get; set; }

        public string[] NombresMeses = new string[]
        {
            "Ene",
            "Feb",
            "Mar",
            "Abr",
            "May",
            "Jun",
            "Jul",
            "Ago",
            "Sep",
            "Oct",
            "Nov",
            "Dic",
        };

        public string ConnectionStringServicioCorreos { get => _csServicioCorreosField; private set => _csServicioCorreosField = value; }
        public string ConnectionStringSoporte { get => _csSoporteField; private set => _csSoporteField = value; }
        public string ConnectionStringAdministracionFE { get => _csAdministracionFE; private set => _csAdministracionFE = value; }
        public string ConnectionStringAS400_Desarrollo { get => _csAS400Desarrollo; private set => _csAS400Desarrollo = value; }
        public string ConnectionStringAS400_Produccion { get => _csAS400Produccion; private set => _csAS400Produccion = value; }

        public string RutaTemporal { get => _pthRutaTemporal; private set => _pthRutaTemporal = value; }
        public string PathNotasDeCargoChedraui { get => _pthNotasDeCargoChedraui; private set => _pthNotasDeCargoChedraui = value; }
        public string PathFolderCorreos { get => _pthFolderCorreos; private set => _pthFolderCorreos = value; }
        public string PathEdicomTrabajo { get => _pthEdicomTrabajo; private set => _pthEdicomTrabajo = value; }
        public string PathInsumosCFDI { get => _pthInsumosCfdi; private set => _pthInsumosCfdi = value; }
        public string PathTempotalInstanciasTXT { get => _pthInstanciasTXT; private set => _pthInstanciasTXT = value; }

        public string RfcGenerico { get => _rfcGenerico; private set => _rfcGenerico = value; }
        public List<string> SeriesFacturas { get => _seriesFactura; private set => _seriesFactura = value; }

        public string PathExeAddendaPlanaCS { get => _pthExeAddendaPlanaCS; private set => _pthExeAddendaPlanaCS = value; }

        public string PathExeSftp { get => _pathExeSftp; private set => _pathExeSftp = value; }
        public string NombreExeSftp { get => _nombreExeSftp; private set => _nombreExeSftp = value; }
        public string ResponsePathSftp { get => _responsePathSftp; private set => _responsePathSftp = value; }

        public string UsuarioSftpCarvajal { get => _usuarioSftpCarvajal; private set => _usuarioSftpCarvajal = value; }
        public string PasswordSftpCarvajal { get => _passwordSftpCarvajal; private set => _passwordSftpCarvajal = value; }
        public string HostSftpCarvajal { get => _hostSftpCarvajal; private set => _hostSftpCarvajal = value; }
        public string SshHostKeyFingerprintSftpCarvajal { get => _sshHostKeyFingerprintSftpCarvajal; private set => _sshHostKeyFingerprintSftpCarvajal = value; }

        public Credenciales CredencialesHDZFAC001 { get => _credencialesHDZFAC001; private set => _credencialesHDZFAC001 = value; }

        public AppDbContext _context { get; private set; }

        public Mensaje _Mensaje { get; set; } = new Mensaje();

        public List<Models.Tables.BI.PacCompania> _pacsCompanias { get; private set; }

        public Connect()
        {
            this._context = new AppDbContext(this.ConnectionStringSoporte);
            this._credencialesHDZFAC001 = new Credenciales()
            {
                Dominio = Startup.initUsuarioDominio,
                Usuario = Startup.initUsuarioNombre,
                Password = Startup.initUsuarioPassword
            };

            this.SoapEnvCancelaciones = new SoapEnv();
            this.SoapEnvCancelaciones = Startup.initSoapEnv;

            this._pacsCompanias = this._context.PacCia.ToList();
        }

        /// <summary>
        /// Registra log de la aplicación
        /// </summary>
        /// <param name="proceso">Proceso que almacena la bitácora</param>
        /// <param name="mensaje">Log</param>
        public void SaveBitacora(string proceso, string mensaje)
        {
            try
            {
                DateTime dtn = DateTime.Now;

                string folder = Path.Combine(Startup.initPathBitacoras, proceso.Trim(), dtn.Year.ToString(), dtn.Month.ToString("00")); //string.Format("{0}{1}\\{2}\\{3}\\", Startup.initPathBitacoras, proceso.Trim(), dtn.Year.ToString(), dtn.Month.ToString("00"));
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                string customMessage = string.Format("[ {0} ] -> {1}", dtn.TimeOfDay.ToString("c"), mensaje);

                string logPath = Path.Combine(folder, string.Format("{0}.log", dtn.Day.ToString("00")));
                if (!File.Exists(logPath))
                    File.WriteAllLines(logPath, new List<string>() { customMessage });
                else
                    File.AppendAllLines(logPath, new List<string>() { "", customMessage });
            }
            catch { }
        }

        public class Credenciales
        {
            public string Dominio { get; set; }
            public string Usuario { get; set; }
            public string Password { get; set; }
        }
    }
}