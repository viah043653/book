﻿namespace Soporte.HerdezV2.Controllers
{
 using System;
 using System.Collections.Generic;
 using System.Linq;
 using System.Threading.Tasks;
 using Microsoft.AspNetCore.Authorization;
 using Microsoft.AspNetCore.Http;
 using Microsoft.AspNetCore.Mvc;
 using Soporte.HerdezV2.Validates.BI;
    
    [Authorize]
    [Produces("application/json")]
    [Route("api/EnviosCfdis")]    
    
    public class EnviosCfdisController : Controller
    {
        ValidateEnviosCfdis validateenttie = new ValidateEnviosCfdis();

        // POST api/values
        [Route("~/api/PostEnvCfdi")]
        [HttpPost]
        public dynamic PostEnvCfdi(int idUsuario,string Clientetext,string Dfolio)
        {
            validateenttie = new ValidateEnviosCfdis();

            IFormFile formFile = null;
            formFile = HttpContext.Request.Form.Files[0];

            return validateenttie.PostEnvioCfdis(idUsuario, Clientetext, Dfolio, formFile);
        }
    }
}