﻿namespace Soporte.HerdezV2.Models.Generic
{
    using System;
    using System.Collections.Generic;

    public class SpBusquedadFolio
    {
        public string Rfc { get; set; }
        public int Cia { get; set; }
        public string SerieFolio { get; set; }
        public string Serie { get; set; }
        public long Folio { get; set; }
        public string Estatus { get; set; }
        public DateTime? FechaHoraTxtAS400 { get; set; }
        public DateTime? FechaHoraGeneraTxt { get; set; }
        public DateTime? FechaEnvioCarvajal { get; set; }
        public DateTime? FechaRespuestaCarvajal { get; set; }
        public DateTime? FechaHoraTimbre { get; set; }
        public DateTime? FechaHoraRegistroUUID { get; set; }
        public string UUID { get; set; }
        public string Detalles { get; set; }
        public string RutaReproceso { get; set; }
        public string ClaseEstatus { get; set; }
        public string RFC_PAC { get; set; }
        public string Historico { get; set; }
    }
}