﻿import { Injectable } from "@angular/core";
import { NgIf } from '@angular/common';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class PdfService {

    private baseUrl: string = '';

    constructor(private httpClient: HttpClient) {
        this.baseUrl = '/api/';
    }

    public PostXmlToPdf(folios: any[]) {
        debugger
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        headers.append('Accept', 'application/zip');
        return this.httpClient.post<any>(`${this.baseUrl}PostXmlToPdf`, folios, { headers: headers });
    }

    //public PostXmlToPdfWithFile(xmls: any[]) {
    //    debugger
    //    var headers = new HttpHeaders();
    //    headers.append('Content-Type', 'application/json; charset=utf-8');
    //    headers.append('Accept', 'application/zip');
    //    return this.httpClient.post<any>(`${this.baseUrl}PostXmlToPdfWithFile`, xmls, { headers: headers })
    //}

    public PostXmlToPdfWithFile(files: any[]) {
        const frmData = new FormData();

        for (let file of files)
            frmData.append('Files', file.file, file.name);

        debugger
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any[]>(`${this.baseUrl}PostXmlToPdfWithFile`, frmData, { headers: headers });
    }
}