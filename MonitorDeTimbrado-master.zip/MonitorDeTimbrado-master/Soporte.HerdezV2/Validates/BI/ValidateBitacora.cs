﻿namespace Soporte.HerdezV2.Validates.BI
{
    using System;
    using Models.Tables.BI;
    using System.Collections.Generic;
    using Soporte.HerdezV2.Models.SP;
    using Dapper;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using Soporte.HerdezV2.Models.Generic;

    public interface IValidateBitacora
    {
        dynamic CreateBitacora(Bitacora bitacora);
    }

    public class ValidateBitacora : Connect, IValidateBitacora
    {
        public dynamic CreateBitacora(Bitacora bitacora)
        {
            try
            {
                this._context.Bitacora.Add(bitacora);
                this._context.SaveChanges();

                return new
                {
                    status = "OK"
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    status = "ERROR",
                    mensaje = ex.Message
                };
            }
        }

        public IEnumerable<dynamic> GetRetransmisionClienteHistorico()
        {
            List<BitacoraSp> result = new List<BitacoraSp>();

            var prms = new DynamicParameters();
            prms.Add("@Proceso", "RetransmisiónXml", DbType.String);
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                result = db.Query<BitacoraSp>("sp_ConsultaHistoricoBitacoras", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            var grp = result.GroupBy(r => new { r.Rfc, r.Serie, r.Folio }).ToList();

            var historico = grp.Select(g => new
            {
                g.Key.Rfc,
                g.Key.Serie,
                g.Key.Folio,
                g.OrderByDescending(d => d.FechaAlta).FirstOrDefault().FechaAlta,
                g.OrderByDescending(d => d.FechaAlta).FirstOrDefault().Estatus,
                Historico = g.Select(h => new
                {
                    h.FechaAlta,
                    h.NombreUsuario,
                    h.Observaciones,
                    h.Error,
                    h.Estatus
                }).OrderByDescending(d => d.FechaAlta)
            }).ToList();

            return historico;
        }

        public IEnumerable<dynamic> PostBitacoraHistorico(string procesos)
        {
            List<BitacoraSp> result = new List<BitacoraSp>();

            var prms = new DynamicParameters();
            prms.Add("@Proceso", procesos, DbType.String);
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                result = db.Query<BitacoraSp>("sp_ConsultaHistoricoBitacoras", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            var grp = result.GroupBy(r => new { r.Rfc, r.Serie, r.Folio }).ToList();

            List<SpBusquedadFolio> resultSpEstatus = new List<SpBusquedadFolio>();
            Busqueda oBusqueda = new Busqueda();
            oBusqueda.Documento = new List<BusquedaDocumento>();

            foreach (var consulta in grp)
            {
                int cia = 0;
                switch (consulta.Key.Rfc)
                {
                    case "HER8301121X4": cia = 1; break;
                    case "CHE041201L59": cia = 60; break;
                    case "NUT840801733": cia = 77; break;
                    case "OCO160809URA": cia = 92; break;
                    case "HER980609NC1": cia = 43; break;
                    case "ROC020422UV9": cia = 102; break;
                    case "KSN200902B97": cia = 95; break;
                }

                var busquedaDocumento = new BusquedaDocumento();
                busquedaDocumento.Cia = cia;
                busquedaDocumento.Folio = consulta.Key.Folio;
                busquedaDocumento.Serie = consulta.Key.Serie;

                oBusqueda.Documento.Add(busquedaDocumento);
            }

            string xml = oBusqueda.GetXml<Busqueda>(oBusqueda);

            prms = new DynamicParameters();
            prms.Add("@Busqueda", xml, DbType.Xml);
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                resultSpEstatus = db.Query<SpBusquedadFolio>("sp_ConsultaEstatusDocumentos_V2", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            var lst = grp.Select(g =>
            {
                var filtList = resultSpEstatus.Where(r => r.Serie == g.Key.Serie && r.Folio == g.Key.Folio);
                var filt = filtList.FirstOrDefault();

                return new 
                {
                    Estatus = filt == null ? "Sin documento" : filt.Estatus,
                    Emisor = g.FirstOrDefault().Rfc,
                    FechaProceso = procesos == "RefacturaCancela" ? g.OrderByDescending(d => d.FechaAlta).FirstOrDefault().FechaAlta : (filt == null ? null : filt.Estatus == "Timbrado" ? filt.FechaHoraTimbre : filt.Estatus.Contains("Seguimiento") ? filt.FechaRespuestaCarvajal : filt.Estatus.Contains("Enviado") ? filt.FechaEnvioCarvajal : filt.FechaHoraGeneraTxt),
                    g.Key.Folio,
                    g.Key.Serie,
                    Mensaje = procesos == "RefacturaCancela" ? g.OrderByDescending(d => d.FechaAlta).FirstOrDefault().Estatus : (filt.Estatus == "Timbrado" ? "" : filt.Detalles),
                    HistoricoDesgloze = g.Select(d => new
                    {
                        d.Proceso,
                        Usuario = d.NombreUsuario,
                        d.Observaciones,
                        FechaProceso = d.FechaAlta
                    })
                };
            }).ToList();

            return lst;
        }
    }
}