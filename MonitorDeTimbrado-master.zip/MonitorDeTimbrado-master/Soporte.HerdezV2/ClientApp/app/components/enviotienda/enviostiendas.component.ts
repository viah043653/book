﻿import { Component, ViewChild, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel, DataSource } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { EnviosTiendasService } from './enviostiendas.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { EnvioIntercambioService } from '../enviointercambio/enviointercambio.service'
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/takeUntil';
import { getAllDebugNodes } from '@angular/core/src/debug/debug_node';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { PropertyRead } from '@angular/compiler';


@Component({
    providers: [EnviosTiendasService, SharedService, EnvioIntercambioService],
    selector: 'enviostiendas',
    templateUrl: './enviostiendas.component.html',
    styleUrls: ['./enviostiendas.style.css']
})

export class EnviosTiendasComponent implements OnInit, OnDestroy {

    private VIEW_ID: number = 7;
    
    cia: string= '';
    serie: string = '';
    folio: string = '';

    /*ciaID: number;*/
    serieID: string = '';

    isActionButtonsVisible: boolean = false;
    ShowSpinnerTable: boolean = true;
    isSearchCleanVisible: boolean = false;

    showCheckInTable: boolean = true;

    isTableVisble: boolean = false;
    interval: any;

    displayedColumns = ['isChecked', 'C10RFC', 'C10NOM', 'sucu', 'nosu', 'nuti'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    filterValue: string = '';

    companias: any[] = [
        { rfc: 'CHE041201L59', nombre: 'COMPAÑIA COMERCIAL HERDEZ S.A. DE C.V.', numero: '60' },
        { rfc: 'NUT840801733', nombre: 'NUTRISA S.A DE C.V.', numero: '77' },
        { rfc: 'OCO160809URA', nombre: 'OLYEN COFFEE', numero: '92' },
        { rfc: 'HER8301121X4', nombre: 'HERDEZ S.A DE C.V.', numero: '1' }
    ];
    
    httpBusqueda: Observable<any[]>;

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService, public consultaservice: EnviosTiendasService, public sharedservice: SharedService, public localstorageservice: LocalStorageService, public enviointercambioservice: EnvioIntercambioService, public dialog: MatDialog) {
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() { }

    regenerarArchivo() {
        this.spinnerService.show();
        this.consultaservice.GetEntTie(this.folio).subscribe(

            (status) => {


                var condicion = status.statuss;
                var listado = status.listadatos;
                var mensajesql = status.mensajeerror;
                debugger
                if (condicion == true) {

                    this.isTableVisble = true;

                    this.interval = setInterval(() => {

                        this.dataSource = new MatTableDataSource(listado);
                        this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;

                        clearInterval(this.interval);
                    }, 200);
                    this.toastr.success('La consulta regreso un total de ' + listado.length + ' registro(s)', 'Consulta finalizada');
                } else {
                    this.toastr.error(mensajesql);
                }
            },
            response => {
                this.spinnerService.hide();
                this.sharedservice.catchHttpResponseError(response);
            },
            () => {
                this.spinnerService.hide();
            }
        );
    }

    regresar() {
        this.isTableVisble = false;
    }

    limpiar() {
        /*this.ciaID = 0;*/
        this.serieID = '';

        this.cia = '';
        this.serie = '';
        this.folio = '';
        //this.folio = null;
    }

    applyFilter(clearData: boolean) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }
}