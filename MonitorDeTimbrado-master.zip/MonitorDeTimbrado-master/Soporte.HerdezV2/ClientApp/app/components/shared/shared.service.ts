﻿import { Injectable, ViewContainerRef } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Router } from '@angular/router';

import { LocalStorageService } from '../shared/localstorage.service';

@Injectable()
export class SharedService {
    private baseUrl: string = '';
    private currentUser: any = '';
    
    constructor(private httpClient: HttpClient, private router: Router, public toastr: ToastsManager, vcr: ViewContainerRef, private localstorageservice: LocalStorageService) {
        this.toastr.setRootViewContainerRef(vcr);
        this.baseUrl = '/api/';
    }

    public ReprocesarDocumentos(documentos: any[], observaciones: string, usuario: number) {
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');

        let obj: any = { reprocesos: documentos, observaciones: observaciones, usuario: usuario };

        return this.httpClient.post<any[]>(`${this.baseUrl}PostReporceso`, obj, { headers: headers });
    }

    public DescargarArchivosIntercambio(documentos: any[]) {
        return this.httpClient.post<any[]>(
            `${this.baseUrl}DescargarArchivosIntercambio`,
            documentos,
            {
                headers: { 'Content-Type': 'application/json; charset=utf-8', 'Accept': 'application/zip' }
            });
    }

    public GetTiposDeDocumentos() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.httpClient.get<any[]>(`${this.baseUrl}TiposDeDocumentos`, { headers: _headers });
    }

    public b64toBlob(b64Data: string, contentType: string) {
        var sliceSize = 512;

        var byteCharacters = atob(b64Data);
        var byteArrays = [];

        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);

            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);

            byteArrays.push(byteArray);
        }

        var blob = new Blob(byteArrays, { type: contentType });
        return blob;
    }

    public catchHttpResponseError(response: any) {
        debugger
        switch (response.status) {
            case 401:
                this.localstorageservice.RemoveAuthorizationData();
                break;
            default:
                this.toastr.error(response, 'Error en comunicación con el servidor');
                break;
        }
    }

    public orderDescendingByDate(array: any, fieldName: any): any {
        if (array) {
            let now: Date = new Date();

            array.sort((a: any, b: any) => {
                let date1: Date = new Date(a[fieldName]);
                let date2: Date = new Date(b[fieldName]);

                if (date1 > date2) return -1;
                if (date1 < date2) return 1;
                return 0;
            });
        }

        return array;
    }
}