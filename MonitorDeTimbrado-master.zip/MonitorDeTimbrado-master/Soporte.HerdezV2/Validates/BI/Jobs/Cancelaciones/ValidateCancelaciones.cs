﻿namespace Soporte.HerdezV2.Validates.BI.Jobs.Cancelaciones
{
    using Dapper;
    using Newtonsoft.Json.Linq;
    using Soporte.HerdezV2.Models.Jobs.Cancelaciones;
    using Soporte.HerdezV2.Validates;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Xml;

    public class ValidateCancelaciones : Connect
    {
        private const string BSolCancelacion = "Cancelacion\\Solicitud";
        private const string BDesRespuestas = "Cancelacion\\DescargaAcuses";

        public ValidateCancelaciones() { }

        /// <summary>
        /// Inicia cancelación masiva de documentos pendientes de cancelación
        /// </summary>
        public void CancelarDocumentosPendientes()
        {
            try
            {
                /*Registra bitácora del proceso*/
                this.SaveBitacora(BSolCancelacion, "===================    Inicia proceso para envío de bloques de documentos a cancelar   ===================");
                List<Cancelacion> cancelaciones = new List<Cancelacion>();

                DynamicParameters prms = new DynamicParameters();
                prms.Add("@IdStatus", 1001, DbType.Int32);
                using (IDbConnection db = new SqlConnection(this.ConnectionStringSoporte))
                    cancelaciones = db.Query<Cancelacion>("CANCELACIONES.sp_GetPendientes", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

                if (cancelaciones.Count > 0)
                    this.RequestCancelacion(cancelaciones);
                else
                    /*Registra bitácora del proceso*/
                    this.SaveBitacora(BSolCancelacion, "No se encontraron documentos pendientes de procesar");
            }
            catch (Exception ex)
            {
                /*Registra bitácora del proceso*/
                this.SaveBitacora(BSolCancelacion, ex.ToString());

                this.ReportaError(string.Format("Error al solicitar cancelación masiva. {0}", ex.ToString()));
            }
            finally
            {
                /*Registra bitácora del proceso*/
                this.SaveBitacora(BSolCancelacion, "===================    Finaliza proceso para envío de bloques de documentos a cancelar   ===================");
            }
        }

        /// <summary>
        /// Descarga respuestas de cancelación
        /// </summary>
        public void RequestCancelacionEstatus()
        {
            try
            {
                /*Registra bitácora del proceso*/
                this.SaveBitacora(BDesRespuestas, "===================    Inicia proceso para descarga de respuestas de cancelación  ===================");

                bool existenRespuestas = true;
                while (existenRespuestas)
                {
                    List<string> requestData = new List<string>();
                    requestData.Add("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:com=\"http://com.edicom.broker.adapter.services\">");
                    requestData.Add("<soapenv:Header/>");
                    requestData.Add("<soapenv:Body>");
                    requestData.Add("<com:subscriptionWS>");
                    requestData.Add(string.Format("<clientId>{0}</clientId>", this.SoapEnvCancelaciones.ClientID));
                    requestData.Add(string.Format("<user>{0}</user>", this.SoapEnvCancelaciones.User));
                    requestData.Add(string.Format("<password>{0}</password>", this.SoapEnvCancelaciones.Password));
                    requestData.Add(string.Format("<domain>{0}</domain>", this.SoapEnvCancelaciones.Domain));
                    requestData.Add(string.Format("<application>{0}</application>", this.SoapEnvCancelaciones.Application));
                    requestData.Add(string.Format("<schema>{0}</schema>", this.SoapEnvCancelaciones.SchemaGetRespuesta));
                    requestData.Add(string.Format("<transformation>{0}</transformation>", this.SoapEnvCancelaciones.Transformation));
                    requestData.Add(string.Format("<reference>{0}</reference>", this.SoapEnvCancelaciones.Reference));
                    requestData.Add("</com:subscriptionWS>");
                    requestData.Add("</soapenv:Body>");
                    requestData.Add("</soapenv:Envelope>");

                    WebClient webClient = new WebClient();

                    try
                    {
                        this.SaveBitacora(BDesRespuestas, "Ignorando errores por certificados....");
                        ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

                        //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    }
                    catch(Exception exSetProtocol)
                    {
                        this.SaveBitacora(BDesRespuestas, string.Format("Error en ServerCertificateValidationCallback [ {0} ]", exSetProtocol.ToString()));
                    }

                    //webClient.Timeout = TimeSpan.FromMinutes(15);
                    webClient.Encoding = System.Text.Encoding.Default;
                    webClient.Headers.Add(HttpRequestHeader.ContentType, "application/xop+xml;charset=utf-8");

                    /*Registra bitácora del proceso*/
                    this.SaveBitacora(BDesRespuestas, string.Format("Request [ {0} ]", string.Join(string.Empty, requestData)));

                    string webResponse = webClient.UploadString(new Uri(this.SoapEnvCancelaciones.EndPoint), string.Join(string.Empty, requestData));

                    /*Registra bitácora del proceso*/
                    this.SaveBitacora(BDesRespuestas, string.Format("Response [ {0} ]", webResponse));

                    List<string> responseList = webResponse.Split(new string[] { "\r\n" }, StringSplitOptions.None).ToList();

                    string
                        soapResponseBody = responseList.Where(r => r.Contains("soap:Envelope")).FirstOrDefault(),
                        acuseResponse = responseList.Where(r => r.Contains("{\"ack\":\"")).FirstOrDefault();

                    this.SaveBitacora(BDesRespuestas, string.Format("SoapResponseBody [ {0} ]", soapResponseBody));
                    this.SaveBitacora(BDesRespuestas, string.Format("AcuseResponse [ {0} ]", acuseResponse));

                    this.SaveBitacora(BDesRespuestas, "Cargando Xml Soap:Envelope....");
                    XmlDocument soapXml = new XmlDocument();
                    soapXml.LoadXml(soapResponseBody);

                    var idElement = soapXml.GetElementsByTagName("id");
                    if (idElement.Count == 0 && acuseResponse == null)
                    {
                        /*Registra bitácora del proceso*/
                        this.SaveBitacora(BDesRespuestas, "No existen timbres pendientes de descarga");
                        existenRespuestas = false;
                    }
                    else
                    {
                        this.SaveBitacora(BDesRespuestas, "Cargando acuse JSON....");
                        //if (!string.IsNullOrEmpty(acuseResponse))
                        //{
                            JObject JsonData = JObject.Parse(acuseResponse);
                            JObject JsonConsulta = JsonData.Value<JObject>("consulta");

                            string
                                rfcEmisor = JsonData.Value<string>("rfcEmisor"),
                                uuid = JsonData.Value<string>("uuid"),
                                estado = JsonConsulta.Value<string>("estado"),
                                estatusCancelacion = JsonConsulta.Value<string>("estatusCancelacion"),
                                esCancelable = JsonConsulta.Value<string>("esCancelable"),
                                refError = string.Empty;
                            int? status = JsonData.Value<int?>("status");

                            /*Registra bitácora del proceso*/
                            this.SaveBitacora(BDesRespuestas, string.Format("Emisor [ {0} ]", rfcEmisor));
                            /*Registra bitácora del proceso*/
                            this.SaveBitacora(BDesRespuestas, string.Format("Uuid [ {0} ]", uuid));
                            /*Registra bitácora del proceso*/
                            this.SaveBitacora(BDesRespuestas, string.Format("Estado [ {0} ]", estado));
                            /*Registra bitácora del proceso*/
                            this.SaveBitacora(BDesRespuestas, string.Format("EstatusCancelacion [ {0} ]", estatusCancelacion));
                            /*Registra bitácora del proceso*/
                            this.SaveBitacora(BDesRespuestas, string.Format("EsCancelable [ {0} ]", esCancelable));

                            /*Registra bitácora del proceso*/
                            this.SaveBitacora(BDesRespuestas, string.Format("Id Edicom [ {0} ]", idElement[0].InnerText));

                            if (!this.UpdateStatus(ref refError, 0, string.Empty, string.Empty, rfcEmisor, uuid, status == null ? 0 : Convert.ToInt32(status), acuseResponse, estado, estatusCancelacion, esCancelable))
                            {
                                /*Registra bitácora del proceso*/
                                this.SaveBitacora(BDesRespuestas, string.Format("Error al actualizar estatus [ {0} ]", refError));

                                this.ReportaError(string.Format("Error al actualizar estatus. Error: {0}", refError));
                            }
                            else
                            {
                                /*Registra bitácora del proceso*/
                                this.SaveBitacora(BDesRespuestas, "Actualización realizada correctamente");

                                string resultConfirm = this.ConfirmarSubscripcion(idElement[0].InnerText, ref refError);

                                /*Registra bitácora del proceso*/
                                this.SaveBitacora(BDesRespuestas, string.Format("Resultado de confirmación [ {0} ]", resultConfirm));
                            }
                        //}
                    }
                }
            }
            catch(WebException wEx)
            {

                /*Registra bitácora del proceso*/
                this.SaveBitacora(BDesRespuestas, string.Format("Error en descarga de respuestas wEx: {0} - {1}", wEx.Status.ToString(), wEx.ToString()));
            }
            catch(Exception ex)
            {
                /*Registra bitácora del proceso*/
                this.SaveBitacora(BDesRespuestas, string.Format("Error en descarga de respuestas {0}", ex.ToString()));

                this.ReportaError(string.Format("Error en descarga de respuestas {0}", ex.ToString()));
            }
            finally
            {
                /*Registra bitácora del proceso*/
                this.SaveBitacora(BDesRespuestas, "===================    Finaliza proceso para descarga de respuestas de cancelación  ===================");
            }
        }

        /// <summary>
        /// Post cancelación masiva
        /// </summary>
        /// <param name="cancelaciones"></param>
        private void RequestCancelacion(List<Cancelacion> cancelaciones)
        {
            /*Registra bitácora del proceso*/
            this.SaveBitacora(BSolCancelacion, string.Format("Se encontraron {0} documento(s) pendiente(s) de procesar", cancelaciones.Count));

            string nombreArchivo = string.Format("LayoutCAN_{0}.TXT", DateTime.Now.ToString("yyyyMMddHHmmss"));

            /*Registra bitácora del proceso*/
            this.SaveBitacora(BSolCancelacion, string.Format("Layout a procesar [ {0} ]", nombreArchivo));

            List<string> documentosACancelar = cancelaciones.Select(c => c.GetLineaLayout()).ToList();

            /*Registra bitácora del proceso*/
            this.SaveBitacora(BSolCancelacion, string.Format("Contenido del layout a procesar [ {0} ]", string.Join(Environment.NewLine, documentosACancelar)));

            byte[] dataArray = documentosACancelar.SelectMany(s => Encoding.ASCII.GetBytes(s)).ToArray();
            string base64File = Convert.ToBase64String(dataArray, Base64FormattingOptions.None);

            /*Registra bitácora del proceso*/
            this.SaveBitacora(BSolCancelacion, string.Format("Contenido del layout a base64 [ {0} ]", base64File));

            List<string> requestData = new List<string>();
            requestData.Add("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:com=\"http://com.edicom.broker.adapter.services\">");
            requestData.Add("<soapenv:Header/>");
            requestData.Add("<soapenv:Body>");
            requestData.Add("<com:publishWS>");
            requestData.Add(string.Format("<clientId>{0}</clientId>", this.SoapEnvCancelaciones.ClientID));
            requestData.Add(string.Format("<user>{0}</user>", this.SoapEnvCancelaciones.User));
            requestData.Add(string.Format("<password>{0}</password>", this.SoapEnvCancelaciones.Password));
            requestData.Add(string.Format("<domain>{0}</domain>", this.SoapEnvCancelaciones.Domain));
            requestData.Add(string.Format("<application>{0}</application>", this.SoapEnvCancelaciones.Application));
            requestData.Add(string.Format("<schema>{0}</schema>", this.SoapEnvCancelaciones.SchemaPostCancelacion));
            requestData.Add(string.Format("<destination>{0}</destination>", this.SoapEnvCancelaciones.Destination));
            requestData.Add(string.Format("<reference>{0}</reference>", this.SoapEnvCancelaciones.Reference));
            requestData.Add("<messages>");
            requestData.Add(string.Format("<message>{0}</message>", base64File));
            requestData.Add(string.Format("<name>{0}</name>", nombreArchivo));
            requestData.Add("</messages>");
            requestData.Add(string.Format("<duplicates>{0}</duplicates>", this.SoapEnvCancelaciones.Duplicates));
            requestData.Add("</com:publishWS>");
            requestData.Add("</soapenv:Body>");
            requestData.Add("</soapenv:Envelope>");

            /*Registra bitácora del proceso*/
            this.SaveBitacora(BSolCancelacion, string.Format("Request [ {0} ]", string.Join(string.Empty, requestData)));

            WebClient webClient = new WebClient();
            webClient.Headers.Add(HttpRequestHeader.ContentType, "application/xop+xml;");
            webClient.Encoding = System.Text.Encoding.UTF8;

            /*Registra bitácora del proceso*/
            this.SaveBitacora(BSolCancelacion, "Enviando solicitud a EDICOM....");

            string webResponse = webClient.UploadString(new Uri(this.SoapEnvCancelaciones.EndPoint), string.Join(string.Empty, requestData));
            int indexIniResponse = webResponse.IndexOf("<soap:Envelope");
            int indexFinResponse = webResponse.IndexOf("</soap:Envelope>");

            /*Registra bitácora del proceso*/
            this.SaveBitacora(BSolCancelacion, string.Format("Response [ {0} ]", webResponse));

            string responseClr = webResponse.Substring(indexIniResponse, (indexFinResponse - indexIniResponse) + 16);
            XmlDocument xmlResponse = new XmlDocument();
            xmlResponse.LoadXml(responseClr);

            var responseReturn = xmlResponse.GetElementsByTagName("return")[0];
            string codigoRespuesta = responseReturn.InnerText;

            /*Registra bitácora del proceso*/
            this.SaveBitacora(BSolCancelacion, string.Format("Codigo de resuesta [ {0} ]", codigoRespuesta));

            CodigoErrorPublish codigoError = this._context.CatCodigosDeErroresPublish.Where(c => c.Codigo.ToString() == codigoRespuesta).FirstOrDefault();
            if (codigoError != null)
            {
                //var S = codigoError.Codigo;
                //var s2 = codigoError.Error;
                ReportaError(string.Format("Se presento el siguiente error al consumir WS de edicom para publicar layout de cancelaciones: Codigo [ {0} ]. Error: [ {1} ]", codigoError.Codigo, codigoError.Error));
            }
            else if (codigoRespuesta.Contains("-"))
            {
                ReportaError(string.Format("Se presento el siguiente error no catalogado al consumir el WS de EDICOM para publicar layout de cancelaciones: Codigo [ {0} ]", codigoRespuesta));
            }                
            else
            {
                XmlCancelacion xmlCancelacion = new XmlCancelacion();
                xmlCancelacion.Cancelacion = cancelaciones;

                string
                    _xml = xmlCancelacion.GetXml(),
                    refError = string.Empty;

                /*Registra bitácora del proceso*/
                this.SaveBitacora(BSolCancelacion, "Actualizando estatus de documentos y solicitud....");

                if (!this.UpdateStatus(ref refError, 1002, _xml, codigoRespuesta))
                {
                    /*Registra bitácora del proceso*/
                    this.SaveBitacora(BSolCancelacion, string.Format("Error al actualizar estatus: {0}", refError));

                    this.ReportaError(string.Format("Error al actualizar estatus en publicación EDICOM. CodigoError: {0}, Error: {1}", codigoRespuesta, refError));
                }
                else
                    /*Registra bitácora del proceso*/
                    this.SaveBitacora(BSolCancelacion, "La actualización de estatus se realizo correctamente");
            }
        }

        /// <summary>
        /// Confirma subscripciones
        /// </summary>
        /// <param name="id">Id de subscripción</param>
        /// <param name="outError">out error</param>
        /// <returns></returns>
        private string ConfirmarSubscripcion(string id, ref string outError)
        {
            try
            {
                List<string> requestData = new List<string>();
                requestData.Add("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:com=\"http://com.edicom.broker.adapter.services\">");
                requestData.Add("<soapenv:Header/>");
                requestData.Add("<soapenv:Body>");
                requestData.Add("<com:confirmSubscriptionWS>");
                requestData.Add(string.Format("<clientId>{0}</clientId>", this.SoapEnvCancelaciones.ClientID));
                requestData.Add(string.Format("<user>{0}</user>", this.SoapEnvCancelaciones.User));
                requestData.Add(string.Format("<password>{0}</password>", this.SoapEnvCancelaciones.Password));
                requestData.Add(string.Format("<domain>{0}</domain>", this.SoapEnvCancelaciones.Domain));
                requestData.Add(string.Format("<application>{0}</application>", this.SoapEnvCancelaciones.Application));
                requestData.Add(string.Format("<messageIds>{0}</messageIds>", id));
                requestData.Add("</com:confirmSubscriptionWS>");
                requestData.Add("</soapenv:Body>");
                requestData.Add("</soapenv:Envelope>");

                string stringRequest = string.Join(string.Empty, requestData);
                WebClient webClient = new WebClient();
                webClient.Headers.Add(HttpRequestHeader.ContentType, "application/xop+xml;charset=utf-8");

                string soapResponse = webClient.UploadString(new Uri(this.SoapEnvCancelaciones.EndPoint), string.Join(string.Empty, requestData));
                List<string> responseList = soapResponse.Split(new string[] { "\r\n" }, StringSplitOptions.None).ToList();

                string soapResponseBody = responseList.Where(r => r.Contains("soap:Envelope")).FirstOrDefault();
                XmlDocument soapXml = new XmlDocument();
                soapXml.LoadXml(soapResponseBody);

                return soapXml.GetElementsByTagName("return")[0].InnerText;
            }
            catch (Exception ex)
            {
                outError = ex.ToString();
                return string.Empty;
            }
        }

        /// <summary>
        /// Actualiza estatus de 
        /// </summary>
        /// <param name="refError"></param>
        /// <param name="idStatus"></param>
        /// <param name="xml"></param>
        /// <param name="idEdicom"></param>
        /// <param name="rfcEmisor"></param>
        /// <param name="uuidCancela"></param>
        /// <param name="estatusSAT"></param>
        /// <param name="jsonAcuse"></param>
        /// <returns></returns>
        private bool UpdateStatus(ref string refError, int idStatus, string xml = "", string idEdicom = "", string rfcEmisor = "", string uuidCancela = "", int estatusSAT = 0, string jsonAcuse = "", string estado = "", string estatusCancelacion = "", string esCancelable = "")
        {
            try
            {
                DynamicParameters paref = new DynamicParameters();
                paref.Add("@IdStatus", idStatus, DbType.Int32);
                paref.Add("@XmlCancelaciones", xml, DbType.Xml);
                paref.Add("@IdEdicom", idEdicom, DbType.String);

                paref.Add("@RfcEmisor", rfcEmisor, DbType.String);
                paref.Add("@UuidCancelacion", uuidCancela, DbType.String);
                paref.Add("@EstatusSAT", estatusSAT, DbType.Int64);
                paref.Add("@JsonResponse", jsonAcuse, DbType.String);
                paref.Add("@Estado", estado, DbType.String);
                paref.Add("@EstatusCancelacion", estatusCancelacion, DbType.String);
                paref.Add("@EsCancelable", esCancelable, DbType.String);
                using (IDbConnection db = new SqlConnection(this.ConnectionStringSoporte))
                    db.Query("[CANCELACIONES].[sp_UpdateStatus]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260);

                return true;
            }
            catch (Exception ex)
            {
                refError = ex.ToString();
                return false;
            }
        }

        /// <summary>
        /// Reporta error por correo
        /// </summary>
        /// <param name="mensaje"></param>
        private void ReportaError(string mensaje)
        {
            DynamicParameters paref = new DynamicParameters();
            paref.Add("@IdIntegracion", 14, DbType.Int32);
            paref.Add("@DataJSON", "", DbType.String);
            paref.Add("@Mensaje", mensaje, DbType.String);
            using (IDbConnection db = new SqlConnection(this.ConnectionStringServicioCorreos))
                db.Query("[GENERICO].[BI_encolarEnvio]", paref, commandType: CommandType.StoredProcedure, commandTimeout: 260);
        }
    }
}
