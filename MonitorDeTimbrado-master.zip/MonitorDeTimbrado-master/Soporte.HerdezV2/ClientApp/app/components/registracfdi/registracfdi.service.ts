﻿import { Injectable } from "@angular/core";
import { NgIf } from '@angular/common';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class RegistraCfdiService {

    private baseUrl: string = '';

    constructor(private httpClient: HttpClient) {
        this.baseUrl = '/api/';
    }
     
    public PostRegistraCfdi(files: any[], usuario: string) {
        const frmData = new FormData();

        for (let file of files)
            frmData.append('Files', file.file, file.name);

        frmData.append('Usuario', usuario);

        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any>(`${this.baseUrl}PostRegistraCfdi`, frmData, { headers: headers });
    }

    public GetRegistroCfdiHistorico() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.httpClient.get<any>(`${this.baseUrl}GetRegistroCfdiHistorico`, { headers: _headers });
    }
}