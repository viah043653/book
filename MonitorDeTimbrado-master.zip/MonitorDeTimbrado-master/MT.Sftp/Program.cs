﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace MT.Sftp
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombreArchivo = "";

            try
            {
                var result = new Models.Result();
                var credentials = new Models.Credentials(args[1], args[2], args[3], args[4]);

                switch (int.Parse(args[0]))
                {
                    case 1:
                        Pacs.Carvajal oCarvajal = new Pacs.Carvajal();
                        result = oCarvajal.Connect(credentials);
                        break;
                }

                if (result.Estatus == Models.estatus.OK)
                {
                    nombreArchivo = String.Format("{0}.OK", args[5]);
                    File.WriteAllLines(Path.Combine(@args[6], nombreArchivo), new List<string>() { "Conexión con SFTP --> OK" });
                }
                else
                {
                    nombreArchivo = String.Format("{0}.ERROR", args[5]);
                    File.WriteAllLines(Path.Combine(@args[6], nombreArchivo), new List<string>() { "Conexión con SFTP --> ERROR", result.Mensaje });
                }
            }
            catch (Exception ex)
            {
                nombreArchivo = String.Format("{0}.TXT", args[5]);
                File.WriteAllLines(@"C:\PortalSoporte\Sftp\error", new List<string>() { "Conexión con SFTP --> ERROR", ex.Message, args[6] });
            }
        }
    }
}
