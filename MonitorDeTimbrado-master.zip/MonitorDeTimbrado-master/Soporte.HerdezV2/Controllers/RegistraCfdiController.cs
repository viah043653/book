﻿namespace Soporte.HerdezV2.Controllers
{
    using System;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI;


    [Produces("application/json")]
    [Route("api/RegistraCfdi")]
    public class RegistraCfdiController : Controller
    {
        ValidateRegistraCfdi _validateRegistraCfdi = new ValidateRegistraCfdi();

        // POST api/values
        [Route("~/api/PostRegistraCfdi")]
        [HttpPost]
        public dynamic PostRegistraCfdi()
        {
            var files = HttpContext.Request.Form.Files;
            int idUsuario = Convert.ToInt16(HttpContext.Request.Form["Usuario"]);

            this._validateRegistraCfdi = new ValidateRegistraCfdi();
            var result = this._validateRegistraCfdi.PostRegistro(files, idUsuario);

            return result;
        }

        // POST api/values
        [Route("~/api/GetRegistroCfdiHistorico")]
        [HttpGet]
        public dynamic GetRegistroCfdiHistorico()
        {
            this._validateRegistraCfdi = new ValidateRegistraCfdi();
            return this._validateRegistraCfdi.GetRegistroCfdiHistorico();
        }
    }
}