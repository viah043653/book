﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using Soporte.HerdezV2.Models.Generic;
using Soporte.HerdezV2.Validates.BI;
using System.IO;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;


namespace Soporte.HerdezV2.Controllers
{
    [Authorize]
    [Produces("application/json")]
    [Route("api/DistribucionXmlController")]
    public class DistribucionXmlController: Controller
    {

        ValidateDistribucionXml validatecamest;
        // POST api/values
        [Route("~/api/PostFitimbrado")]
        [HttpPost]
        public IEnumerable PostFitimbrado()
        {


            ValidateDistribucionXml validatefitimbrado = new ValidateDistribucionXml();
            validatefitimbrado = new ValidateDistribucionXml();
            return validatefitimbrado.GetFitimbrado();

        }

        [Route("~/api/PostCamEst")]
        [HttpPost]
        public IEnumerable PostCamEst([FromBody]List<CamEst> cambio)
        {
            validatecamest = new ValidateDistribucionXml();
            return validatecamest.Getcamest(cambio, null);

        }
    }
}
