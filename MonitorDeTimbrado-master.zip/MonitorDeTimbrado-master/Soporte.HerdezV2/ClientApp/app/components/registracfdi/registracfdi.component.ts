﻿import { Component, ViewChild, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSortable } from '@angular/material';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { EnvioIntercambioService } from '../enviointercambio/enviointercambio.service'
import { RegistraCfdiService } from './registracfdi.service';
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/takeUntil';

@Component({
    providers: [SharedService, EnvioIntercambioService, RegistraCfdiService],
    selector: 'registracfdicomponent',
    templateUrl: './registracfdi.component.html',
    styleUrls: ['./registracfdi.style.css']
})

export class RegistraCfdiComponent implements OnInit, OnDestroy {

    private VIEW_ID: number = 8;

    ShowTable: boolean = true;
    ShowSpinnerTable: boolean = true;
    isSearchCleanVisible: boolean = false;
    
    files: any[] = [];

    isActionButtonsVisible: boolean = false;

    displayedColumns = ['emisor', 'documento', 'usuario', 'nombreArchivo', 'mensaje', 'fechaAlta'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);
    filterValue: string = '';

    displayedColumnsArchivos = ['archivo', 'fechaModificacion', 'accion'];
    dataSourceArchivos = new MatTableDataSource<any>();

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService, public sharedservice: SharedService, public localstorageservice: LocalStorageService, public dialog: MatDialog, public enviointercambioservice: EnvioIntercambioService, public registrocfdiservice: RegistraCfdiService) {
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() {
        this.getRetransmisionList();
        Observable.interval(2000 * 60).takeUntil(this.onDestroy$).subscribe(x => {
            this.getRetransmisionList();
        });
    }

    sendFiles(observaciones: string) {
        debugger

        this.spinnerService.show();

        let usuario = this.localstorageservice.GetAuthorizationUser();
        this.registrocfdiservice.PostRegistraCfdi(this.files, usuario.toString()).
            subscribe(
                (data) => {
                    debugger

                    let procesados: any[] = [];

                    if (data.estatus === true) {
                        for (let p of data.cfdis) {
                            let faClass = 'fa fa-bug bg-red';

                            var mensaje = p.mensaje;
                            if (p.estatus === true) {
                                faClass = 'fa fa-check-square-o bg-green';
                                mensaje = 'Documento en proceso de registro, favor de consultar estatus en la sección de Seguimiento Entregas';
                            }

                            procesados.push({ nombreArchivo: p.serie + ' - ' + p.folio, mensaje: mensaje, claseError: faClass });
                        }

                        var dataDetails = { tipoModal: 'errorFolios', data: { titulo: 'Se procesaron ' + procesados.length + ' documento(s)', foliosError: procesados } };

                        this.dialog.open(DialogTimeLineComponent, {
                            width: '570%',
                            height: 'auto',
                            data: dataDetails,
                            panelClass: 'custom-dialog-container2'
                        });
                    }
                    else
                        this.toastr.error(data.mensaje, 'Error');

                    this.regresar();
                },
                response => {
                    this.files = [];
                    this.spinnerService.hide();
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                    this.files = [];
                    this.spinnerService.hide();
                });
    }
    
    getRetransmisionList() {
        this.ShowSpinnerTable = true;
        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);

        debugger
        let procesos: string = "RetransmisiónXml";
        this.registrocfdiservice.GetRegistroCfdiHistorico().
            subscribe(
                (data) => {
                    debugger
                    if (data.estatus === true) {
                        this.dataSource = new MatTableDataSource(data.registros);
                        this.dataSource.paginator = this.paginator;
                        this.sort.sort(({ id: 'fechaAlta', start: 'desc' }) as MatSortable);
                        this.dataSource.sort = this.sort
                        this.selectionCheckBox = new SelectionModel<any>(true, []);
                    }
                    else {
                        this.toastr.error(data.mensage, 'Error');
                    }
                },
                response => {
                    debugger
                    this.ShowSpinnerTable = false;
                    this.sharedservice.catchHttpResponseError(response)
                },
                () => {
                    this.ShowSpinnerTable = false;
                });
    }
    
    getFiles(event: any) {
        debugger

        for (let file of event.target.files) {
            if (file.name.toUpperCase().includes('.XML')) {
                this.files.push({ name: file.name, file: file });
            }            
        }


        if (this.files.length === 0) {
            this.files = [];
            this.toastr.error('Solamente está permitida la carga de archivos Xml', 'Error');
        }
        else {

            this.ShowTable = false;

            this.dataSourceArchivos = new MatTableDataSource(this.files);
            this.dataSourceArchivos.paginator = this.paginator;
            this.dataSourceArchivos.sort = this.sort;
        }
    }

    removeFile(file: any) {
        this.files.splice(this.files.indexOf(file), 1);

        if (this.files.length == 0) {
            this.toastr.info('Se removieron todos los documentos cargados para registro de timbre', 'Sin documentos por registrar');
            this.regresar();
        }
        else {
            this.dataSourceArchivos = new MatTableDataSource(this.files);
            this.dataSourceArchivos.paginator = this.paginator;
            this.dataSourceArchivos.sort = this.sort;
        }
    }

    regresar() {
        this.files = [];
        this.ShowTable = true;
        this.getRetransmisionList();
    }

    applyFilter(clearData: boolean) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }
}