﻿namespace Soporte.HerdezV2.Models.Tables.Catalogos
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("catPacs")]
    public class Pac
    {
        [Key]
        public byte IdPac { get; set; }

        [Required]
        [MaxLength(80)]
        public string Nombre { get; set; }

        [Required]
        public string Logo { get; set; }

        [Required]
        public DateTime FechaAlta { get; set; }

        [Required]
        public byte IdStatus { get; set; }
    }
}