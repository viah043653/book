﻿namespace Soporte.HerdezV2.Validates.BI
{
    using Dapper;
    using Microsoft.AspNetCore.Http;
    using NPOI.HSSF.UserModel;
    using Soporte.HerdezV2.Models.Tables.BI;
    using System;
    using System.Collections.Generic;
    using System.Data.Odbc;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml;

    public class ValidateArchivosIntercambio : Connect
    {
        List<dynamic> errores { get; set; }
        List<string> correctos { get; set; }
        List<XmlNm> xmls = new List<XmlNm>();

        public ValidateArchivosIntercambio()
        {
            this.errores = new List<dynamic>();
            this.correctos = new List<string>();
        }

        public dynamic PostFiles(IFormFileCollection files, string observaciones, int idUsuario)
        {
            try
            {
                foreach (var file in files)
                {
                    string cia = file.FileName.Substring(0, 4);
                    string serie = file.FileName.Substring(4, 1);

                    string _folio = "";
                    foreach (char c in file.FileName.Substring(5, file.FileName.IndexOf('.') - 5))
                    {
                        if (Char.IsLetter(c) || Char.IsSymbol(c) || Char.IsSeparator(c) || Char.IsPunctuation(c) || Char.IsWhiteSpace(c))
                            break;

                        _folio += c.ToString();
                    }

                    PacCompania pac = new PacCompania();
                    long folio = Convert.ToInt64(_folio);
                    switch (cia)
                    {
                        case "0600":
                            pac = _pacsCompanias.Where(p => p.RfcCia == "CHE041201L59").FirstOrDefault();
                            SaveFile(file, pac.RutaReprocesamiento, file.FileName, 60, serie, folio, observaciones, idUsuario, "CargaManual");
                            break;
                        case "0770":
                            pac = _pacsCompanias.Where(p => p.RfcCia == "NUT840801733").FirstOrDefault();
                            SaveFile(file, pac.RutaReprocesamiento, file.FileName, 77, serie, folio, observaciones, idUsuario, "CargaManual");
                            break;
                        case "0010":
                            pac = _pacsCompanias.Where(p => p.RfcCia == "HER8301121X4").FirstOrDefault();
                            SaveFile(file, pac.RutaReprocesamiento, file.FileName, 1, serie, folio, observaciones, idUsuario, "CargaManual");
                            break;
                        case "0920":
                            pac = _pacsCompanias.Where(p => p.RfcCia == "OCO160809URA").FirstOrDefault();
                            SaveFile(file, pac.RutaReprocesamiento, file.FileName, 92, serie, folio, observaciones, idUsuario, "CargaManual");
                            break;
                        case "0430":
                            pac = _pacsCompanias.Where(p => p.RfcCia == "HER980609NC1").FirstOrDefault();
                            SaveFile(file, pac.RutaReprocesamiento, file.FileName, 43, serie, folio, observaciones, idUsuario, "CargaManual");
                            break;
                        case "0950":
                            pac = _pacsCompanias.Where(p => p.RfcCia == "KSN200902B97").FirstOrDefault();
                            SaveFile(file, pac.RutaReprocesamiento, file.FileName, 95, serie, folio, observaciones, idUsuario, "CargaManual");
                            break;
                        case "1020":
                            pac = _pacsCompanias.Where(p => p.RfcCia == "ROC020422UV9").FirstOrDefault();
                            SaveFile(file, pac.RutaReprocesamiento, file.FileName, 102, serie, folio, observaciones, idUsuario, "CargaManual");
                            break;
                    }
                }

                return new
                {
                    estatus = "OK",
                    resultados = new
                    {
                        procesados = correctos,
                        errores = errores
                    }
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    estatus = "ERROR",
                    mensaje = ex.Message
                };
            }
        }

        public dynamic PostRegeneracion(string cia, string serie, long folio, int usuario, string observaciones)
        {
            try
            {
                using (var connection = new OdbcConnection(this.ConnectionStringAS400_Produccion))
                {
                    string _sucursal = "000";
                    string _serie = serie + " ";
                    string _folio = folio.ToString("000000000");

                    connection.Open();
                    connection.Execute("{ { CALL HDZFAE.FE023006('" + cia + "', '" + _sucursal + "', '" + _serie + "', '" + _folio + "', '') } }");
                }

                int _numCia = int.Parse(cia.Substring(0, 3));
                SaveBitacora(_numCia, folio, "", observaciones, serie, usuario, "Regeneración", false, "");

                return new
                {
                    estatus = "OK"
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    estatus = "ERROR",
                    mensaje = ex.Message
                };
            }
        }

        public dynamic PostRetransmision(IFormFileCollection files, string observaciones, int idUsuario, string esCambioCajas)
        {
            List<RetransmisionXml> retransmisionesLst = new List<RetransmisionXml>();
            List<CsvFolio> foliosCsv = new List<CsvFolio>();
            xmls = new List<XmlNm>();

            foreach (var file in files)
            {
                if (Path.GetExtension(file.FileName) == ".csv")
                {
                    List<string> csvData = new List<string>();
                    using (var ms = new MemoryStream())
                    {
                        file.CopyTo(ms);
                        ms.Flush();
                        ms.Position = 0;
                        csvData = Encoding.UTF8.GetString(ms.ToArray()).Split(new[] { Environment.NewLine }, StringSplitOptions.None).ToList();
                    }
                    foliosCsv = csvData.Select(c => new CsvFolio(c.Split(','))).Where(c => !string.IsNullOrEmpty(c.factura) && !string.IsNullOrEmpty(c.cantidad) && !string.IsNullOrEmpty(c.ean13) && !string.IsNullOrEmpty(c.importeUnitario)).ToList();
                }
                else if (Path.GetExtension(file.FileName).ToUpper() == ".XML")
                {
                    XmlDocument xmlDoc = new XmlDocument();

                    using (var ms = new MemoryStream())
                    {
                        file.CopyTo(ms);
                        ms.Flush();
                        ms.Position = 0;
                        xmlDoc.Load(ms);
                    }

                    xmls.Add(new XmlNm (){ xml = xmlDoc, nombreArchivo = file.FileName });
                }
            }

            if (foliosCsv.Count > 0)
                foliosCsv.RemoveAt(0);

            if (esCambioCajas == "TRUE" && foliosCsv.Count == 0)
            {
                return new List<RetransmisionXml>() { new RetransmisionXml()
                {
                    fecha = DateTime.Now,
                    documento = "Verificar CSV",
                    estatus = "REJECT",
                    mensaje = "No se está adjuntando CSV o este no contiene información."
                } };
            }

            if (esCambioCajas == "TRUE")
                ReCalcularSoriana(foliosCsv);

            foreach (var xmlO in xmls)
            {
                RetransmisionXml retransmision = new RetransmisionXml();
                retransmision.documento = xmlO.nombreArchivo;
                retransmision.fecha = DateTime.Now;
                retransmision.mensaje = "Archivo retransmitido correctamente. Favor de consultar en el portal del cliente";

                string _serie = string.Empty;
                long _folio = 0;
                int _cia = 0;

                try
                {
                    string xmlContent = xmlO.xml.InnerXml;

                    var nodoEmisor = ((XmlElement)xmlO.xml.GetElementsByTagName("cfdi:Emisor")[0]);

                    string _rfc = nodoEmisor.Attributes["Rfc"] == null ? nodoEmisor.Attributes["rfc"].Value : nodoEmisor.Attributes["Rfc"].Value;

                    switch (_rfc)
                    {
                        case "HER8301121X4": _cia = 1; break;
                        case "CHE041201L59": _cia = 60; break;
                        case "NUT840801733": _cia = 77; break;
                        case "OCO160809URA": _cia = 99; break;
                    }

                    var nodoComprobante = ((XmlElement)xmlO.xml.GetElementsByTagName("cfdi:Comprobante")[0]);

                    _serie = nodoComprobante.Attributes["Serie"] == null ? nodoComprobante.Attributes["serie"].Value : nodoComprobante.Attributes["Serie"].Value;
                    _folio = nodoComprobante.Attributes["Folio"] == null ? Convert.ToInt64(nodoComprobante.Attributes["folio"].Value) : Convert.ToInt64(nodoComprobante.Attributes["Folio"].Value);


                    var task = ConsumeWS(xmlContent);
                    task.Wait();

                    var s = task.Result.Body.RecibeCFDResult;

                    XmlDocument AckErrorApplication = new XmlDocument();
                    AckErrorApplication.LoadXml(task.Result.Body.RecibeCFDResult);

                    retransmision.estatus = ((XmlElement)AckErrorApplication.GetElementsByTagName("AckErrorApplication")[0]).Attributes["documentStatus"].Value;

                    if (retransmision.estatus == "REJECT")
                        retransmision.mensaje = ((XmlElement)AckErrorApplication.GetElementsByTagName("errorDescription")[0]).ChildNodes[0].InnerText;

                    string nombreFolder = string.Format("E:\\PortalMT\\RetransmisionSoriana\\{0}\\{1}\\{2}\\", DateTime.Now.Year, DateTime.Now.Month.ToString("00"), DateTime.Now.Day.ToString("00"));

                    if (!Directory.Exists(nombreFolder))
                        Directory.CreateDirectory(nombreFolder);

                    string fullPathArchivo = string.Format("{0}{1}", nombreFolder, xmlO.nombreArchivo);

                    if (File.Exists(fullPathArchivo))
                        File.Delete(fullPathArchivo);

                    xmlO.xml.Save(fullPathArchivo);
                }
                catch (Exception ex)
                {
                    retransmision.estatus = "ERROR";
                    retransmision.mensaje = ex.Message;
                }

                var bitacoraLst = _context.Bitacora.Where(b => b.Cia == _cia && b.Serie == _serie && b.Folio == _folio).ToList();
                if (bitacoraLst.Count == 0)
                    SaveBitacora(_cia, _folio, retransmision.documento, observaciones, _serie, idUsuario, "RetransmisiónXml", true, retransmision.estatus, retransmision.mensaje);
                else
                {
                    var bitacoraAccepted = bitacoraLst.Where(b => b.Estatus == "ACCEPTED").FirstOrDefault();
                    if (bitacoraAccepted == null)
                        SaveBitacora(_cia, _folio, retransmision.documento, observaciones, _serie, idUsuario, "RetransmisiónXml", true, retransmision.estatus, retransmision.mensaje);
                    else
                    {
                        retransmision.estatus = "ACCEPTED";
                        retransmision.mensaje = "El documento ya se había retransmitido correctamente en la fecha " + bitacoraAccepted.FechaAlta.ToString();
                    }
                }

                retransmisionesLst.Add(retransmision);
            }

            return retransmisionesLst;
        }

        private void ReCalcularSoriana(List<CsvFolio> csvFolios)
        {
            foreach (XmlNm _xml in xmls)
            {
                double subTotal = 0, total = 0, descuentos = 0, ieps = 0, iva = 0;

                string factura = _xml.xml.GetElementsByTagName("cfdi:Comprobante")[0].Attributes["Folio"].Value.Trim();

                foreach (XmlElement articulo in _xml.xml.GetElementsByTagName("cfdi:Addenda")[0].SelectNodes("DSCargaRemisionProv/Articulos"))
                {
                    var codigo = articulo.GetElementsByTagName("Codigo")[0].InnerText.Trim();

                    var datosCodigo = csvFolios.Where(f => f.ean13 == codigo && f.factura == factura).FirstOrDefault();
                    if (datosCodigo != null)
                    {
                        articulo.GetElementsByTagName("CantidadUnidadCompra")[0].InnerText = datosCodigo.cantidad;
                        articulo.GetElementsByTagName("CostoNetoUnidadCompra")[0].InnerText = datosCodigo.importeUnitario;
                    }

                    Int64 cantidad = Convert.ToInt64(articulo.GetElementsByTagName("CantidadUnidadCompra")[0].InnerText);
                    double precio = Convert.ToDouble(articulo.GetElementsByTagName("CostoNetoUnidadCompra")[0].InnerText);

                    subTotal = subTotal + (precio * cantidad);
                }

                _xml.xml.GetElementsByTagName("cfdi:Addenda")[0].SelectSingleNode("DSCargaRemisionProv/Remision/Subtotal").InnerText = Math.Round(subTotal, 2).ToString();
                descuentos = Convert.ToDouble(_xml.xml.GetElementsByTagName("cfdi:Addenda")[0].SelectSingleNode("DSCargaRemisionProv/Remision/Descuentos").InnerText);
                ieps = Convert.ToDouble(_xml.xml.GetElementsByTagName("cfdi:Addenda")[0].SelectSingleNode("DSCargaRemisionProv/Remision/IEPS").InnerText);
                iva = Convert.ToDouble(_xml.xml.GetElementsByTagName("cfdi:Addenda")[0].SelectSingleNode("DSCargaRemisionProv/Remision/IVA").InnerText);

                total = subTotal - descuentos + ieps + iva;
                _xml.xml.GetElementsByTagName("cfdi:Addenda")[0].SelectSingleNode("DSCargaRemisionProv/Remision/Total").InnerText = Math.Round(total, 2).ToString();
            }
        }

        private async Task<wsSoriana.RecibeCFDResponse> ConsumeWS(string xml)
        {
            wsSoriana.wseDocReciboSoapClient wsClient = new wsSoriana.wseDocReciboSoapClient(wsSoriana.wseDocReciboSoapClient.EndpointConfiguration.wseDocReciboSoap12);
            return await wsClient.RecibeCFDAsync(xml);
        }

        private void SaveFile(IFormFile file, string path, string nombre, int cia, string serie, long folio, string observaciones, int idUsuario, string proceso, bool esRetransmisionXml = false, string estatus = "")
        {
            try
            {
                string fullPath = Path.Combine(path, nombre);
                using (var fileStream = new FileStream(fullPath, FileMode.Create))
                    file.CopyTo(fileStream);

                SaveBitacora(cia, folio, nombre, observaciones, serie, idUsuario, proceso, esRetransmisionXml, estatus);

                this.correctos.Add(nombre);
            }
            catch (Exception ex)
            {
                this.errores.Add(new { archivo = nombre, error = ex.Message });
            }
        }

        public void SaveBitacora(int cia, long folio, string nombreArchivo, string observaciones, string serie, int idUsuario, string proceso, bool esRetransmisionXml, string estatus, string error = "")
        {
            Bitacora oBitacora = new Bitacora();
            oBitacora.Cia = cia;
            oBitacora.FechaAlta = DateTime.Now;
            oBitacora.Folio = folio;
            oBitacora.NombreArchivo = nombreArchivo;
            oBitacora.Observaciones = observaciones;
            oBitacora.Serie = serie;
            oBitacora.IdUsuario = idUsuario;
            oBitacora.Proceso = proceso;
            if (esRetransmisionXml)
                oBitacora.Estatus = estatus;

            if (!string.IsNullOrEmpty(error))
                oBitacora.Error = error;

            this._context.Bitacora.Add(oBitacora);
            this._context.SaveChanges();
        }

        private void CambiosEnAdendaSoriana()
        {

        }

        public class RetransmisionXml
        {
            public string estatus { get; set; }
            public string mensaje { get; set; }
            public string documento { get; set; }
            public DateTime fecha { get; set; }
        }

        public class CsvFolio
        {
            public string factura { get; set; }
            public string cantidad { get; set; }
            public string ean13 { get; set; }
            public string importeUnitario { get; set; }

            public CsvFolio(string[] columnas)
            {
                if (columnas.Length >= 4)
                {
                    this.factura = columnas[0].Trim();
                    this.cantidad = columnas[1].Trim();
                    this.ean13 = columnas[2].Trim();
                    this.importeUnitario = columnas[3].ToString().Replace("$", "").Trim();
                }
            }
        }

        public class XmlNm
        {
            public XmlDocument xml { get; set; }
            public string nombreArchivo { get; set; }
        }
    }
}