﻿import { Component, ViewChild, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { JobInstanciaTxtService } from './jobinstanciatxt.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { EnvioIntercambioService } from '../enviointercambio/enviointercambio.service'
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/takeUntil';

@Component({
    providers: [JobInstanciaTxtService, SharedService, EnvioIntercambioService],
    selector: 'jobinstanciatxt',
    templateUrl: './jobinstanciatxt.component.html',
    styleUrls: ['./jobinstanciatxt.style.css']
})

export class JobInstanciaTxtComponent implements OnInit, OnDestroy {

    private VIEW_ID: number = 17;

    isActionButtonsVisible: boolean = false;
    ShowSpinnerTable: boolean = true;
    isSearchCleanVisible: boolean = false;

    displayedColumns = [
        'ClaveInstancia',
        'Servidor',
        'NombreCia',
        'DescripcionTipoDeDocumento',
        //'DescripcionTipoIteracion',
        'Intervalo',
        //'TiposDeFactura',
        //'EstatusDocumento',
        'FechaAlta',
        'UltimaEjecucion',
        'SiguienteEjecucion',
        
        'EsInstanciaActiva',
        'Configuracion'
    ];

    dataSource = new MatTableDataSource<any>();

    switchPreparaBD: boolean = false;
    switchCancelaEDIWIN: boolean = false;

    filterValue: string = '';

    instanciasConfiguradas: any[] = [];

    companias: any[] = [];
    servidores: any[] = [];
    tiposDeDocumentos: any[] = [];
    tiposDeIteracion: any[] = [];

    cia: string = '';
    ciaID: number = 0;

    servidor: string = '';
    servidorID: string = '';

    tipoDeDocumento: string = '';
    tipoDeDocumentoID: number = 0;

    tipoDeIteracion: string = '';
    tipoDeIteracionID: string = '';

    intervaloEjecucion: number = 1;
    nombreInstancia: string = '';
    folderDestino: string = '';
    tiposDeFactura: string = '';
    estatusDeDocumento: number = 5;
    esInstanciaActiva: boolean = false;

    mostrarAcciones: boolean = false;
    accionRefacturacion: boolean = false;
    accionCancelacion: boolean = false;
    accionesConfiguradas: boolean = false;

    ShowCaptura: boolean = false;
    EsModificacion: boolean = false; 

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService, public jobInstanciaTXTService: JobInstanciaTxtService, public sharedservice: SharedService, public localstorageservice: LocalStorageService, public enviointercambioservice: EnvioIntercambioService, public dialog: MatDialog) {
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() {

        debugger

        this.ShowCaptura = false;
        this.EsModificacion = false;

        this.limpiar();

        this.instanciasConfiguradas = [];
        this.companias = [];
        this.servidores = [];
        this.tiposDeDocumentos = [];
        this.tiposDeIteracion = [];

        /*Obtiene listado de compañías*/
        this.jobInstanciaTXTService.GetCias().
            subscribe(
                (data) => {
                    debugger
                    this.companias = data;
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                });

        /*Obtiene listado de servidores*/
        this.jobInstanciaTXTService.GetServidores().
            subscribe(
                (data) => {
                    debugger
                    this.servidores = data;
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                });

        /*Obtiene listado de tipos de documento*/
        this.jobInstanciaTXTService.GetTiposDeDocumento().
            subscribe(
                (data) => {
                    debugger
                    this.tiposDeDocumentos = data;
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                });

        /*Obtiene listado de tipos de iteracion*/
        this.jobInstanciaTXTService.GetTipoIteracion().
            subscribe(
                (data) => {
                    debugger
                    this.tiposDeIteracion = data;
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                });

        //this.tiposDeDocumentos = [];
        //this.sharedservice.GetTiposDeDocumentos().
        //    subscribe(
        //        (data) => {
        //            debugger
        //            this.tiposDeDocumentos = data;
        //        },
        //        response => {
        //            this.sharedservice.catchHttpResponseError(response);
        //        },
        //        () => {
        //            this.spinnerService.hide();
        //        });

        this.mostrarAcciones = false;
        this.accionCancelacion = false;
        this.accionRefacturacion = false;
        this.accionesConfiguradas = false;

        this.switchCancelaEDIWIN = false;
        this.switchPreparaBD = false;

        let dataActions = this.localstorageservice.GetActions(this.VIEW_ID)

        for (let action of dataActions) {
            switch (action.numeroAccion) {
                case 22:
                    this.accionRefacturacion = true;
                    this.switchPreparaBD = true;
                    break;
                case 23:
                    this.accionCancelacion = true;
                    this.switchCancelaEDIWIN = true;
                    break;
            }
        }

        this.mostrarAcciones = this.accionCancelacion && this.accionRefacturacion;
        this.accionesConfiguradas = this.accionCancelacion || this.accionRefacturacion;

        if (this.mostrarAcciones) {
            this.switchPreparaBD = true;
            this.switchCancelaEDIWIN = false;
        }

        this.getInstanciasConfiguradas();
        Observable.interval(1000 * 60).takeUntil(this.onDestroy$).subscribe(x => {
            this.getInstanciasConfiguradas();
        });
    }

    setCia(_cia: any) {
        this.cia = _cia.Rfc;// + " - " + _cia.Nombre;
        this.ciaID = _cia.IdCia;
    }

    setServidor(_servidor: any) {
        this.servidor = _servidor.Servidor;
        this.servidorID = _servidor.Servidor;
    }

    setTipoDeDocumento(_tipoDoc: any) {
        this.tipoDeDocumento = _tipoDoc.Descripcion;
        this.tipoDeDocumentoID = _tipoDoc.ClaveTipoDeDocumento;
    }

    setTipoIteracion(_iteracion: any) {
        this.tipoDeIteracion = _iteracion.Descripcion;
        this.tipoDeIteracionID = _iteracion.IdTipoIteracion;
    }

    mostrarFormularioParaCaptura() {
        this.limpiar();
        this.EsModificacion = false;
        this.ShowCaptura = true;
    }

    cancelarInstancia() {
        this.ShowCaptura = false;
    }

    eliminarInstancia(instancia: any, motivo: string) {
        debugger

        if (motivo === '') {
            this.toastr.error('El motivo es obligatorio', 'Error');
            return;
        }

        this.spinnerService.show();
        this.jobInstanciaTXTService.DeleteInstancia(this.localstorageservice.GetAuthorizationUser(), instancia, motivo).
            subscribe(
                (data) => {
                    debugger
                    if (data.estatus == 'OK') {
                        this.toastr.success(data.mensaje, 'Eliminación de instancia');
                        this.getInstanciasConfiguradas();
                    }
                    else {
                        this.toastr.error(data.mensaje, 'Error al eliminar instancia');
                    }
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                    this.spinnerService.hide();
                },
                () => {
                    this.spinnerService.hide();
                });

    }

    crearInstancia() {
        debugger

        var data = {
            NombreInstancia: this.nombreInstancia,
            Cia: this.ciaID,
            Servidor: this.servidorID,
            TipoDeDocumentos: this.tipoDeDocumentoID,
            TipoDeIntervalo: this.tipoDeIteracionID,
            Intervalo: this.intervaloEjecucion,
            FolderDestino: this.folderDestino,
            TiposDePedidos: this.tiposDeFactura,
            EsInstanciaActiva: this.esInstanciaActiva,
            EstatusDeDocumento: this.estatusDeDocumento,
            IdUsuario: this.localstorageservice.GetAuthorizationUser(),
            EsModificacion: this.EsModificacion
        };

        if (data.Cia == 0
            || data.EstatusDeDocumento == null
            || data.FolderDestino == ''
            || data.Intervalo == null
            || data.NombreInstancia == ''
            || data.Servidor == ''
            || data.TipoDeDocumentos == 0
            || data.TipoDeIntervalo == ''
            || data.TiposDePedidos == ''
        ) {
            this.toastr.error('Todos los datos son obligatorios', 'Error');
            return;
        }

        if (data.Intervalo <= 0) {
            this.toastr.error('El intervalo de ejecución debe ser mayor a 0', 'Error');
            return;
        }

        this.spinnerService.show();
        this.jobInstanciaTXTService.PostInstancia(data).
            subscribe(
                (data) => {
                    debugger
                    if (data.estatus == 'OK') {
                        this.ShowCaptura = false;
                        this.toastr.success(data.mensaje, 'Configuración de instancia');
                        this.getInstanciasConfiguradas();

                        this.limpiar();
                    }
                    else {
                        this.toastr.error(data.mensaje, 'Error');
                    }
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                    this.spinnerService.hide();
                },
                () => {
                    this.spinnerService.hide();
                });
    }

    getInstanciasConfiguradas() {

        this.ShowSpinnerTable = true;
        this.dataSource = new MatTableDataSource<any>();

        this.jobInstanciaTXTService.GetInstanciasConfiguradas().
            subscribe(
                (data) => {
                    debugger
                    this.instanciasConfiguradas = data;

                    this.dataSource = new MatTableDataSource(this.instanciasConfiguradas);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                    this.ShowSpinnerTable = false;
                },
                () => {
                    this.ShowSpinnerTable = false;
                });
    }

    mostrarConfirmacionSwitch(instancia: string) {
        debugger
        let element: HTMLElement = document.getElementById(instancia) as HTMLElement;

        element.click();
    }

    switchInstancia(instancia: string, esConfirmacion: boolean) {
        debugger
        if (!esConfirmacion) {
            for (let dat of this.instanciasConfiguradas) {
                if (dat.ClaveInstancia == instancia) {
                    dat.EsInstanciaActiva = !dat.EsInstanciaActiva;
                    break;
                }
            }
        }
        else {
            this.spinnerService.show();

            this.jobInstanciaTXTService.PostSwitchInstancia(instancia, this.localstorageservice.GetAuthorizationUser()).
                subscribe(
                    (data) => {
                        debugger
                        if (data.estatus == 'ERROR')
                            this.toastr.error(data.mensaje, 'Error en cambio de estatus');
                        else {
                            this.toastr.success(data.mensaje);

                            this.getInstanciasConfiguradas();
                        }
                    },
                    response => {
                        this.sharedservice.catchHttpResponseError(response);
                        this.spinnerService.hide();
                    },
                    () => {
                        this.spinnerService.hide();
                    });
        }
    }

    mostrarPanelDeModificacion(dat: any) {
        this.limpiar();

        this.EsModificacion = true;
        this.ShowCaptura = true;

        //for (let dat of this.instanciasConfiguradas) {
        //    if (dat.ClaveInstancia == claveInstancia) {

                this.nombreInstancia = dat.NombreInstancia;
                this.ciaID = dat.IdCia;
                this.servidorID = dat.Servidor;
                this.tipoDeDocumentoID = dat.ClaveTipoDeDocumento;
                this.tipoDeIteracionID = dat.IdTipoIteracion;
                this.intervaloEjecucion = dat.Intervalo;
                this.folderDestino = dat.FolderDestino;
                this.tiposDeFactura = dat.TiposDeFactura;
                this.esInstanciaActiva = dat.EsInstanciaActiva;
                this.estatusDeDocumento = dat.EstatusDocumento;

                this.cia = dat.NombreCia;
                this.servidor = dat.Servidor;
                this.tipoDeDocumento = dat.DescripcionTipoDeDocumento;
                this.tipoDeIteracion = dat.DescripcionTipoIteracion;
                
        //        break;
        //    }
        //}
    }

    //mostrarDetalles(dat: any) {
    //    debugger
    //}

    setAccion(idAccion: number) {
        switch (idAccion) {
            case 1:
                this.switchCancelaEDIWIN = this.switchPreparaBD;
                break;
            case 2:
                this.switchPreparaBD = this.switchCancelaEDIWIN;
                break;
        }
    }

    mostrarDetalles(dat: any) {
        debugger

        var dataDetails = { tipoModal: 'jobInstanciaTXT', data: dat};

        this.dialog.open(DialogTimeLineComponent, {
            width: '80%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }

    refacturarDocumento(observaciones: string) {
        debugger

        //let banderaActiva: boolean = this.switchPreparaBD || this.switchCancelaEDIWIN;

        //if (this.serieID == '' || this.ciaID == '' || this.folio == undefined) {
        //    this.toastr.error('Todos los datos son obligatorios', 'Error');
        //    return;
        //}
        //if (this.folio <= 0) {
        //    this.toastr.error('El folio del documento tiene que ser mayor a 0', 'Error');
        //    return;
        //}

        //if (!banderaActiva) {
        //    this.toastr.error('Por lo menos debe activar una acción', 'Error');
        //    return;
        //}

        //if (observaciones == '') {
        //    this.toastr.error('Los comentarios son obligatorios.', 'Error');
        //    let element: HTMLElement = document.getElementById('btnSend') as HTMLElement;
        //    element.click();
        //    return;
        //}

        //this.spinnerService.show();

        ////let usuario = this.localstorageservice.GetAuthorizationUser();
        ////this.refacturacionesService.
        ////    PostRefactura(this.ciaID, this.serieID, this.folio, observaciones, this.switchPreparaBD, this.switchCancelaEDIWIN, usuario).
        ////    subscribe(
        ////        (data) => {
        ////            debugger
        ////            if (data.estatus == 'OK') {

        ////                let dataDetails: any = {};
        ////                let desgloze: any[] = [];

        ////                if (data.mensaje.PreparaBD == true) {
        ////                    desgloze.push(
        ////                        {
        ////                            proceso: 'Solicitud de cancelación',
        ////                            tipoLinea: 1,
        ////                            mensaje: data.mensaje.EstatusCancelacion,
        ////                            localizadoEnFE090F: data.mensaje.DocumentoLocalizadoEnFE090F,
        ////                            localizadoEnUuidsProcesados: data.mensaje.DocumentoLocalizadoEnUuidsProcesados,
        ////                            claseError: data.mensaje.EstatusCancelacion.includes('El documento fue marcado para ser cancelado') ? 'fa fa-check bg-green' : 'fa fa-bug bg-red'
        ////                        });
        ////                }
        ////                else
        ////                    desgloze.push(
        ////                        {
        ////                            proceso: 'Solicitud de cancelación',
        ////                            tipoLinea: 2,
        ////                            mensaje: data.mensaje.EstatusCancelacion,
        ////                            claseError: data.mensaje.EstatusCancelacion.includes('El documento fue marcado para ser cancelado') ? 'fa fa-check bg-green' : 'fa fa-bug bg-red'
        ////                        });

        ////                dataDetails = { tipoModal: 'responseCancelacion', data: { foliosError: desgloze } };

        ////                this.dialog.open(DialogTimeLineComponent, {
        ////                    width: '470%',
        ////                    height: 'auto',
        ////                    data: dataDetails,
        ////                    panelClass: 'custom-dialog-container2'
        ////                });

        ////                this.getRegeneracionList();
        ////                this.limpiar();
        ////            }
        ////            else {
        ////                this.toastr.error(data.mensaje, 'Error en proceso de cancelación');
        ////            }
        ////        },
        ////        response => {
        ////            this.spinnerService.hide();
        ////            this.sharedservice.catchHttpResponseError(response);
        ////        },
        ////        () => {
        ////            this.spinnerService.hide();
        ////        });
    }

    descargarCsv() {
        //debugger
        //this.spinnerService.show();
        //var datosTablaResumen = [];

        //datosTablaResumen.push({
        //    "emisor": "Emisor",
        //    "documento": "Documento",
        //    "usuario": "Usuario",
        //    "estatus": "Estatus",
        //    "accion": "Acción",
        //    "fechaProcesamiento": "Fecha Procesamiento",
        //    "comentarios": "Comentarios",
        //    "uuidCancela": "UuidCancela"
        //});

        //for (let doc of this.selectionCheckBox.selected) {

        //    //if(doc.IdStatus
        //    datosTablaResumen.push(
        //        {
        //            "emisor": doc.RfcEmisor,
        //            "documento": doc.Serie + '-' + doc.Folio,
        //            "usuario": doc.Nombre,
        //            "estatus": doc.EstatusCancelacion,
        //            "accion": doc.Motivos,
        //            "fechaProcesamiento": doc.FechaProceso,
        //            "comentarios": doc.Comentarios,
        //            "uuidCancela": doc.UuidCancela
        //        }
        //    );
        //}

        //if (this.selectionCheckBox.selected.length > 0) {
        //    new Angular2Csv(datosTablaResumen, 'Resumen de cancelaciones');
        //    this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        //}
        //else
        //    this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        //this.spinnerService.hide();
    }

    limpiar() {
        this.cia = '';
        this.ciaID = 0;

        this.servidor = '';
        this.servidorID = '';

        this.tipoDeDocumento = '';
        this.tipoDeDocumentoID = 0;

        this.tipoDeIteracion = '';
        this.tipoDeIteracionID = '';

        this.intervaloEjecucion = 1;
        this.nombreInstancia = '';
        this.folderDestino = '';
        this.tiposDeFactura = '';
        this.estatusDeDocumento = 5;
        this.esInstanciaActiva = false;
        this.EsModificacion = false;
    }

    applyFilter(clearData: boolean/*filterValue: string*/) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.isActionButtonsVisible = false;
    }
}