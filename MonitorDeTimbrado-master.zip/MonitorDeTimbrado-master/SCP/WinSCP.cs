﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.XPath;
using WinSCP;

namespace SCP
{
    public class WinSCP
    {
        public static void Main()
        {

            string Vfacfdsev = @"\\hdzfac001\FacturasDescargadas\7Eleven\EnvioPM\";

            List<string> oDirectories = Directory.GetFiles(Vfacfdsev, "*.xml").ToList();

            foreach (string oDirectorie in oDirectories)
            {

                if (File.Exists(oDirectorie))
                {

                    string[] Vnomxml = oDirectorie.Split('\\');
                    string Vnomxmld = Vnomxml[6];

                    //File.Copy(Vfoldercorreos, Vfacfdsev + Vnomxmld);

                    #region Envio SCP
                    SessionOptions sessionOptions = new SessionOptions
                    {
                        Protocol = Protocol.Scp,
                        HostName = "www.e7-eleven.com.mx",
                        UserName = "E1X11668",
                        Password = "pr#11668",
                        PortNumber = 2021,
                        SshHostKeyFingerprint = "ssh-rsa 2048 09:e2:75:7e:00:b4:22:26:e6:cd:0c:a2:08:61:e1:50"
                    };
                    using (Session session = new Session())
                    {
                        // Connect
                        session.DisableVersionCheck = true;
                        session.ExecutablePath = @"\\hdzfac001\FacturasDescargadas\7Eleven\EnvioPM\\WinSCP\WinSCP.exe";
                        session.Open(sessionOptions);

                        // Upload files
                        TransferOptions transferOptions = new TransferOptions();
                        transferOptions.TransferMode = TransferMode.Binary;

                        #region subir archivo
                        // determinar nombres de archivo
                        string rfc_receptor = string.Empty, serie = string.Empty, rfc_emisor = string.Empty, rfc_pac = string.Empty;
                        int folio = 0;
                        ;

                        rfc_receptor = ConsultaXPath(Vfacfdsev + Vnomxmld, @"string(/cfdi:Comprobante/cfdi:Receptor/@rfc | /cfdi:Comprobante/cfdi:Receptor/@Rfc)");
                        serie = ConsultaXPath(Vfacfdsev + Vnomxmld, @"string(/cfdi:Comprobante/@serie | /cfdi:Comprobante/@Serie)");
                        folio = int.Parse(ConsultaXPath(Vfacfdsev + Vnomxmld, @"string(/cfdi:Comprobante/@folio | /cfdi:Comprobante/@Folio)"));
                        rfc_emisor = ConsultaXPath(Vfacfdsev + Vnomxmld, @"string(/cfdi:Comprobante/cfdi:Emisor/@rfc | /cfdi:Comprobante/cfdi:Emisor/@Rfc)");
                        rfc_pac = ConsultaXPath(Vfacfdsev + Vnomxmld, "string(/cfdi:Comprobante/cfdi:Complemento/tfd:TimbreFiscalDigital/@RfcProvCertif)");

                        //string customFormat = "yyyyMMdd'T'HH:mm:ss";
                        //DateTime fechaTimbrado = DateTime.ParseExact(ConsultaXPath(archivo.Path, "/cfdi:Comprobante/cfdi:Complemento/tfd:TimbreFiscalDigital/@FechaTimbrado"), customFormat, new CultureInfo("en-US"), DateTimeStyles.None);
                        string FechaTimbrado = ConsultaXPath(Vfacfdsev + Vnomxmld, "string(/cfdi:Comprobante/cfdi:Complemento/tfd:TimbreFiscalDigital/@FechaTimbrado)");


                        TransferOperationResult transferResult;
                        transferResult = session.PutFiles(Vfacfdsev + Vnomxmld, "/home/E1X11668/Facturas/", true, transferOptions);

                        #endregion
                    }
                    #endregion
                }
            }

            string ConsultaXPath(string ArchivoXML, string xpath)
            {
                string ret = string.Empty;
                StringDictionary sd = new StringDictionary();
                XmlDocument document;
                XPathNavigator navigator;
                XmlNamespaceManager manager;

                NavegadorXPath(ArchivoXML, out document, out navigator, out manager);

                XPathExpression xPathExpression = navigator.Compile(xpath);
                xPathExpression.SetContext(manager);

                if (xPathExpression.ReturnType == XPathResultType.String)
                {
                    ret = navigator.Evaluate(xPathExpression).ToString();
                }

                return ret;
            }

            void NavegadorXPath(string ArchivoXML, out XmlDocument document, out XPathNavigator navigator, out XmlNamespaceManager manager)
            {
                StringDictionary sd = new StringDictionary();
                document = new XmlDocument();
                document.Load(ArchivoXML);

                navigator = document.CreateNavigator();
                manager = new XmlNamespaceManager(navigator.NameTable);
                XPathNodeIterator xpathNodeIterator = navigator.Select("//namespace::*[name() != 'xml'][not(../../namespace::*=.)]");
                while (xpathNodeIterator.MoveNext())
                {
                    XPathNavigator current = xpathNodeIterator.Current;
                    if (current.NodeType == XPathNodeType.Namespace)
                    {
                        if (!sd.ContainsKey(current.Name))
                        {
                            manager.AddNamespace(current.Name, current.Value);
                        }
                    }
                }
            }


        }
    }
}
