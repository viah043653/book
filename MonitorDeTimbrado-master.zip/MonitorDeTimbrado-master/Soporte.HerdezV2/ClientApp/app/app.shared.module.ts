import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CdkTableModule } from '@angular/cdk/table';
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http';

import { AppComponent } from './components/app/app.component';
import { NavMenuComponent } from './components/navmenu/navmenu.component';
import { HeaderMenuComponent } from './components/headermenu/headermenu.component';
import { HomeComponent } from './components/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SeguimientoEntregasComponent } from './components/seguimientoentregas/seguimientoentregas.component';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './components/login/auth.guard';
import { DialogTimeLineComponent } from './components/dialog/dialog.timeline.component';
import { EnvioIntercambioComponent } from './components/enviointercambio/enviointercambio.component';
import { RegeneracionAutonomaComponent } from './components/regneracionautonoma/regeneracionautonoma.component';
import { RetransmisionXmlComponent } from './components/retransmisionxml/retransmisionxml.component';
import { PdfComponent } from './components/pdf/pdf.component';
import { ConsultaEnvioClienteComponent } from './components/consultaenviocliente/consultaenviocliente.component';
import { HistoricoTimbradosComponent } from './components/historicotimbrados/historicotimbrados.component';
import { EnviosDocumentosComponent } from './components/enviosdocumentos/enviosdocumentos.component';
import { DistribucionXmlComponent } from './components/distribucionxml/distribucionxml.component';
import { RegistraCfdiComponent } from './components/registracfdi/registracfdi.component';
import { ActualizaTxtRfcGenericoComponent } from './components/actualizatxtrfcgenerico/actualizatxtrfcgenerico.component';
import { RefacturacionesComponent } from './components/refacturaciones/refacturaciones.component';
import { JobInstanciaTxtComponent } from './components/jobinstanciatxt/jobinstanciatxt.component';
import { EnviosCfdisComponent } from './components/enviocfdis/envioscfdis.component';

import { MatInputModule, MatTableModule, MatToolbarModule, MatPaginatorModule, MatSortModule, MatCheckboxModule, MatIconModule } from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog'
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { SweetAlert2Module } from '@toverux/ngx-sweetalert2';
import { GoTopButtonModule } from 'ng2-go-top-button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // angular 4.x and greater

import { InterceptorService } from './components/shared/interceptor.service';
import { LocalStorageService } from './components/shared/localstorage.service';


//import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

declare module 'file-saver';

import { ToastModule, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { ConsultaEnvioClienteService } from './components/consultaenviocliente/consultaenviocliente.service';
import { EnviosTiendasComponent } from './components/enviotienda/enviostiendas.component';

export class CustomOption extends ToastOptions {
    animate = 'flyRight';
    newestOnTop = false;
    showCloseButton = true;
    //dismiss = 'click';
    toastLife = 3000;
    //toastLife = 7000000;
    enableHTML = true;
    positionClass = "toast-top-right";
}

@NgModule({
    declarations: [
        AppComponent,
        NavMenuComponent,
        HeaderMenuComponent,
        SeguimientoEntregasComponent,
        DashboardComponent,
        DialogTimeLineComponent,
        LoginComponent,
        HomeComponent,
        EnvioIntercambioComponent,
        RegeneracionAutonomaComponent,
        RetransmisionXmlComponent,
        PdfComponent,
        ConsultaEnvioClienteComponent,
        HistoricoTimbradosComponent,
        EnviosDocumentosComponent,
        EnviosTiendasComponent,
        DistribucionXmlComponent,
        RegistraCfdiComponent,
        ActualizaTxtRfcGenericoComponent,
        RefacturacionesComponent,
        JobInstanciaTxtComponent,
        EnviosCfdisComponent
    ],
    imports: [
        CommonModule,
        HttpClientModule,
        FormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        MatToolbarModule, MatInputModule, MatTableModule, MatPaginatorModule, MatSortModule, MatDialogModule, MatCheckboxModule, MatIconModule,
        CdkTableModule,
        Ng4LoadingSpinnerModule.forRoot(),
        ToastModule.forRoot(),
        SweetAlert2Module.forRoot(),
        GoTopButtonModule,
        RouterModule.forRoot([
            //{ path: '', redirectTo: 'home', pathMatch: 'full' },
            //{ path: 'home', component: HomeComponent },
            //{ path: 'seguimientoentregas', component: SeguimientoEntregasComponent },
            //{ path: 'login', component: LoginComponent },
            //{ path: '**', redirectTo: 'home' }
            { path: '', component: LoginComponent },
            {
                path: 'monitor', component: HomeComponent, canActivate: [AuthGuard],
                children: [
                    { path: 'seguimientoentregas', component: SeguimientoEntregasComponent },
                    { path: 'dashboard', component: DashboardComponent },
                    { path: 'enviointercambio', component: EnvioIntercambioComponent },
                    { path: 'regeneracionarchivos', component: RegeneracionAutonomaComponent },
                    { path: 'retransmisionarchivos', component: RetransmisionXmlComponent },
                    { path: 'reporteenviosclientes', component: ConsultaEnvioClienteComponent },
                    { path: 'historicotimbrados', component: HistoricoTimbradosComponent },
                    { path: 'enviosdocumentos', component: EnviosDocumentosComponent },
                    { path: 'enviostiendas', component: EnviosTiendasComponent },
                    { path: 'distribucionxml', component: DistribucionXmlComponent },
                    { path: 'registracfdi', component: RegistraCfdiComponent },
                    { path: 'insertarfcgenerico', component: ActualizaTxtRfcGenericoComponent },
                    { path: 'cancelaciones', component: RefacturacionesComponent },
                    { path: 'instanciastxtintercambio', component: JobInstanciaTxtComponent },
                    { path: 'envioscfdis', component: EnviosCfdisComponent }
                ]
            }
        ])
    ],
    entryComponents: [
        DialogTimeLineComponent
    ],
    exports: [
        CommonModule, MatToolbarModule, MatInputModule, MatTableModule, MatPaginatorModule, MatSortModule,
        GoTopButtonModule
    ],
    providers: [
        {
            provide: ToastOptions,
            useClass: CustomOption
        },
        AuthGuard,
        LocalStorageService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: InterceptorService,
            multi: true
        }
    ]
})
export class AppModuleShared {
}