﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Headers } from '@angular/http';
import { Observable } from "rxjs";

@Injectable()
export class RefacturacionesService {

    private baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }

    public PostRefactura(cia: string, serie: string, folio: string, observaciones: string, preparaDB: boolean, cancelaFolio: boolean, usuario: number, idMotivoDeCancelacion: number, esCancelacionMasiva: boolean, archivoExcel: any) {

        const frmData = new FormData();

        if (esCancelacionMasiva)
            frmData.append('Files', archivoExcel.Archivo, archivoExcel.NombreArchivo);

        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostRefacturacion?cia=${cia}&serie=${serie}&folio=${folio}&observaciones=${observaciones}&preparaDB=${preparaDB}&cancelaFolio=${cancelaFolio}&idUsuario=${usuario}&idMotivoDeCancelacion=${idMotivoDeCancelacion}&esCancelacionMasiva=${esCancelacionMasiva}`;

        return this.http.post<any>(postUrl, frmData, { headers: _headers });
    }

    public GetDocumentosPorSolicitud(idSolicitud: number) {

        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}GetDocumentosPorSolicitud?idSolicitud=${idSolicitud}`;

        return this.http.post<any>(postUrl, { headers: _headers });
    }

    public GetHistorico(){
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.get<any>(`${this.baseUrl}GetHistoricoCancelaciones`, { headers: _headers });
    }

    public GetMotivosDeCancelacion() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');
        debugger
        return this.http.get<any[]>(`${this.baseUrl}GetMotivosDeCancelacionPorTipoDeDocumento`, { headers: _headers });
    }
}