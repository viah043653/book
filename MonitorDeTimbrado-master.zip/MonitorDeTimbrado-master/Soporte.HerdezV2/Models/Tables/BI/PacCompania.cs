﻿namespace Soporte.HerdezV2.Models.Tables.BI
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("vw_PacCompania")]
    public class PacCompania
    {
        [Key, Column(Order = 0)]
        [MaxLength(15)]
        public string RfcPac { get; set; }
        [Key, Column(Order = 1)]
        [MaxLength(13)]
        public string RfcCia { get; set; }
        [MaxLength(50)]
        public string RutaProcesados { get; set; }
        [MaxLength(100)]
        public string RutaErrores { get; set; }
        [MaxLength(50)]
        public string RutaReprocesamiento { get; set; }
    }
}