﻿namespace Soporte.HerdezV2.Models.Tables.Catalogos
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("catTipoDeDocumento")]
    public class TipoDeDocumento
    {
        [Key]
        public string Serie { get; set; }

        [Required]
        [MaxLength(20)]
        public string Descripcion { get; set; }

        [Required]
        public DateTime FechaAlta { get; set; }

        [Required]
        public bool EstatusActivo { get; set; }
    }
}
