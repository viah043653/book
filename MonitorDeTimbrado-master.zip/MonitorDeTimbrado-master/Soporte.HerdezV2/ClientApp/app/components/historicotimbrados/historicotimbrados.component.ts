﻿import { Component, ViewChild, OnInit, ViewContainerRef } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { SwalComponent } from '@toverux/ngx-sweetalert2';
import { saveAs } from 'file-saver';

import 'rxjs/add/observable/of';

import { HistoricoTimbradosService } from './historicotimbrados.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';


@Component({
    providers: [HistoricoTimbradosService, SharedService],
    selector: 'historicotimbrados',
    styleUrls: ['./historicotimbrados.style.css'],
    templateUrl: './historicotimbrados.component.html'
})

export class HistoricoTimbradosComponent implements OnInit {

    private VIEW_ID: number = 11;
    /*Variables de acción*/
    PostBusqueda: boolean = false;
    GetIntercambio: boolean = false;
    GetCSV: boolean = false;
    PostRetransmitir: boolean = false;

    interval: any;

    consultaLista: any[] = [];
    retransmision: any[] = [];
    folios: string = '';
    isTableVisble: boolean = false;
    isConcentrado: boolean = false;
    isActionButtonsVisible: boolean = false;
    isSearchCleanVisible: boolean = false;
    showCheckInTable: boolean = true;
    filterValue: string = '';
    concentrado: any = {};

    companias: any[] = [{ 'cia': 1, 'rfc': 'HER8301121X4' }, { 'cia': 92, 'rfc': 'OCO160809URA' }, { 'cia': 60, 'rfc': 'CHE041201L59' }, { 'cia': 77, 'rfc': 'NUT840801733' }];
    companiaSelect: any = {};

    series: string[] = ['A', 'B', 'C', 'D', 'P'];
    serieSelect: string = '';

    receptor: string = '';
    pac: string = '';

    fechaInicial: Date;
    fechaFinal: Date;

    //displayedColumns = ['isChecked', 'rfcEmisor', 'rfcReceptor', 'serie', 'folio', 'folioFiscal', 'fechaTimbrado', 'rfcPac', 'cadena', 'cliente' ];
    displayedColumns = ['isChecked', 'rfcEmisor', 'rfcReceptor', 'serie', 'folio', 'folioFiscal', 'fechaTimbrado', 'rfcPac'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    httpBusqueda: Observable<any[]>;

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;
    @ViewChild('deleteSwal') private deleteSwal: SwalComponent;

    private _busquedaService: HistoricoTimbradosService;
    private _sharedService: SharedService;

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, busquedaService: HistoricoTimbradosService, sharedService: SharedService, private spinnerService: Ng4LoadingSpinnerService, public dialog: MatDialog, private localstorageservice: LocalStorageService) {
        this.toastr.setRootViewContainerRef(vcr);
        this._busquedaService = busquedaService;
        this._sharedService = sharedService;
        this.isSearchCleanVisible = false;
    }

    ngOnInit() {
        this.showCheckInTable = true;
        this.setActions(this.localstorageservice.GetActions(this.VIEW_ID));
    }

    private setActions(_acciones: any[]): void {
        this.cleanActions();
        for (let _accion of _acciones) {
            switch (_accion.nombreAccion) {
                case "PostBusqueda": this.PostBusqueda = true; break;
                case "GetIntercambio": this.GetIntercambio = true; break;
                case "GetCSV": this.GetCSV = true; break;
                case "PostRetransmitir": this.PostRetransmitir = true; break;
            }
        }

        if (!this.GetIntercambio && !this.GetCSV && !this.PostRetransmitir)
            this.showCheckInTable = false;
    }

    private cleanActions() {
        this.PostBusqueda = false;
        this.GetIntercambio = false;
        this.GetCSV = false;
        this.PostRetransmitir = false;
        this.showCheckInTable = true;
    }

    setCia(data: any) { this.companiaSelect = data; }

    setSerie(data: string) { debugger; this.serieSelect = data; }

    iniciarBusqueda() {
        this.spinnerService.show();

        this._busquedaService.PostBusqueda(this.companiaSelect.rfc, this.receptor, this.pac, this.serieSelect, this.fechaInicial, this.fechaFinal).
            subscribe(
                (data) => {
                    debugger
                    this.spinnerService.hide();

                    this.isTableVisble = true;
                    this.interval = setInterval(() => {

                        this.dataSource = new MatTableDataSource(data);
                        this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;

                        clearInterval(this.interval);
                    }, 200);
                    this.toastr.success('La consulta regreso un todal de ' + data.length + ' registro(s)', 'Consulta finalizada');

                    //this.isActionButtonsVisible = data.length > 0;
                },
                response => {
                    this.spinnerService.hide();
                },
                () => {
                    this.spinnerService.hide();
                });
    }

    descargarCsv() {
        this.spinnerService.show();
        var datosTablaResumen = [];

        datosTablaResumen.push({
            "emisor": "Emisor",
            "receptor": "Receptor",
            "serie": "Serie",
            "folio": "Folio",
            "folioFiscal": "Folio Fiscal",
            "fechaTimbrado": "Fecha Timbrado",
            "pac": "Pac"
        });


        for (let doc of this.selectionCheckBox.selected) {

            datosTablaResumen.push(
                {
                    "emisor": doc.RfcEmisor,
                    "receptor": doc.RfcReceptor,
                    "serie": doc.Serie,
                    "folio": doc.Folio,
                    "folioFiscal": doc.FolioFiscal,
                    "fechaTimbrado": doc.FechaTimbrado,
                    "pac": doc.RfcPac
                }
            );
        }


        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();

    }
    
    selectedTab(type: number) {
        this.isConcentrado = type == 1 ? true : false;
    }
    
    applyFilter(clearData: boolean) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}