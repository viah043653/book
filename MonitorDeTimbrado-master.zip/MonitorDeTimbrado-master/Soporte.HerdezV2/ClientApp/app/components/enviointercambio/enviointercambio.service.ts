﻿import { Injectable } from "@angular/core";
import { NgIf } from '@angular/common';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class EnvioIntercambioService {

    private baseUrl: string = '';

    constructor(private httpClient: HttpClient) {
        this.baseUrl = '/api/';
    }

    public PostIntercambio(files: any[], observaciones: string, usuario: string) {
        const frmData = new FormData();

        for (let file of files)
            frmData.append('Files', file.file, file.name);

        frmData.append('Observaciones', observaciones);
        frmData.append('Usuario', usuario);

        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any>(`${this.baseUrl}PostIntercambio`, frmData, { headers: headers });
    }

    public PostBitacora(procesos: string) {
        const frmData = new FormData();
        frmData.append('Procesos', procesos);

        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any[]>(`${this.baseUrl}PostBitacoraHistorico`, frmData, { headers: headers });
    }
}