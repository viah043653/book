﻿namespace Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui
{
    using System;

    public class Folio
    {
        public enum Estatus { Timbrado, SinRegistroDeTimbre }
        public enum EstatusLecturaXml { Localizado, NoLocalizado }

        public string Serie { get; set; }
        public long Numero { get; set; }
        public decimal Importe { get; set; }
        public string Uuid { get; set; }
        public string NombreArchivoXmlLike { get; set; }
        public string NombreArchivoXml { get; set; }
        public string PathXml { get; set; }
        public DateTime? FechaProceso { get; set; }
        public Estatus _Estatus { get; set; }
        public EstatusLecturaXml _EstatusLecturaXml { get; set; }

        private string[] meses = new string[12]
        {
            "enero",
            "febrero",
            "marzo",
            "abril",
            "mayo",
            "junio",
            "julio",
            "agosto",
            "septiembre",
            "octubre",
            "noviembre",
            "diciembre"
        };

        public void SetName()
        {
            if (this.FechaProceso != null && this.FechaProceso != DateTime.MinValue)
            {
                DateTime fp = Convert.ToDateTime(this.FechaProceso);
                this.NombreArchivoXmlLike = string.Format("TCH850701RM1_{0}_{1}_774956_", this.Serie, this.Numero);
                this.NombreArchivoXml = string.Format("TCH850701RM1_{0}_{1}_774956_{2}.xml", this.Serie, this.Numero, fp.ToString("ddMMyyyy"));
                this.PathXml = string.Format(@"\\HDZFAC001\Aplicaciones\ProcesaXML\FolderCorreos\{0}\{1} - {2}\{3}\", fp.Year, fp.Month.ToString("00"), meses[fp.Month - 1], fp.ToString("yyyyMMdd"));
            }
            
            this._Estatus = FechaProceso == null ? Estatus.SinRegistroDeTimbre : Estatus.Timbrado;
        }
    }
}