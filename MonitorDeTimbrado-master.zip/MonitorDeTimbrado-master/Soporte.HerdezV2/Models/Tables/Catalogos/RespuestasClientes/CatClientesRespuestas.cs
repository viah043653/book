﻿namespace Soporte.HerdezV2.Models.Tables.Catalogos.RespuestasClientes
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    
    [Table("catClientesRespuestasComerciales")]
    public class CatClientesRespuestas
    {
        [Key]
        [MaxLength(18)]
        public string Rfc { get; set; }
        [Required]
        [MaxLength(100)]
        public string Nombre { get; set; }
        [Required]
        public DateTime FechaAlta { get; set; }
        public DateTime FechaModificacion { get; set; }
        [Required]
        public byte IdStatus { get; set; }
    }
}
