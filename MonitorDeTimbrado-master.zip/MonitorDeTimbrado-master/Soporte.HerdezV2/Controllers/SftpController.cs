﻿namespace Soporte.HerdezV2.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Authorization;
    using Soporte.HerdezV2.Validates.BI;
    using System.Collections;

    [Authorize]
    [Produces("application/json")]
    [Route("api/Sftp")]
    public class SftpController : Controller
    {
        ValidateSftp _validateSftp = new ValidateSftp();

        [Route("~/api/PostSftpEstatus")]
        [HttpPost]
        public IEnumerable PostSftp([FromBody]int[] pacs)
        {
            _validateSftp = new ValidateSftp();
            var result = _validateSftp.isActiveConnection(pacs);
            return result;
        }
    }
}