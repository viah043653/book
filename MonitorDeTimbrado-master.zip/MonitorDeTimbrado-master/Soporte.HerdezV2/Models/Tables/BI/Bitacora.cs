﻿namespace Soporte.HerdezV2.Models.Tables.BI
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("biBitacora")]
    public class Bitacora
    {
        [Key]
        public long IdBitacora { get; set; }
        [Required]
        public int IdUsuario { get; set; }
        [Required]
        public int Cia { get; set; }
        [Required]
        [MaxLength(2)]
        public string Serie { get; set; }
        [Required]
        public long Folio { get; set; }
        [Required]
        [MaxLength(20)]
        public string Proceso { get; set; }
        [MaxLength(10)]
        public string Estatus { get; set; }
        [Required]
        [MaxLength(80)]
        public string NombreArchivo { get; set; }
        [Required]
        public string Observaciones { get; set; }
        public string Error { get; set; }
        [Required]
        public DateTime FechaAlta { get; set; }

        public Catalogos.User User { get; set; }
    }
}