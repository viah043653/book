﻿import { Component, ViewContainerRef, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Router } from '@angular/router';

import { LoginService } from './login.service';
import { LocalStorageService } from '../shared/localstorage.service';

import { Md5 } from 'ts-md5';
//import * as bcrypt from 'bcryptjs';
import * as CryptoJS from 'crypto-js';

@Component({
    providers: [LoginService],
    selector: 'login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.style.css']
})
export class LoginComponent implements OnInit {

    usuario: string = '';
    password: string = '';

    showLogin: boolean = true;
    showLoginBack: boolean = false;
    showAnimation: boolean = false;

    displayBlockLogin: boolean = true;
    displayBlockRegister: boolean = false;

    cambioPassword1: string = '';
    cambioPassword2: string = '';

    constructor(private spinnerService: Ng4LoadingSpinnerService,
        private loginService: LoginService,
        public toastr: ToastsManager,
        vcr: ViewContainerRef,
        private router: Router,
        private localStorageService: LocalStorageService) {

        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnInit() {

        this.usuario = '';
        this.password = '';
        this.cambioPassword1 = '';
        this.cambioPassword2 = '';
        
        let authData = this.localStorageService.GetAuthorizationData();
        if (authData != null)
            this.router.navigate(['/monitor']);

        this.brandAnimation();
        this.showLogin = true;
        this.showLoginBack = false;
    }

    login() {
        if (this.usuario == "" || this.password == "") {
            this.toastr.error('El usuario y password son datos obligatorios', 'Error');
            return;
        }
        
        this.displayBlockRegister = false;
        this.displayBlockLogin = true;

        this.spinnerService.show();

        debugger

        var key = CryptoJS.enc.Utf8.parse('9889276456839648');
        var iv = CryptoJS.enc.Utf8.parse('9889276456839648'); 

        var _usuario = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(this.usuario), key,
            {
                keySize: 128 / 8,
                iv: iv,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7
            });

        var _password = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(this.password), key,
            {
                keySize: 128 / 8,
                iv: iv,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7
            });

        this.loginService.login(_usuario.toString(), _password.toString()).subscribe(
            (user) => {

                this.spinnerService.hide();
                
                this.localStorageService.SetAuthorizationData(user);
                let oauthData = this.localStorageService.GetAuthorizationData();

                if (!oauthData._userData.ngUser.cambioPass)
                    this.showPasswordChange();
                else
                    this.router.navigate(['/monitor']);

            },
            response => {
                this.spinnerService.hide();
                if (response.status == 401)
                    this.toastr.error('Los datos ingresados no son correctos', 'Error');
                else
                    this.toastr.error('Error en conexión con el servidor.', 'Error');

                this.localStorageService.RemoveAuthorizationData();
            });
    }

    returnLogin() {

        this.usuario = '';
        this.password = '';
        this.cambioPassword1 = '';
        this.cambioPassword2 = '';

        this.showLogin = true;
        this.brandAnimation();

        this.showLoginBack = true;
        this.displayBlockLogin = true;

        setTimeout(() => {
            this.displayBlockRegister = false;
        }, 500);

        setTimeout(() => {
            this.showLoginBack = false;
        }, 1000);
    }

    changePassword() {
        debugger
        if (this.cambioPassword1 != '' && this.cambioPassword2 != '') {
            if (this.cambioPassword1 == this.cambioPassword2) {
                if (this.cambioPassword1 != this.password) {
                    if (this.cambioPassword1.length >= 8) {

                        this.spinnerService.show();

                        this.loginService.changePassword(this.usuario, this.password, this.cambioPassword1).subscribe(
                            (user) => {
                                debugger
                                this.spinnerService.hide();

                                if (user.status == "OK") {
                                    this.toastr.success('La actualización de la contraseña se realizo correctamente.', 'Cambio de contraseña');
                                    this.returnLogin();
                                }
                                else
                                    this.toastr.error(user.descripcion, 'Error');
                            },
                            response => {
                                debugger
                                this.spinnerService.hide();
                                this.toastr.error('Error en conexión con el servidor.', 'Error');

                                this.localStorageService.RemoveAuthorizationData();
                            });
                    }
                    else
                        this.toastr.error('La longitud de la contraseña tiene que ser mayor o igual a 8 dígitos', 'Error');
                }
                else
                    this.toastr.error('La contraseña tiene que ser diferente a la actual', 'Error');
            }
            else
                this.toastr.error('Las contraseñas no coinciden', 'Error');
        }
        else
            this.toastr.error('La contraseña y la confirmación son obligatorias.', 'Error');
    }

    private showPasswordChange() {
        this.localStorageService.RemoveAuthorizationData();

        this.brandAnimation();

        this.toastr.info('Favor de cambiar su contraseña', 'Cambio de contraseña');

        this.showLogin = false;

        setTimeout(() => {
            this.displayBlockLogin = false;
        }, 500);

        this.displayBlockRegister = true;
    }

    private brandAnimation() {
        this.showAnimation = true;
        setTimeout(() => {
            this.showAnimation = false;
        }, 1000);
    }
}