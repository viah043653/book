﻿namespace Soporte.HerdezV2.Validates.BI
{
    using Dapper;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Xml;
    using System.Xml.Serialization;
    using System.Text;
    using System.Globalization;
    using System.Threading.Tasks;
    using System.IO.Compression;
    using Microsoft.AspNetCore.Http;

    public class ValidatePdf : Connect
    {
        private string[] meses = new string[12]
        {
            "enero",
            "febrero",
            "marzo",
            "abril",
            "mayo",
            "junio",
            "julio",
            "agosto",
            "septiembre",
            "octubre",
            "noviembre",
            "diciembre"
        };

        private string nmFechaHoraSS = "", fullPathCarpeta = "", fullPathZip = "";

        public ValidatePdf()
        {
            nmFechaHoraSS = DateTime.Now.ToString("HHmmss");
            fullPathCarpeta = string.Format("{0}XmlToPdf_{1}", this.RutaTemporal, nmFechaHoraSS);
            fullPathZip = string.Format("{0}XmlToPdf_{1}.zip", this.RutaTemporal, nmFechaHoraSS);

            if (!Directory.Exists(fullPathCarpeta)) Directory.CreateDirectory(fullPathCarpeta);

            DirectoryInfo dInfo = new DirectoryInfo(this.RutaTemporal);
            var zipEliminar = dInfo.GetFiles("*.zip").Where(f => f.LastWriteTime < DateTime.Now.AddMinutes(-20)).ToList();
            var carpetasEliminar = dInfo.GetDirectories().Where(d => d.LastWriteTime < DateTime.Now.AddMinutes(-20)).ToList();

            foreach (var zip in zipEliminar) File.Delete(zip.FullName);
            foreach (var carpeta in carpetasEliminar) Directory.Delete(carpeta.FullName, true);
        }

        public string PostXmlToPdf(List<XmlBusquedaDocumento> documentos, ref List<dynamic> outResultadosProceso)
        {
            XmlBusqueda xmlBusqueda = new XmlBusqueda();
            xmlBusqueda.Documento = documentos;

            string xml = xmlBusqueda.GetXml<XmlBusqueda>(xmlBusqueda);

            var docInfoResult = new List<DocInfo>();
            var prms = new DynamicParameters();
            prms.Add("@XmlBusqueda", xml, DbType.Xml);

            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                docInfoResult = db.Query<DocInfo>("sp_ConsultaFechasDeTimbrado", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            foreach (DocInfo doc in docInfoResult)
            {
                try
                {
                    if (string.IsNullOrEmpty(doc.FechaTimbre) || doc.FechaTimbre == "0")
                        outResultadosProceso.Add(new { Emisor = doc.RfcEmisor, Serie = doc.Serie, Folio = doc.Folio, Error = "El documento no se encuentra en la relación de timbrados" });
                    //else if (string.IsNullOrEmpty(doc.RfcReceptor))
                    //    outResultadosProceso.Add(new { Emisor = doc.RfcEmisor, Serie = doc.Serie, Folio = doc.Folio, Error = "El documento no tiene registro en seguimiento entregas" });
                    else
                    {
                        DateTime ft = DateTime.ParseExact(doc.FechaTimbre, "yyyyMMdd", CultureInfo.InvariantCulture);
                        string nombreXml = string.Format("{0}_{1}_{2}_774956_{3}.xml", string.IsNullOrEmpty(doc.RfcReceptor) ? "*" : doc.RfcReceptor, doc.Serie, doc.Folio, ft.ToString("ddMMyyyy"));
                        string path = string.Format(@"\\HDZFAC001\Aplicaciones\ProcesaXML\FolderCorreos\{0}\{1} - {2}\{3}\", ft.Year, ft.Month.ToString("00"), meses[ft.Month - 1], ft.ToString("yyyyMMdd"));

                        string fullPathServer = string.Format("{0}{1}", path, nombreXml);
                        string fullPathCopy = string.Format("{0}\\{1}", fullPathCarpeta, Path.GetFileName(fullPathServer));

                        try
                        {
                            //NetworkCredential networkCredential = new NetworkCredential(this.CredencialesHDZFAC001.Usuario, this.CredencialesHDZFAC001.Password, this.CredencialesHDZFAC001.Dominio);
                            //NetworkConnection networkConnection = new NetworkConnection(@"\\HDZFAC001\Aplicaciones", networkCredential);

                            if (nombreXml[0] == '*')
                            {
                                string[] documentosLike = Directory.GetFiles(path, nombreXml);

                                foreach (string docLike in documentosLike)
                                {
                                    string pathCopyLike = string.Format("{0}\\{1}", fullPathCarpeta, Path.GetFileName(docLike));
                                    SendFileWS(docLike, pathCopyLike, Path.GetFileName(docLike), doc, ref outResultadosProceso);
                                }

                            }
                            else
                            {
                                if (!File.Exists(fullPathServer))
                                    outResultadosProceso.Add(new { Emisor = doc.RfcEmisor, Serie = doc.Serie, Folio = doc.Folio, Error = "El documento no se encuentra en la fecha: " + doc.FechaTimbre });
                                else
                                    SendFileWS(fullPathServer, fullPathCopy, nombreXml, doc, ref outResultadosProceso);
                            }
                        }
                        catch (Exception ex)
                        {
                            outResultadosProceso.Add(new { Emisor = doc.RfcEmisor, Serie = doc.Serie, Folio = doc.Folio, Error = "No se tiene acceso al backup de documentos" });
                        }
                    }
                }
                catch (Exception ex)
                {
                    outResultadosProceso.Add(new { Emisor = doc.RfcEmisor, Serie = doc.Serie, Folio = doc.Folio, Error = ex.ToString() });
                }
            }

            ZipFile.CreateFromDirectory(fullPathCarpeta, fullPathZip, CompressionLevel.Optimal, true);

            return outResultadosProceso.Count != docInfoResult.Count ? fullPathZip : "";
        }

        void SendFileWS(string fullPathServer, string fullPathCopy, string nombreXml, DocInfo doc, ref List<dynamic> outResultadosProceso)
        {
            File.Copy(fullPathServer, fullPathCopy);

            var task = ConsumeWSPdf(File.ReadAllText(fullPathCopy, Encoding.UTF8), nombreXml);
            task.Wait();

            wsPdf.DataResponsePdf[] responsePdfs = task.Result;
            foreach (wsPdf.DataResponsePdf responsePdf in responsePdfs)
            {
                if (responsePdf.Estatus == wsPdf.Status.Ok)
                {
                    XmlDocument xDocCambios = new XmlDocument();
                    xDocCambios.Load(fullPathCopy);

                    XmlNodeList nodosAdenda = xDocCambios.GetElementsByTagName("cfdi:Addenda");
                    if (nodosAdenda.Count > 1)
                    {
                        for (int i = 0; i < nodosAdenda.Count; i++)
                            if (nodosAdenda[i].InnerXml.Contains("lev1add:EDCINVOICE"))
                                nodosAdenda[i].ParentNode.RemoveChild(nodosAdenda[i]);
                        xDocCambios.Save(fullPathCopy);
                    }

                    File.WriteAllBytes(string.Format("{0}\\{1}", fullPathCarpeta, responsePdf.NombrePdf), responsePdf.Pdf);
                }
                else
                    outResultadosProceso.Add(new { Emisor = doc.RfcEmisor, Serie = doc.Serie, Folio = doc.Folio, Error = string.Format("{0} - {1}", responsePdf.Error.IdError, responsePdf.Error.Mensaje) });
            }
        }

        public string PostXmlToPdfWithFile(IFormFileCollection files, ref List<dynamic> outResultadosProceso)
        {
            List<DocInfo> docInfoResult = new List<DocInfo>();
            foreach (var file in files)
            {
                XmlDocument xmlDoc = new XmlDocument();

                using (var ms = new MemoryStream())
                {
                    file.CopyTo(ms);
                    ms.Flush();
                    ms.Position = 0;

                    var fileBytes = ms.ToArray();
                    xmlDoc.Load(ms);
                }

                string _folio = GetAttribute(xmlDoc, "cfdi:Comprobante", "Folio");
                string _serie = GetAttribute(xmlDoc, "cfdi:Comprobante", "Serie");
                string _rfcEmisor = GetAttribute(xmlDoc, "cfdi:Emisor", "Rfc");
                string _rfcReceptor = GetAttribute(xmlDoc, "cfdi:Receptor", "Rfc");
                string _fechaTimbrado = GetAttribute(xmlDoc, "tfd:TimbreFiscalDigital", "FechaTimbrado");

                docInfoResult.Add(new DocInfo()
                {
                    Serie = _serie,
                    Folio = Convert.ToInt64(_folio),
                    RfcEmisor = _rfcEmisor,
                    RfcReceptor = _rfcReceptor,
                    FechaTimbre = _fechaTimbrado
                });

                var task = ConsumeWSPdf(xmlDoc.InnerXml, file.FileName);
                task.Wait();

                wsPdf.DataResponsePdf[] responsePdfs = task.Result;
                foreach (wsPdf.DataResponsePdf responsePdf in responsePdfs)
                {
                    if (responsePdf.Estatus == wsPdf.Status.Ok)
                        File.WriteAllBytes(string.Format("{0}\\{1}", fullPathCarpeta, responsePdf.NombrePdf), responsePdf.Pdf);
                    else
                        outResultadosProceso.Add(new { Emisor = _rfcEmisor, Serie = _serie, Folio = _folio, Error = string.Format("{0} - {1}", responsePdf.Error.IdError, responsePdf.Error.Mensaje) });
                }
            }

            ZipFile.CreateFromDirectory(fullPathCarpeta, fullPathZip, CompressionLevel.Optimal, true);

            return outResultadosProceso.Count != docInfoResult.Count ? fullPathZip : "";
        }

        string GetAttribute(XmlDocument cfdi, string nodo, string atributo)
        {
            XmlAttribute attValue = ((XmlElement)cfdi.GetElementsByTagName(nodo)[0]).Attributes[atributo];
            return attValue == null ? ((XmlElement)cfdi.GetElementsByTagName(nodo)[0]).Attributes[atributo.ToLower()].Value : attValue.Value;
        }

        private async Task<wsPdf.DataResponsePdf[]> ConsumeWSPdf(string xml, string nombreXml)
        {
            wsPdf.DataRequestPdf dataRequestPdf = new wsPdf.DataRequestPdf();
            dataRequestPdf.usuario = "HRDZPIDISTRIBUCION";
            dataRequestPdf.password = "CNVRT3RXm|T09D5ISMXN";
            dataRequestPdf.nombreXml = nombreXml;
            dataRequestPdf.xml = xml;

            wsPdf.PdfClient pdfClient = new wsPdf.PdfClient();
            return await pdfClient.ConvertToPdfAsync(dataRequestPdf);
        }

        public class PdfResult
        {
            public PdfResult(string json, string xmlNombre)
            {
                JObject jPdf = JObject.Parse(json);
                Estatus = (int)jPdf["Estatus"];
                Pdf = (string)jPdf["Pdf"];
                NombrePdf = (string)jPdf["NombrePdf"];
                NombreCfdi = xmlNombre;
                Detalle = (string)jPdf["Detalle"];
            }

            public int Estatus { get; set; }
            public string Pdf { get; set; }
            public string NombrePdf { get; set; }
            public string NombreCfdi { get; set; }
            public string Detalle { get; set; }
        }

        public class DocInfo
        {
            public string RfcEmisor { get; set; }
            public string RfcReceptor { get; set; }
            public string Serie { get; set; }
            public long Folio { get; set; }
            public string FechaTimbre { get; set; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
        public partial class XmlBusqueda
        {
            private List<XmlBusquedaDocumento> documentoField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute("Documento")]
            public List<XmlBusquedaDocumento> Documento
            {
                get
                {
                    return this.documentoField;
                }
                set
                {
                    this.documentoField = value;
                }
            }

            public string GetXml<T>(T objct)
            {
                string xmlCFDIResultField = string.Empty;
                XmlDocument xmlCFDI = new XmlDocument();
                var xmlSerializer = new XmlSerializer(typeof(T));

                XmlWriterSettings settings = new XmlWriterSettings()
                {
                    Encoding = new UnicodeEncoding(false, false),
                    Indent = false,
                    OmitXmlDeclaration = false
                };

                using (StringWriter sWriter = new StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(sWriter, settings))
                    {
                        xmlSerializer.Serialize(sWriter, objct, null);
                        xmlCFDI.LoadXml(sWriter.ToString());
                    }
                }
                xmlCFDIResultField = xmlCFDI.InnerXml;
                using (MemoryStream mStream = new MemoryStream())
                {
                    using (XmlTextWriter writer = new XmlTextWriter(mStream, Encoding.UTF8))
                    {
                        XmlDocument document = new XmlDocument();
                        document.LoadXml(xmlCFDI.InnerXml);

                        writer.Formatting = System.Xml.Formatting.Indented;

                        document.WriteContentTo(writer);
                        writer.Flush();

                        mStream.Flush();
                        mStream.Position = 0;

                        using (StreamReader sReader = new StreamReader(mStream, Encoding.UTF8))
                            xmlCFDIResultField = sReader.ReadToEnd();
                    }
                }
                return xmlCFDIResultField;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class XmlBusquedaDocumento
        {
            private string rfcField = "";
            private string serieField = "";
            private long folioField = 0;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Rfc
            {
                get
                {
                    return this.rfcField;
                }
                set
                {
                    this.rfcField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Serie
            {
                get
                {
                    return this.serieField;
                }
                set
                {
                    this.serieField  = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public long Folio {
                get
                {
                    return this.folioField;
                }
                set
                {
                    this.folioField = value;
                }
            }
        }
    }
}