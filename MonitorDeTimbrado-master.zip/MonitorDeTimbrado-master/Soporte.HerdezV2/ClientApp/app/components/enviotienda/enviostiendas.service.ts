﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Headers } from '@angular/http';

@Injectable()
export class EnviosTiendasService {

    private baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }

    public GetEntTie(folio: string) {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostEntTie?folio=${folio}`;

        return this.http.post<any>(postUrl, { headers: _headers });
    }

   
}