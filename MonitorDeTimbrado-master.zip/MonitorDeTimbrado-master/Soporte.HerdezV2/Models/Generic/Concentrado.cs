﻿namespace Soporte.HerdezV2.Models.Generic
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class Concentrado
    {
        public string Almacen { get; set; }
        public string Tipo { get; set; }
        public int Numero { get; set; }
    }
}