﻿namespace Soporte.HerdezV2.Models.Generic
{
    public class CamEst
    {
        public int fenum { get; set; }
        public string feser { get; set; }
        public long stA001 { get; set; }
    }
}

