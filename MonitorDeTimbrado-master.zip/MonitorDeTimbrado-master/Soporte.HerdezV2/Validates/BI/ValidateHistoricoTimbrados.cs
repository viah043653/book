﻿using Dapper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Soporte.HerdezV2.Validates.BI
{
    public class ValidateHistoricoTimbrados: Connect
    {
        public IEnumerable Get(string rfcEmisor, string rfcReceptor, string rfcPac, string serie, DateTime? fechaInicial, DateTime? fechaFinal)
        {
            IEnumerable result;

            var prms = new DynamicParameters();
            prms.Add("@RfcEmisor", rfcEmisor, DbType.String);
            prms.Add("@RfcReceptor", rfcReceptor, DbType.String);
            prms.Add("@RfcPac", rfcPac, DbType.String);
            prms.Add("@Serie", serie, DbType.String);
            prms.Add("@Folio", 0, DbType.Int64);
            prms.Add("@FechaTimbradoInicial", fechaInicial = (fechaInicial == DateTime.MinValue ? null : fechaInicial), DbType.Date);
            prms.Add("@FechaTimbradoFinal", fechaFinal = (fechaFinal == DateTime.MinValue ? null : fechaFinal), DbType.Date);

            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                result = db.Query<dynamic>("sp_ConsultaHistoricoTimbrados", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
            return result;
        }
    }
}
