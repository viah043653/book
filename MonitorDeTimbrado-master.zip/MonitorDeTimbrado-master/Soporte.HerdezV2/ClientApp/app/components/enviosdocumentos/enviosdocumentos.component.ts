﻿import { Component, ViewChild, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel, DataSource } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { EnviosDocumentosService } from './enviosdocumentos.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { EnvioIntercambioService } from '../enviointercambio/enviointercambio.service'
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/takeUntil';
import { getAllDebugNodes } from '@angular/core/src/debug/debug_node';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { PropertyRead } from '@angular/compiler';


@Component({
    providers: [EnviosDocumentosService, SharedService, EnvioIntercambioService],
    selector: 'enviosdocumentos',
    templateUrl: './enviosdocumentos.component.html',
    styleUrls: ['./enviosdocumentos.style.css']
})

export class EnviosDocumentosComponent implements OnInit, OnDestroy {

    private VIEW_ID: number = 7;

    
    cia: string= '';
    serie: string = '';
    folio: number;

    ciaID: number;
    serieID: string = '';

    tiposDeDocumentos: any[] = [];

    isActionButtonsVisible: boolean = false;
    ShowSpinnerTable: boolean = true;
    isSearchCleanVisible: boolean = false;

    showCheckInTable: boolean = true;

    isTableVisble: boolean = false;
    interval: any;

    displayedColumns = ['isChecked', 'cliente', 'nombre', 'correo'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    filterValue: string = '';

    companias: any[] = [
        { rfc: 'CHE041201L59', nombre: 'COMPAÑIA COMERCIAL HERDEZ S.A. DE C.V.', numero: '60' },
        { rfc: 'NUT840801733', nombre: 'NUTRISA S.A DE C.V.', numero: '77' },
        { rfc: 'OCO160809URA', nombre: 'OLYEN COFFEE', numero: '92' },
        { rfc: 'HER8301121X4', nombre: 'HERDEZ S.A DE C.V.', numero: '1' },
        { rfc: 'HER980609NC1', nombre: 'HERSEA.', numero: '43' },
        { rfc: 'KSN200902B97', nombre: "KI'TAL SNACKS, S. A. DE C. V.", numero: '95' },
        { rfc: 'ROC020422UV9', nombre: 'RC OPERADORA DE CAFETERIAS S.A. DE C.V.', numero: '102' }
    ];    

    httpBusqueda: Observable<any[]>;

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService, public consultaservice: EnviosDocumentosService, public sharedservice: SharedService, public localstorageservice: LocalStorageService, public enviointercambioservice: EnvioIntercambioService, public dialog: MatDialog) {
        this.toastr.setRootViewContainerRef(vcr);

    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() {

        this.tiposDeDocumentos = [];
        this.sharedservice.GetTiposDeDocumentos().
            subscribe(
                (data) => {
                    debugger
                    this.tiposDeDocumentos = data;
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                    this.spinnerService.hide();
                });

        this.getRegeneracionList();
        Observable.interval(2000 * 60).takeUntil(this.onDestroy$).subscribe(x => {
            this.getRegeneracionList();
        });
    }

    

    setCia(_cia: any) {
        this.cia = _cia.rfc;
        this.ciaID = _cia.numero;
    }

    //setSerie(_serie: string, _descripcion: string) {
    //    this.serie = _serie + ' - ' + _descripcion;
    //    this.serieID = _serie;
    //}

    setSerie(data: any) {
        this.serie = data.serie + ' - ' + data.descripcion;
        this.serieID = data.serie;
    }

    detalleSeguimiento(bitacora: any) {
        let desgloze: any[] = [];
        for (let historico of bitacora.historicoDesgloze)
            desgloze.push({ proceso: historico.proceso, tipoLinea: 1, usuario: historico.usuario, mensaje: historico.observaciones, fechaProceso: historico.fechaProceso, claseError: 'fa fa-repeat bg-blue' })

        let _mensaje = bitacora.mensaje == null ? '' : bitacora.mensaje;
        let _contenido = bitacora.contenido == null ? '' : bitacora.contenido;

        desgloze.push({ proceso: 'Respuesta del PAC', tipoLinea: 2, usuario: bitacora.estatus, mensaje: _mensaje + ' ' + _contenido, fechaProceso: bitacora.fechaProceso, claseError: bitacora.estatus.includes('Error') ? 'fa fa-bug bg-red' : bitacora.estatus.includes('Timbrado') ? 'fa fa-check bg-green' : 'fa fa-exclamation-triangle bg-yellow' });

        var dataDetails = { tipoModal: 'detalleBitacora', data: { titulo: 'Linea de tiempo de regeneraciónes ordenada descendente', foliosError: this.sharedservice.orderDescendingByDate(desgloze, "fechaProceso") } };

        this.dialog.open(DialogTimeLineComponent, {
            width: '570%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }

    regenerarArchivo() {
        this.spinnerService.show();
         this.consultaservice.GetEntrxFoli(this.ciaID, this.serieID, this.folio).subscribe(

            (status) => {

                
                var condicion = status.statuss;
                var listado = status.listadatos;
                var mensajesql = status.mensajeerror;
                debugger
                if (condicion == true)
                {

                    this.isTableVisble = true;
                    
                    this.interval = setInterval(() => {

                        this.dataSource = new MatTableDataSource(listado);
                        this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;

                        clearInterval(this.interval);
                    }, 200);
                    this.toastr.success('La consulta regreso un todal de ' + listado.length + ' registro(s)', 'Consulta finalizada');
                } else {
                    this.toastr.error(mensajesql);
                 }
            },
            response => {
                this.spinnerService.hide();
                this.sharedservice.catchHttpResponseError(response);
            },
            () => {
                this.spinnerService.hide();
            }
        );

    
    }
          
    

    getRegeneracionList() {

        this.ShowSpinnerTable = true
        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);

        let procesos: string = "Regeneración";
        this.enviointercambioservice.PostBitacora(procesos).
            subscribe(
                (data) => {
                    this.dataSource = new MatTableDataSource(data);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;
                    this.selectionCheckBox = new SelectionModel<any>(true, []);
                },
                response => {
                    this.ShowSpinnerTable = false;
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                    this.ShowSpinnerTable = false;
                });
    }

    descargarCsv() {
        this.spinnerService.show();
        var datosTablaResumen = [];

        datosTablaResumen.push({
            "emisor": "Emisor",
            "receptor": "Receptor",
            "serie": "Serie",
            "folio": "Folio",
            "estatus": "Estatus",
            "proceso": "Proceso",
            "fechaProcesamiento": "Fecha Procesamiento",
            "usuario": "Usuario",
            "motivoRetransmision": "Motivo De Retransmisión"
        });


        for (let doc of this.selectionCheckBox.selected) {
            var detalle = '';

            for (let h of doc.historicoDesgloze) {
                datosTablaResumen.push(
                    {
                        "emisor": doc.emisor,
                        "receptor": doc.receptor,
                        "serie": doc.serie,
                        "folio": doc.folio,
                        "estatus": doc.estatus,
                        "proceso": h.proceso,
                        "fechaProcesamiento": h.fechaProceso,
                        "usuario": h.usuario,
                        "motivoRetransmision": h.observaciones
                    }
                );
            }
        }

        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();
    }

    regresar() {
        this.isTableVisble = false;
    }

    limpiar() {
        this.ciaID = 0;
        this.serieID = '';

        this.cia = '';
        this.serie = '';
        this.folio = 0;
        //this.folio = null;
    }

    //applyFilter(filterValue: string) {
    //    filterValue = filterValue.trim();
    //    filterValue = filterValue.toLowerCase();
    //    this.dataSource.filter = filterValue;

    //    this.selectionCheckBox = new SelectionModel<any>(true, []);
    //    this.isActionButtonsVisible = false;
    //}
    applyFilter(clearData: boolean/*filterValue: string*/) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}