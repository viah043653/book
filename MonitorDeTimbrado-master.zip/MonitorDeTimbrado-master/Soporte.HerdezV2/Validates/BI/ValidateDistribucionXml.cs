﻿using Dapper;
using Newtonsoft.Json;
using Soporte.HerdezV2.Models.Generic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.IO.Compression;
using System.Net;

namespace Soporte.HerdezV2.Validates.BI
{
    public class ValidateDistribucionXml : Connect
    {
        ValidateShared vShared = new ValidateShared();
        List<dynamic> lstResultadosError = new List<dynamic>();

       

        public class Docfiti
        {
            public string FESER { get; set; }
            public string FENUM { get; set; }
            public string STA001 { get; set; }
            // public List<dynamic> Fitim { get; set; }
            // public List<dynamic> Fitimparm { get; set; }
        }

        public IEnumerable GetFitimbrado()
        {
            List<Docfiti> resultado = new List<Docfiti>();

             using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
             {

                    resultado = db.Query<Docfiti>("sp_FiTimbrado", commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                
              }
          return resultado;
        }
        
        public IEnumerable Getcamest(List<CamEst> cambio, Concentrado oConcentrado)
        {
            
            try
            {
                List<SpBusquedadFolio> result = new List<SpBusquedadFolio>();

                string spName = string.Empty;
                var prms = new DynamicParameters();

                if (oConcentrado == null)
                {
                    spName = "sp_ConsultaEstatusDocumentos_V2";
                }
                else
                {
                    prms.Add("@Bodega", oConcentrado.Almacen, DbType.String);
                    prms.Add("@Tipo", oConcentrado.Tipo, DbType.String);
                    prms.Add("@Concentrado", oConcentrado.Numero, DbType.Int32);

                    spName = "sp_ConsultarEstatusDocumentosPorConcentrado";
                }

                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                {
                    result = db.Query<SpBusquedadFolio>(spName, prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                }

                result.Select(f =>
                {
                    f.RutaReproceso = vShared.RutaReproceso(f.Cia, f.Serie, f.Folio);
                    return f;
                }).ToList();

                result.Select(f =>
                {
                    f.ClaseEstatus = f.Estatus == "Sin Txt Generado" ? "fa fa-bug bg-red" :
                                     f.Estatus == "Seguimiento" ? "fa fa-bug bg-red" :
                                     f.Estatus == "Timbrado" ? "fa fa-thumbs-o-up bg-green" : "fa fa-warning bg-yellow";
                    return f;
                }).ToList();

                return result;
            }
            catch (Exception ex)
            {
                _Mensaje.Exception = ex.ToString();
                _Mensaje.Descripcion = ex.Message;
                throw new ApplicationException(JsonConvert.SerializeObject(_Mensaje));
            }
        }


    }
}