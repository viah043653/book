﻿namespace Soporte.HerdezV2.Validates.Self
{
    using Dapper;
    using Soporte.HerdezV2.Models.Generic;
    using Soporte.HerdezV2.Models.SP;
    using Soporte.HerdezV2.Models.Tables.Catalogos;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;

    public interface IValidateUser
    {
        dynamic Authenticate(Autenticacion _user);
        //dynamic Authenticate(string username, string password);
        IEnumerable<User> GetAll();
        User GetById(int id);
        User Create(User user, string password);
        void Update(User user, string password = null);
        void Delete(int id);
        dynamic ChangePassword(string userName, string oldPassword, string newPassword);
    }

    public class ValidateUsers : Connect, IValidateUser
    {
        private User _user;

        public ValidateUsers() { }

        public ValidateUsers(User user)
        {
            this._user = user;
        }

        public dynamic Authenticate(Autenticacion _user)
        {
            _user.Decrypt();
            //byte[] outPassHash;
            //byte[] outPassSalt;
            //CreatePasswordHash(password, out outPassHash, out outPassSalt);

            //var usuario = new User()
            //{
            //    NombreUsuario = username,
            //    CambioPass = false,
            //    Conectado = false,
            //    FechaAlta = DateTime.Now,
            //    FechaModificacion = DateTime.Now,
            //    PasswordHash = outPassHash,
            //    PasswordSalt = outPassSalt,
            //    IdPerfil = 2
            //};

            //this._context.Usuarios.Add(usuario);
            ////this._context.Usuarios.Update(usuario);
            //this._context.SaveChanges();

            //var userd = this._context.Usuarios.SingleOrDefault(x => x.NombreUsuario == username);
            //byte[] outPassHash;
            //byte[] outPassSalt;
            //CreatePasswordHash(password, out outPassHash, out outPassSalt);

            //userd.PasswordHash = outPassHash;
            //userd.PasswordSalt = outPassSalt;
            //userd.CambioPass = false;

            //this._context.Usuarios.Update(userd);
            //this._context.SaveChanges();

            //string myPassword = "password";
            //string mySalt = BCrypt.GenerateSalt();
            ////mySalt == "$2a$10$rBV2JDeWW3.vKyeQcM8fFO"
            //string myHash = BCrypt.HashPassword(myPassword, mySalt);
            ////myHash == "$2a$10$rBV2JDeWW3.vKyeQcM8fFO4777l4bVeQgDL6VIkxqlzQ7TCalQvla"
            //bool doesPasswordMatch = BCrypt.CheckPassword(myPassword, myHash);


            if (string.IsNullOrEmpty(_user.DecryptedUser) || string.IsNullOrEmpty(_user.DecryptedPassword))
                return null;

            var user = new UsuarioEmpleado();
            var prmsUserSp = new DynamicParameters();
            prmsUserSp.Add("@Usuario", _user.DecryptedUser, DbType.String);
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                user = db.Query<UsuarioEmpleado>("sp_ObtenerDatosUsuario", prmsUserSp, commandType: CommandType.StoredProcedure, commandTimeout: 260).FirstOrDefault();

            if (user == null)
                return null;

            var pantallasPorPerfil = new List<PantallasPorPerfil>();
            var prmsPantallasPerfil = new DynamicParameters();
            prmsPantallasPerfil.Add("@IdPerfil", user.IdPerfil, DbType.Int32);
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                pantallasPorPerfil = db.Query<PantallasPorPerfil>("sp_ObtenerPantallasPorPerfil", prmsPantallasPerfil, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            if (!VerifyPasswordHash(_user.DecryptedPassword, user.PasswordHash, user.PasswordSalt))
                return null;

            var grpByModuloId = pantallasPorPerfil.
                GroupBy(p => p.IdModulo);

            var modulos = grpByModuloId.
                Where(p => p.Count() > 1).
                Select(p => new
                {
                    modulo = p.Key,
                    nombre = p.FirstOrDefault().NombreModulo,
                    icono = p.FirstOrDefault().IconoModulo,
                    display = "none",
                    pantallas = p.Select(pantalla => new
                    {
                        pantalla = pantalla.IdPantalla,
                        nombre = pantalla.NombrePantalla,
                        componente = pantalla.Componente,
                        icono = pantalla.IconoPantalla,
                        acciones = pantalla.Acciones
                    })
                });

            var vistaUnica = grpByModuloId.
                Where(pu => pu.Count() == 1).
                SelectMany(p => p.ToList());

            return new
            {
                ngUser = new
                {
                    usuario = user.NombreUsuario,
                    nombre = user.FullName(),
                    imagen = user.Imagen,
                    cambioPass = user.CambioPass,
                    puesto = user.Puesto,
                    numU = user.IdUsuario
                },
                ngViews = new
                {
                    modulos = modulos,
                    vistasUnicas = vistaUnica
                }
            };
        }

        public dynamic ChangePassword(string userName, string oldPassword, string newPassword)
        {
            try
            {
                var user = this._context.Usuarios.SingleOrDefault(x => x.NombreUsuario == userName);

                if (user == null)
                    return new
                    {
                        status = "ERROR",
                        descripcion = "El usuario " + userName + " no fue encontrado"
                    };

                if (user.CambioPass)
                    return new
                    {
                        status = "ERROR",
                        descripcion = "El usuario no está habilitado para actualizar su contraseña"
                    };

                if (!VerifyPasswordHash(oldPassword, user.PasswordHash, user.PasswordSalt))
                    return new
                    {
                        status = "ERROR",
                        descripcion = "La contraseña actual del usuario no es valida"
                    };

                byte[] outPassHash;
                byte[] outPassSalt;
                CreatePasswordHash(newPassword, out outPassHash, out outPassSalt);

                user.PasswordHash = outPassHash;
                user.PasswordSalt = outPassSalt;
                user.CambioPass = true;

                this._context.Usuarios.Update(user);
                this._context.SaveChanges();

                return new
                {
                    status = "OK"
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    status = "ERROR",
                    descripcion = ex.Message
                };
            }
        }

        public IEnumerable<User> GetAll()
        {
            return null;
        }

        public User GetById(int id)
        {
            return null;
        }

        public User Create(User user, string password)
        {
            //byte[] outPassHash;
            //byte[] outPassSalt;
            //CreatePasswordHash(password, out outPassHash, out outPassSalt);

            //var usuario = new User()
            //{
            //    NombreUsuario = username,
            //    CambioPass = false,
            //    Conectado = false,
            //    FechaAlta = DateTime.Now,
            //    FechaModificacion = DateTime.Now,
            //    PasswordHash = outPassHash,
            //    PasswordSalt = outPassSalt
            //};

            ////this._context.Usuarios.Add(usuario);

            //this._context.Usuarios.Update(usuario);
            //this._context.SaveChanges();
            return null;
        }

        public void Update(User user, string password = null)
        {
        }

        public void Delete(int id)
        {
        }

        private static void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");

            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        private static bool VerifyPasswordHash(string password, byte[] storedHash, byte[] storedSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");
            if (storedHash.Length != 64) throw new ArgumentException("Invalid length of password hash (64 bytes expected).", "passwordHash");
            if (storedSalt.Length != 128) throw new ArgumentException("Invalid length of password salt (128 bytes expected).", "passwordHash");

            using (var hmac = new System.Security.Cryptography.HMACSHA512(storedSalt))
            {
                var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                for (int i = 0; i < computedHash.Length; i++)
                {
                    if (computedHash[i] != storedHash[i]) return false;
                }
            }

            return true;
        }
    }
}