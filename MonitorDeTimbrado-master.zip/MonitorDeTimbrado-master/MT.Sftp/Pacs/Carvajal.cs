﻿namespace MT.Sftp.Pacs
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Models;
    using WinSCP;

    public class Carvajal: Sftp
    {
        public override Result Connect(Credentials _sftpCredentials)
        {
            try
            {
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = _sftpCredentials.hostName,
                    UserName = _sftpCredentials.userName,
                    Password = _sftpCredentials.password,
                    SshHostKeyFingerprint = _sftpCredentials.sshHostKeyFingerprint
                };

                using (Session session = new Session())
                {
                    session.Open(sessionOptions);
                }

                return new Result()
                {
                    Estatus = estatus.OK
                };
            }
            catch (Exception ex)
            {
                return new Result()
                {
                    Estatus = estatus.ERROR,
                    Mensaje = ex.Message
                };
            }
        }
    }
}