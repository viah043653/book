﻿import { Component, ViewChild, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { ActualizaTxtRfcGenericoService } from './actualizatxtrfcgenerico.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';
import { EnvioIntercambioService } from '../enviointercambio/enviointercambio.service'
import { Observable } from "rxjs/Observable";
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/takeUntil';

@Component({
    providers: [ActualizaTxtRfcGenericoService, SharedService, EnvioIntercambioService],
    selector: 'actualizatxtrfcgenerico',
    templateUrl: './actualizatxtrfcgenerico.component.html',
    styleUrls: ['./actualizatxtrfcgenerico.style.css']
})

export class ActualizaTxtRfcGenericoComponent implements OnInit, OnDestroy {

    private VIEW_ID: number = 16;

    cia: string = '';
    serie: string = '';
    folio: number;

    ciaID: string = '';
    serieID: string = '';

    isActionButtonsVisible: boolean = false;
    ShowSpinnerTable: boolean = true;
    isSearchCleanVisible: boolean = false;

    displayedColumns = ['isChecked', 'emisor', 'serie', 'folio', 'estatus', 'fechaProceso'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    filterValue: string = '';

    companias: any[] = [
        { rfc: 'CHE041201L59', nombre: 'COMPAÑIA COMERCIAL HERDEZ S.A. DE C.V.', numero: '0600' },
        { rfc: 'NUT840801733', nombre: 'NUTRISA S.A DE C.V.', numero: '0770' },
        { rfc: 'OCO160809URA', nombre: 'OLYEN COFFEE', numero: '0920' },
        { rfc: 'HER8301121X4', nombre: 'HERDEZ S.A DE C.V.', numero: '0010' },
        { rfc: 'HER980609NC1', nombre: 'HERSEA', numero: '0430' },
        { rfc: 'KSN200902B97', nombre: "KI'TAL SNACKS, S. A. DE C. V.", numero: '0950' },
        { rfc: 'ROC020422UV9', nombre: 'RC OPERADORA DE CAFETERIAS SA DE CV', numero: '1020' }
    ];

    tiposDeDocumentos: any[] = [];

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    private onDestroy$ = new Subject<void>();

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService, public actualizaTxtRfcGenericoService: ActualizaTxtRfcGenericoService, public sharedservice: SharedService, public localstorageservice: LocalStorageService, public enviointercambioservice: EnvioIntercambioService, public dialog: MatDialog) {
        this.toastr.setRootViewContainerRef(vcr);        
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
    }

    ngOnInit() {

        this.tiposDeDocumentos = [];
        this.sharedservice.GetTiposDeDocumentos().
            subscribe(
                (data) => {
                    debugger
                    this.tiposDeDocumentos = data;
                },
                response => {
                    this.sharedservice.catchHttpResponseError(response);
                },
                () => {
                    this.spinnerService.hide();
                });

        this.getRegeneracionList();
        Observable.interval(2000 * 60).takeUntil(this.onDestroy$).subscribe(x => {
            this.getRegeneracionList();
        });
    }

    setCia(_cia: any) {
        this.cia = _cia.rfc + " - " +_cia.nombre;
        this.ciaID = _cia.numero;
    }

    //setSerie(_serie: string, _descripcion: string) {
    //    this.serie = _serie + ' - ' + _descripcion;
    //    this.serieID = _serie;
    //}

    setSerie(data: any) {
        this.serie = data.serie + ' - ' + data.descripcion;
        this.serieID = data.serie;
    }

    detalleSeguimiento(bitacora: any) {
        let desgloze: any[] = [];
        for (let historico of bitacora.historicoDesgloze)
            desgloze.push({ proceso: historico.proceso, tipoLinea: 1, usuario: historico.usuario, mensaje: historico.observaciones, fechaProceso: historico.fechaProceso, claseError: 'fa fa-repeat bg-blue' })

        let _mensaje = bitacora.mensaje == null ? '' : bitacora.mensaje;
        let _contenido = bitacora.contenido == null ? '' : bitacora.contenido;

        desgloze.push({ proceso: 'Respuesta del PAC', tipoLinea: 2, usuario: bitacora.estatus, mensaje: _mensaje + ' ' + _contenido, fechaProceso: bitacora.fechaProceso, claseError: bitacora.estatus.includes('Error') ? 'fa fa-bug bg-red' : bitacora.estatus.includes('Timbrado') ? 'fa fa-check bg-green' : 'fa fa-exclamation-triangle bg-yellow' });

        var dataDetails = { tipoModal: 'detalleBitacora', data: { titulo: 'Linea de tiempo de regeneraciónes ordenada descendente', foliosError: this.sharedservice.orderDescendingByDate(desgloze, "fechaProceso") } };

        this.dialog.open(DialogTimeLineComponent, {
            width: '570%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }

    regenerarArchivo(observaciones: string) {
        debugger
        if (this.serieID != '' && this.ciaID != '' && this.folio != undefined) {
            if (this.folio > 0) {

                if (observaciones != '') {

                    this.spinnerService.show();

                    let usuario = this.localstorageservice.GetAuthorizationUser();

                    this.actualizaTxtRfcGenericoService.
                        PostActualizaRfcGenerico(this.ciaID, this.serieID, this.folio, usuario, observaciones).
                        subscribe(
                        (data) => {
                            debugger
                            let nombreDocumento = this.ciaID + this.serieID + this.folio + ".TXT";
                            if (data.estatus == 'OK') {
                                this.toastr.success('La actualización del documento ' + nombreDocumento + ' fue éxitosa. Favor de esperar de 5 a 10 minutos para poder visualizar el documento en Seguimiento Entregas', 'Regeneración finalizada');
                                this.limpiar();
                            }
                            else
                                this.toastr.error(data.mensaje, 'Error en actualización de Rfc');
                        },
                        response => {
                            this.spinnerService.hide();
                            this.sharedservice.catchHttpResponseError(response);
                        },
                        () => {
                            this.spinnerService.hide();
                        });
                }
                else {
                    this.toastr.error('Los motivos de la actualización son obligatorias.', 'Error');
                    let element: HTMLElement = document.getElementById('btnSend') as HTMLElement;
                    element.click();
                }
            }
            else
                this.toastr.error('El folio tiene que ser mayor a 0', 'Error');
        }
        else
            this.toastr.error('Todos los datos son obligatorios', 'Error');
    }

    getRegeneracionList() {

        this.ShowSpinnerTable = true;
        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);

        let procesos: string = "InsertaRfc";
        this.enviointercambioservice.PostBitacora(procesos).
            subscribe(
            (data) => {
                this.dataSource = new MatTableDataSource(data);
                this.dataSource.paginator = this.paginator;
                this.dataSource.sort = this.sort;
                this.selectionCheckBox = new SelectionModel<any>(true, []);
            },
            response => {
                this.ShowSpinnerTable = false;
                this.sharedservice.catchHttpResponseError(response);
            },
            () => {
                this.ShowSpinnerTable = false;
            });
    }

    descargarCsv() {
        this.spinnerService.show();
        var datosTablaResumen = [];

        datosTablaResumen.push({
            "emisor": "Emisor",
            "receptor": "Receptor",
            "serie": "Serie",
            "folio": "Folio",
            "estatus": "Estatus",
            "proceso": "Proceso",
            "fechaProcesamiento": "Fecha Procesamiento",
            "usuario": "Usuario",
            "motivoRetransmision": "Motivo De Retransmisión"
        });


        for (let doc of this.selectionCheckBox.selected) {
            var detalle = '';

            for (let h of doc.historicoDesgloze) {
                datosTablaResumen.push(
                    {
                        "emisor": doc.emisor,
                        "receptor": doc.receptor,
                        "serie": doc.serie,
                        "folio": doc.folio,
                        "estatus": doc.estatus,
                        "proceso": h.proceso,
                        "fechaProcesamiento": h.fechaProceso,
                        "usuario": h.usuario,
                        "motivoRetransmision": h.observaciones
                    }
                );
            }
        }

        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();
    }

    limpiar() {
        this.ciaID = '';
        this.serieID = '';

        this.cia = '';
        this.serie = '';
        this.folio = 0;
        //this.folio = null;
    }

    //applyFilter(filterValue: string) {
    //    filterValue = filterValue.trim();
    //    filterValue = filterValue.toLowerCase();
    //    this.dataSource.filter = filterValue;

    //    this.selectionCheckBox = new SelectionModel<any>(true, []);
    //    this.isActionButtonsVisible = false;
    //}
    applyFilter(clearData: boolean/*filterValue: string*/) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}