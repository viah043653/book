﻿export class Concentrado {
    almacen: string
    tipo: string
    numero: number
}