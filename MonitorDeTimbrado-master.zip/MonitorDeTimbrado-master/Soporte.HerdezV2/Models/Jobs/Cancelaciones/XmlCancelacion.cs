﻿namespace Soporte.HerdezV2.Models.Jobs.Cancelaciones
{
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Xml;
    using System.Xml.Serialization;

    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class XmlCancelacion
    {
        private List<Cancelacion> cancelacionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Cancelacion")]
        public List<Cancelacion> Cancelacion
        {
            get
            {
                return this.cancelacionField;
            }
            set
            {
                this.cancelacionField = value;
            }
        }

        public string GetXml()
        {
            string xmlDocResultField = string.Empty;
            XmlDocument xmlDoc = new XmlDocument();
            var xmlSerializer = new XmlSerializer(typeof(XmlCancelacion));

            XmlWriterSettings settings = new XmlWriterSettings()
            {
                Encoding = new UnicodeEncoding(false, false),
                Indent = false,
                OmitXmlDeclaration = false
            };

            using (StringWriter sWriter = new StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(sWriter, settings))
                {
                    xmlSerializer.Serialize(sWriter, this, null);
                    xmlDoc.LoadXml(sWriter.ToString());
                }
            }
            xmlDocResultField = xmlDoc.InnerXml;
            using (MemoryStream mStream = new MemoryStream())
            {
                using (XmlTextWriter writer = new XmlTextWriter(mStream, Encoding.UTF8))
                {
                    XmlDocument document = new XmlDocument();
                    document.LoadXml(xmlDoc.InnerXml);

                    writer.Formatting = System.Xml.Formatting.Indented;

                    document.WriteContentTo(writer);
                    writer.Flush();

                    mStream.Flush();
                    mStream.Position = 0;

                    using (StreamReader sReader = new StreamReader(mStream, Encoding.UTF8))
                        xmlDocResultField = sReader.ReadToEnd();
                }
            }
            return xmlDocResultField;
        }
    }

}
