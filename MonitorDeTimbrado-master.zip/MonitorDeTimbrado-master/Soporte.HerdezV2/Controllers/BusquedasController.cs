﻿namespace Soporte.HerdezV2.Controllers
{
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Mvc;
    using System.Collections;
    using Soporte.HerdezV2.Models.Generic;
    using Soporte.HerdezV2.Validates.BI;
    using System.IO;
    using Microsoft.AspNetCore.Authorization;
    using Newtonsoft.Json;

    [Authorize]
    [Produces("application/json")]
    [Route("api/Busquedas")]
    public class BusquedasController : Controller
    {
        ValidateBusquedas validateBusquedas;

        // POST api/values
        [Route("~/api/PostByFolios")]
        [HttpPost]
        public IEnumerable PostByFolios([FromBody]List<Documento> documentos)
        {
            validateBusquedas = new ValidateBusquedas();
            return validateBusquedas.ConsultaEstatus(documentos, null);
        }

        // POST api/values
        [Route("~/api/PostByConcentrado")]
        [HttpPost]
        public IEnumerable PostByConcentrado([FromBody]Concentrado concentrado)
        {
            validateBusquedas = new ValidateBusquedas();
            return validateBusquedas.ConsultaEstatus(null, concentrado);
        }

        // POST api/values
        [Route("~/api/PostReporceso")]
        [HttpPost]
        public IEnumerable PostReporceso([FromBody]ReprocesoContent reproceso)
        {
            validateBusquedas = new ValidateBusquedas();
            return validateBusquedas.Reproceso(reproceso.reprocesos, reproceso.observaciones, reproceso.usuario);
        }

        // POST api/values
        [Route("~/api/DescargarArchivosIntercambio")]
        [HttpPost]
        public IEnumerable DescargarArchivosIntercambio([FromBody]List<Reproceso> archivosIntercambio)
        {
            validateBusquedas = new ValidateBusquedas();

            List<dynamic> outErrores = new List<dynamic>();
            string fullPathZip = validateBusquedas.GetZip(archivosIntercambio, ref outErrores);

            const string contentType = "application/zip";
            HttpContext.Response.ContentType = contentType;
            HttpContext.Response.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
            
            dynamic result = null;
            if (!string.IsNullOrEmpty(fullPathZip))
                result = new FileContentResult(System.IO.File.ReadAllBytes(fullPathZip), contentType)
                {
                    FileDownloadName = Path.GetFileName(fullPathZip)
                };

            return new List<dynamic>() { new { archivo = result, errores = outErrores } };
        }
    }
}