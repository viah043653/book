﻿namespace Soporte.HerdezV2.Validates.BI
{
    using Dapper;
    using ExcelDataReader;
    using Microsoft.AspNetCore.Http;
    using Microsoft.EntityFrameworkCore.Metadata.Internal;
    using NPOI.SS.Formula.Functions;
    using Soporte.HerdezV2.Models.Generic;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using System.Xml;
    using System.Xml.Serialization;

    public class ValidateRefacturacion : Connect
    {
        /// <summary>
        /// Encola documento para ser cancelado
        /// </summary>
        /// <param name="cia">Compañia</param>
        /// <param name="serie">Serie</param>
        /// <param name="folio">Folio</param>
        /// <param name="observaciones">Motivo de cancelación</param>
        /// <param name="preparaDB">Bandera para indicar si el folio del documento se reutilizara</param>
        /// <param name="cancelaFolio"></param>
        /// <param name="idUsuario">Usuario que cancela el documento</param>
        /// <returns></returns>
        public dynamic PostDocumento(string cia, string serie, string folio, string observaciones, bool preparaDB, bool cancelaFolio, int idUsuario, int idMotivoDeCancelacion, bool esCancelacionMasiva, IFormFile formFile)
        {
            //string pathLogTemp = @"E:\Servicios\error.txt";
            try
            {
                List<string> folios = new List<string>();

                //File.AppendAllLines(pathLogTemp, new List<string>() { "Lectura archivo de excel...." });
                if (esCancelacionMasiva)
                    folios = GetFoliosOnExcel(formFile).ToList();
                else
                    folios.Add(folio);

                //File.AppendAllLines(pathLogTemp, new List<string>() { "Set Folios...." });
                Documentos oDocumentos = new Documentos();
                oDocumentos.Documento = folios.Select(f =>
                {
                    string newfolio = Regex.Replace(f, "[^0-9]", "");

                    int outFolio = 0;
                    int.TryParse(newfolio, out outFolio);
                    return outFolio;
                }).Distinct().Select(f => new DocumentoBusqueda() { Folio = f }).ToList();

                if (oDocumentos.Documento.Count == 0)
                    throw new Exception(esCancelacionMasiva ? "El archivo de excel no cuenta con una lista de folios en la columna A de la hoja 1" : "Favor de proporcionar un folio valido");


                //File.AppendAllLines(pathLogTemp, new List<string>() { "obtiene Xml...." });
                string xml = oDocumentos.GetXml(oDocumentos);

                /*En caso de que la serie ingresada corresponda a una factura se validara la existencia de documentos relacionados*/
                Dictionary<long, List<DocumentoRelacionado>> facturasConDocumentosRelacionados = new Dictionary<long, List<DocumentoRelacionado>>();
                if (this.SeriesFacturas.Contains(serie))
                {

                    //File.AppendAllLines(pathLogTemp, new List<string>() { "Consulta documentos relacionados...." });

                    dynamic docRelacionado = this.GetDocumentosRelacionados(cia, serie, xml);
                    if (docRelacionado.Estatus == "ERROR")
                        throw new Exception(docRelacionado.Mensaje);

                    if (docRelacionado.DocumentosRelacionados.Count > 0)
                        facturasConDocumentosRelacionados = docRelacionado.DocumentosRelacionados;
                }

                if (facturasConDocumentosRelacionados.Count > 0)
                {
                    oDocumentos.Documento = new List<DocumentoBusqueda>();
                    oDocumentos.Documento = folios.Where(f => !facturasConDocumentosRelacionados.Select(x => x.Key.ToString()).Contains(f)).Distinct().Select(f => new DocumentoBusqueda() { Folio = Convert.ToInt64(f) }).ToList();

                    if (oDocumentos.Documento.Count == 0)
                    {
                        return new
                        {
                            Estatus = "DocumentosRelacionados",
                            CantidadDeFacturas = facturasConDocumentosRelacionados.Count,
                            DocumentosRelacionados = facturasConDocumentosRelacionados.SelectMany(f => f.Value.Select(d => new { d.Folio, d.Serie, Factura = string.Format("{0}-{1}", serie, f.Key.ToString()), cia }).ToList()).ToList()
                        };
                    }
                        //throw new Exception(esCancelacionMasiva ? "El archivo de excel no cuenta con una lista de folios en la columna A de la hoja 1" : "Favor de proporcionar un folio valido");

                    xml = oDocumentos.GetXml(oDocumentos);
                }


                //File.AppendAllLines(pathLogTemp, new List<string>() { "Consulta aprobadores...." });
                /*Se valida la existencia de aprobadores*/
                dynamic objAprobador = this.GetAprobadores(idMotivoDeCancelacion);
                if (objAprobador.Estatus == "ERROR")
                    throw new Exception(objAprobador.Mensaje);

                if (objAprobador.Aprobadores.Count == 0)
                    throw new Exception("No se encontraron aprobadores relacionados al motivo de cancelación");


                //File.AppendAllLines(pathLogTemp, new List<string>() { "Inserta solicitud...." });
                dynamic result = null;
                var prms = new DynamicParameters();
                prms.Add("@IdUsuarioSolicitante", idUsuario, DbType.Int32);
                prms.Add("@IdMotivoDeCancelacion", idMotivoDeCancelacion, DbType.Int32);
                prms.Add("@IdNivelAprobador", objAprobador.Aprobadores[0].IdNivelAprobador, DbType.Int32);
                prms.Add("@IdUsuarioAprobador", objAprobador.Aprobadores[0].IdUsuario, DbType.Int32);
                prms.Add("@RfcEmisor", cia, DbType.String);
                prms.Add("@Serie", serie, DbType.String);
                prms.Add("@XmlFolios", xml, DbType.Xml);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    result = db.Query<dynamic>("[CANCELACIONES].[sp_InsertaSolicitud]", prms, commandType: CommandType.StoredProcedure, commandTimeout: 300).FirstOrDefault();

                return new
                {
                    Estatus = "OK",
                    Mensaje = result,
                    DocumentosRelacionados = facturasConDocumentosRelacionados.SelectMany(f => f.Value.Select(d => new { d.Folio, d.Serie, Factura = string.Format("{0}-{1}", serie, f.Key.ToString()), cia}).ToList()).ToList()
                };
            }
            catch (Exception ex)
            {
                //File.AppendAllLines(pathLogTemp, new List<string>() { ex.ToString() });

                return new
                {
                    Estatus = "ERROR",
                    Mensaje = ex.Message
                };
            }
        }

        /// <summary>
        /// Consulta Histórico de documentos cancelados
        /// </summary>
        /// <returns></returns>
        public dynamic GetHistorico()
        {
            try
            {
                List<dynamic> result = new List<dynamic>();
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    result = db.Query<dynamic>("CANCELACIONES.sp_GetHistoricoSolicitudes", null, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

                return new
                {
                    Estatus = "OK",
                    Solicitudes = result
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    Estatus = "ERROR",
                    Mensaje = "Error al consultar histórico"
                };
            }
        }

        public dynamic GetDocumentosPorSolicitud(long idSolicitud)
        {
            try
            {
                List<dynamic> result = new List<dynamic>();
                var prms = new DynamicParameters();
                prms.Add("@IdSolicitud", idSolicitud, DbType.Int64);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    result = db.Query<dynamic>("[CANCELACIONES].[sp_GetDocumentosPorSolicitud]", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

                return new
                {
                    Estatus = "OK",
                    Documentos = result
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    Estatus = "ERROR",
                    Mensaje = "Error al consultar documentos"
                };
            }
        }

        /// <summary>
        /// Lista de series configuradas con sus respectivos motivos de cancelación
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetMotivosDeCancelacionPorTipoDeDocumento()
        {
            //return this._context.CatMotivosDeCancelacion.Where(m => m.EsEstatusActivo);
            
            List<dynamic> relacionSerieMotivosCancelacion = new List<dynamic>();
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                relacionSerieMotivosCancelacion = db.Query<dynamic>("CANCELACIONES.sp_GetMotivosDeCancelacionPorTipoDeDocumento", null, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            return relacionSerieMotivosCancelacion;
        }

        /// <summary>
        /// Consulta documentos relacionados a Factura
        /// </summary>
        /// <param name="rfcEmisor">Rfc de compañia (Emisor)</param>
        /// <param name="serie">Serie de factura</param>
        /// <param name="folio">Folio</param>
        /// <returns></returns>
        private dynamic GetDocumentosRelacionados(string rfcEmisor, string serie, string xmlFolios)
        {
            try
            {
                List<dynamic> documentosRelacionados = new List<dynamic>();
                var prms = new DynamicParameters();
                prms.Add("@Rfc", rfcEmisor, DbType.String);
                prms.Add("@Serie", serie, DbType.String);
                prms.Add("@XmlFolios", xmlFolios, DbType.Xml);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    documentosRelacionados = db.Query<dynamic>("CANCELACIONES.sp_GetDocumentosRelacionados", prms, commandType: CommandType.StoredProcedure, commandTimeout: 300).ToList();

                return new
                {
                    Estatus = "OK",
                    DocumentosRelacionados =
                    documentosRelacionados.
                    GroupBy(x => x.Factura).
                    Select(x => {
                        return new KeyValuePair<long, List<DocumentoRelacionado>>(x.Key, x.ToList().Select(d => new DocumentoRelacionado() { Serie = d.Serie, Folio = d.Folio }).ToList());
                    }).ToDictionary(p => p.Key, p => p.Value)
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    Estatus = "ERROR",
                    Mensaje = ex.ToString()
                };
            }
        }

        /// <summary>
        /// Consulta lista de aprobadores asignados a motivo de cancelación
        /// </summary>
        /// <param name="idMotivoDeCancelacion">Motivo de cancelación</param>
        /// <returns></returns>
        private dynamic GetAprobadores(int idMotivoDeCancelacion)
        {
            try
            {
                List<dynamic> aprobadores = new List<dynamic>();
                var prms = new DynamicParameters();
                prms.Add("@IdMotivoDeCancelacion", idMotivoDeCancelacion, DbType.Int32);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    aprobadores = db.Query<dynamic>("CANCELACIONES.sp_GetAprobadoresPorMotivo", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

                return new
                {
                    Estatus = "OK",
                    Aprobadores = aprobadores.ToList()
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    Estatus = "ERROR",
                    Mensaje = string.Format("Error en consulta de aprobadores. {0}", ex.Message)
                };
            }
        }

        /// <summary>
        /// Lectura de folios contenidos en archivo de excel
        /// </summary>
        /// <param name="formFile"></param>
        /// <returns></returns>
        private IEnumerable<string> GetFoliosOnExcel(IFormFile formFile)
        {
            List<string> folios = new List<string>();
            try
            {   
                byte[] fileByteArray = null;
                using (MemoryStream ms = new MemoryStream())
                {
                    formFile.OpenReadStream().CopyTo(ms);
                    fileByteArray = ms.ToArray();
                }

                string archivoTemporal = Path.Combine(this.RutaTemporal, formFile.FileName);
                if (File.Exists(archivoTemporal))
                    File.Delete(archivoTemporal);

                File.WriteAllBytes(archivoTemporal, fileByteArray);

                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                using (var stream = System.IO.File.Open(archivoTemporal, FileMode.Open, FileAccess.Read))
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        while (reader.Read())
                            folios.Add(reader.GetValue(0).ToString());
                    }
                }

                try { File.Delete(archivoTemporal); }
                catch (Exception ex) { }
            }
            catch (Exception ex)
            {
                throw new Exception("Error en lectura de archivo, favor de validar que cuente con la lista de folios en la columna A de la hoja 1");
            }

            return folios;
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
        public partial class Documentos
        {
            private List<DocumentoBusqueda> documentoField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute("Documento")]
            public List<DocumentoBusqueda> Documento
            {
                get
                {
                    return this.documentoField;
                }
                set
                {
                    this.documentoField = value;
                }
            }

            public string GetXml(Documentos objct)
            {
                string xmlResultField = string.Empty;
                XmlDocument xmlDocument = new XmlDocument();
                var xmlSerializer = new XmlSerializer(typeof(Documentos));

                XmlWriterSettings settings = new XmlWriterSettings()
                {
                    Encoding = new UnicodeEncoding(false, false),
                    Indent = false,
                    OmitXmlDeclaration = false
                };

                using (StringWriter sWriter = new StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(sWriter, settings))
                    {
                        xmlSerializer.Serialize(sWriter, objct, null);
                        xmlDocument.LoadXml(sWriter.ToString());
                    }
                }
                xmlResultField = xmlDocument.InnerXml;
                using (MemoryStream mStream = new MemoryStream())
                {
                    using (XmlTextWriter writer = new XmlTextWriter(mStream, Encoding.UTF8))
                    {
                        XmlDocument document = new XmlDocument();
                        document.LoadXml(xmlDocument.InnerXml);

                        writer.Formatting = System.Xml.Formatting.Indented;

                        document.WriteContentTo(writer);
                        writer.Flush();

                        mStream.Flush();
                        mStream.Position = 0;

                        using (StreamReader sReader = new StreamReader(mStream, Encoding.UTF8))
                            xmlResultField = sReader.ReadToEnd();
                    }
                }
                return xmlResultField;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class DocumentoBusqueda
        {
            private string folioField;

            public DocumentoBusqueda() { }


            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public long Folio { get; set; }
        }

        public class DocumentoRelacionado
        {
            public string Serie { get; set; }
            public long Folio { get; set; }
        }
    }
}
