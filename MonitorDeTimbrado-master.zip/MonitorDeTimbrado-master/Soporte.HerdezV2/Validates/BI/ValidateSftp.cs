﻿namespace Soporte.HerdezV2.Validates.BI
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;

    public class ValidateSftp : Connect
    {
        public List<SftpResponse> isActiveConnection(int[] pacs)
        {
            List<SftpResponse> response = new List<SftpResponse>();

            foreach (int pac in pacs)
                switch (pac)
                {
                    case 1: response.Add(ExecCarvajal()); break;
                }

            return response;
        }

        SftpResponse ExecCarvajal()
        {
            var pacData = new Models.Tables.Catalogos.Pac();

            try
            {
                pacData = this._context.Pac.Where(pc => pc.IdPac == 1).FirstOrDefault();

                Process p = new Process();
                ProcessStartInfo info = new ProcessStartInfo();
                info.FileName = "cmd.exe";
                info.RedirectStandardInput = true;
                info.UseShellExecute = false;
                info.WindowStyle = ProcessWindowStyle.Hidden;

                p.StartInfo = info;
                p.Start();

                string nombreArchivo = DateTime.Now.ToString("yyyyMMddHHmmss");
                string argument = string.Format(@"{0} ""1"" ""{1}"" ""{2}"" ""{3}"" ""{4}"" ""{5}"" ""{6}"" ", this.NombreExeSftp, this.HostSftpCarvajal, this.UsuarioSftpCarvajal, this.PasswordSftpCarvajal, this.SshHostKeyFingerprintSftpCarvajal, nombreArchivo, ResponsePathSftp);

                using (StreamWriter sw = p.StandardInput)
                {
                    if (sw.BaseStream.CanWrite)
                    {
                        sw.WriteLine(string.Format("cd {0}", this.PathExeSftp));
                        sw.WriteLine(argument);
                    }
                }

                p.WaitForExit();

                string
                    fullPathResponseFileOK = Path.Combine(ResponsePathSftp, nombreArchivo) + ".OK",
                    fullPathResponseFileERROR = Path.Combine(ResponsePathSftp, nombreArchivo) + ".ERROR",
                    fullPathResponseFileEXCEPCION = Path.Combine(ResponsePathSftp, nombreArchivo) + ".TXT",
                    sftpTitle = "",
                    sftpMessage = "";

                bool isActiveSftp = false;

                if (File.Exists(fullPathResponseFileOK))
                {
                    isActiveSftp = true;
                    sftpMessage = "Activo";
                    sftpTitle = "Conexión activa";
                    File.Delete(fullPathResponseFileOK);
                }
                else if (File.Exists(fullPathResponseFileERROR))
                {
                    sftpTitle = File.ReadAllLines(fullPathResponseFileERROR)[1];
                    sftpMessage = "Sin conexión";
                    File.Delete(fullPathResponseFileERROR);
                }
                else if (File.Exists(fullPathResponseFileEXCEPCION))
                {
                    sftpMessage = "Error desconocido";
                    sftpTitle = File.ReadAllLines(fullPathResponseFileEXCEPCION)[1];
                    File.Delete(fullPathResponseFileEXCEPCION);
                }

                return new SftpResponse() { response = isActiveSftp ? 1 : 2, message = sftpMessage, title = sftpTitle, pac = 1, logoPac = pacData.Logo, nombrePac = pacData.Nombre, ultimaConexion = DateTime.Now };
            }
            catch (Exception ex)
            {
                File.WriteAllLines(@"C:\PortalSoporte\Sftp\error.txt", new List<string>() { "Conexión con SFTP --> ERROR", ex.Message });
                return new SftpResponse() { response = 3, message = "Error desconocido", title = ex.Message, pac = 1, logoPac = pacData == null ? "" : pacData.Logo, nombrePac = pacData == null ? "" : pacData.Nombre, ultimaConexion = DateTime.Now };
            }
        }

        public class SftpResponse
        {
            public int response { get; set; }
            public int pac { get; set; }
            public string message { get; set; }
            public string nombrePac { get; set; }
            public string logoPac { get; set; }
            public string title { get; set; }
            public DateTime ultimaConexion { get; set; }
        }
    }
}