﻿namespace Soporte.HerdezV2.Models.SP
{
    using System.Collections.Generic;

    public class DashboardPrincipal
    {
        public long IdCia { get; set; }
        public string RfcCia { get; set; }
        public string Nombre { get; set; }
        public string Logo { get; set; }
        public IEnumerable<Mes> Meses { get; set; }
    }

    public class Mes
    {
        public int Numero { get; set; }
        public string Nombre { get; set; }
        public long TotalDocumentos { get; set; }
        public long TotalTimbrados { get; set; }
        public long TotalNoTimbrados { get; set; }
    }
}