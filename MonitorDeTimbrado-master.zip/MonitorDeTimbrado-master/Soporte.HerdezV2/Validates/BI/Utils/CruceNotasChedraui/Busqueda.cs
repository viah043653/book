﻿namespace Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui
{
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Xml;
    using System.Xml.Serialization;

    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public class Busqueda
    {
        [System.Xml.Serialization.XmlElementAttribute("Documento")]
        public List<ReporteBase> Documento { get; set; }

        public string GetXml<T>(T objct)
        {
            string xmlCFDIResultField = string.Empty;
            XmlDocument xmlCFDI = new XmlDocument();
            var xmlSerializer = new XmlSerializer(typeof(T));

            XmlWriterSettings settings = new XmlWriterSettings()
            {
                Encoding = new UnicodeEncoding(false, false),
                Indent = false,
                OmitXmlDeclaration = false
            };

            using (StringWriter sWriter = new StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(sWriter, settings))
                {
                    xmlSerializer.Serialize(sWriter, objct, null);
                    xmlCFDI.LoadXml(sWriter.ToString());
                }
            }
            xmlCFDIResultField = xmlCFDI.InnerXml;
            using (MemoryStream mStream = new MemoryStream())
            {
                using (XmlTextWriter writer = new XmlTextWriter(mStream, Encoding.UTF8))
                {
                    XmlDocument document = new XmlDocument();
                    document.LoadXml(xmlCFDI.InnerXml);

                    writer.Formatting = System.Xml.Formatting.Indented;

                    document.WriteContentTo(writer);
                    writer.Flush();

                    mStream.Flush();
                    mStream.Position = 0;

                    using (StreamReader sReader = new StreamReader(mStream, Encoding.UTF8))
                        xmlCFDIResultField = sReader.ReadToEnd();
                }
            }
            return xmlCFDIResultField;
        }
    }
}