﻿namespace Soporte.HerdezV2.Controllers.Jobs.InstanciasTXT
{
    using System.Collections;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI.Jobs.InstanciasTXT;

    [Authorize]
    [Produces("application/json")]
    [Route("api/JobInstanciaTxt")]
    public class JobInstanciaTxtController : ControllerBase
    {
        ValidateJobInstanciaTxt valInstanciaTxt = new ValidateJobInstanciaTxt();

        [Route("~/api/JobInstanciaTxt/GetCias")]
        [HttpGet]
        public IEnumerable GetCias()
        {
            valInstanciaTxt = new ValidateJobInstanciaTxt();
            return valInstanciaTxt.GetCias();
        }

        [Route("~/api/JobInstanciaTxt/GetServidores")]
        [HttpGet]
        public IEnumerable GetServidores()
        {
            valInstanciaTxt = new ValidateJobInstanciaTxt();
            return valInstanciaTxt.GetServidores();
        }

        [Route("~/api/JobInstanciaTxt/GetTiposDeDocumento")]
        [HttpGet]
        public IEnumerable GetTiposDeDocumento()
        {
            valInstanciaTxt = new ValidateJobInstanciaTxt();
            return valInstanciaTxt.GetTiposDeDocumento();
        }

        [Route("~/api/JobInstanciaTxt/GetTipoIteracion")]
        [HttpGet]
        public IEnumerable GetTipoIteracion()
        {
            valInstanciaTxt = new ValidateJobInstanciaTxt();
            return valInstanciaTxt.GetTipoIteracion();
        }

        [Route("~/api/JobInstanciaTxt/GetInstanciasConfiguradas")]
        [HttpGet]
        public IEnumerable GetInstanciasConfiguradas()
        {
            valInstanciaTxt = new ValidateJobInstanciaTxt();
            return valInstanciaTxt.GetInstanciasConfiguradas();
        }

        [Route("~/api/JobInstanciaTxt/PostInstancia")]
        [HttpPost]
        public dynamic PostInstancia([FromBody] ValidateJobInstanciaTxt.Instancia data)
        {
            valInstanciaTxt = new ValidateJobInstanciaTxt();
            return valInstanciaTxt.PostInstancia(data);
        }

        [Route("~/api/JobInstanciaTxt/PostSwitchInstancia")]
        [HttpPost]
        public dynamic PostSwitchInstancia(string claveInstancia, int idUsuario)
        {
            valInstanciaTxt = new ValidateJobInstanciaTxt();
            return valInstanciaTxt.SwitchInstancias(claveInstancia, idUsuario);
        }

        [Route("~/api/JobInstanciaTxt/Delete")]
        [HttpDelete]
        public dynamic Delete(string claveInstancia, int idUsuario, string motivo)
        {
            valInstanciaTxt = new ValidateJobInstanciaTxt();
            return valInstanciaTxt.EliminarInstancia(claveInstancia, idUsuario, motivo);
        }
    }
}
