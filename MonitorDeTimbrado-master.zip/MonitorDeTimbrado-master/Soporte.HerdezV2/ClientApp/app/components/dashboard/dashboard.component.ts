import { Component, AfterViewInit, OnInit, ViewChild, Inject, QueryList, ViewContainerRef, OnDestroy } from '@angular/core';
import { Chart, ChartData, Point } from 'chart.js';
import { Subject } from "rxjs/Subject";
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Angular2Csv } from 'angular2-csv';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SelectionModel } from '@angular/cdk/collections';
import { saveAs } from 'file-saver';
import { Observable } from "rxjs/Observable";

import 'chartjs-plugin-datalabels';

import { DashboardService } from './dashboard.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';

import { DetalleMes } from './dashboard.model'

@Component({
    selector: 'dashboard',
    providers: [DashboardService, SharedService],
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.style.css']
})

export class DashboardComponent implements OnInit, AfterViewInit, OnDestroy {

    private VIEW_ID: number = 1;
    /*Variables de acci�n*/
    GetIntercambio: boolean = false;
    GetCSV: boolean = false;
    PostRetransmitir: boolean = false;

    isSearchCleanVisible: boolean = false;
    filterValue: string = '';

    subTitulo: string = '(Dashboard - Seguimiento Timbrados)';
    //dataSftp: any[];

    displayedColumns = ['isChecked', 'no', 'serie', 'folio', 'descripcionEstatus', 'fechaAlta'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    chartCHE041201L59: Chart;
    chartHER8301121X4: Chart;
    chartNUT840801733: Chart;
    chartOCO160809URA: Chart;
    chartHER980609NC1: Chart;
    chartROC020422UV9: Chart;

    chart2018: Chart;
    chart2019: Chart;

    ShowDashboard: boolean = true;
    ShowDashboardTimbrados: boolean = false;
    ShowSeriesTimbrados: boolean = false;
    ShowTable: boolean = false;
    ShowDashboardLoading: boolean = true;
    nombreMes: string;
    dMes: DetalleMes;
    cia: any;
    logoCia: string = '';
    nombreCia: string = '';
    rfcCia: string = '';

    interval: any;

    mostrarDashboard: boolean = false;

    selectedNoEnviados: boolean = false;
    selectedEnviados: boolean = false;
    selectedErrores: boolean = false;

    isActionButtonsVisible: boolean = false;
    showCheckInTable: boolean = true;

    showManualGetIntercambio: boolean = false;
    showManualGetCSV: boolean = false;
    showManualPostRetransmitir: boolean = false;

    showCHE041201L59: boolean = true;
    showNUT840801733: boolean = true;
    showOCO160809URA: boolean = true;
    showHER8301121X4: boolean = true;
    showHER980609NC1: boolean = true;
    showROC020422UV9: boolean = true;

    timbradosCias: any = {};
    timbradosCiasSeries: any[] = [];

    ciaSeriesTotales: any = {};
    message: string;
    ciaSelectedTimbrados: number = 0;

    canvas2018: any;
    ctx2018: any;

    canvas2019: any;
    ctx2019: any;

    filtrosTimbrados: any = { 'Pac': 'Pac', 'Serie': 'Serie', 'Tipo': 'Tipo De Producto' };

    constructor(private dataService: DashboardService, private sharedService: SharedService, public dialog: MatDialog, private spinnerService: Ng4LoadingSpinnerService, public toastr: ToastsManager, vcr: ViewContainerRef, private localstorageservice: LocalStorageService) {
        this.nombreMes = '';
        this.toastr.setRootViewContainerRef(vcr);
    }

    ngOnInit() {

        this.mostrarDashboard = false;

        this.setActions(this.localstorageservice.GetActions(this.VIEW_ID));

        let userData = this.localstorageservice.GetAuthorizationData();

        let vistasUnicas = userData._userData.ngViews.vistasUnicas;
        if (vistasUnicas.length > 0) {
            for (let vista of vistasUnicas) {
                if (vista.idPantalla === 1)
                    this.mostrarDashboard = true;
            }
        }

        //this.loadDashboards();
        this.ShowDashboard = true;
        this.ShowDashboardTimbrados = false;
        this.ShowSeriesTimbrados = false;
        this.ShowTable = false;
        this.ShowDashboardLoading = true;

        this.showCHE041201L59 = true;
        this.showHER8301121X4 = true;
        this.showNUT840801733 = true;
        this.showOCO160809URA = true;
        this.showHER980609NC1 = true;
        this.showROC020422UV9 = true;
    }

    ngOnDestroy() {
    }

    private loadDashboards() {
        this.ShowDashboard = true;
        this.ShowDashboardTimbrados = false;
        this.ShowSeriesTimbrados = false;
        this.ShowTable = false;
        this.ShowDashboardLoading = true;

        this.showCHE041201L59 = true;
        this.showHER8301121X4 = true;
        this.showNUT840801733 = true;
        this.showOCO160809URA = true;
        this.showHER980609NC1 = true;
        this.showROC020422UV9 = true;

        this.dataService.GetDashboardTimbrados()
            .subscribe(
                (data) => {                    
                    var cia1 = 0, cia60 = 0, cia77 = 0, cia92 = 0, cia43 = 0, cia102 = 0, total = 0;
                    for (let c of data) {
                        switch (c.Cia) {
                            case 1: cia1 += c.Timbrados; break;
                            case 60: cia60 += c.Timbrados; break;
                            case 77: cia77 += c.Timbrados; break;
                            case 92: cia92 += c.Timbrados; break;
                            case 43: cia43 += c.Timbrados; break;
                            case 102: cia102 += c.Timbrados; break;
                        }
                    }

                    this.timbradosCiasSeries = data;

                    total = cia1 + cia60 + cia77 + cia92 + cia43 + cia102;
                    this.timbradosCias = { 'cia1': cia1, 'cia60': cia60, 'cia77': cia77, 'cia92': cia92, 'cia43': cia43, 'cia102': cia102, 'total': total };
                },
                response => {
                    console.log(response);
                    this.sharedService.catchHttpResponseError(response);
                },
                () => {
                });

        this.dataService.GetDashboard()
            .subscribe(
            (data) => {
                    this.dataService.dashboardPrincipal = data;

                    this.dataService.UpdateData();

                    this.chartCHE041201L59.data = this.dataService.dataCHE041201L59.dataConfig;
                    this.chartHER8301121X4.data = this.dataService.dataHER8301121X4.dataConfig;
                    this.chartNUT840801733.data = this.dataService.dataNUT840801733.dataConfig;
                    this.chartOCO160809URA.data = this.dataService.dataOCO160809URA.dataConfig;
                    this.chartHER980609NC1.data = this.dataService.dataHER980609NC1.dataConfig;
                    this.chartROC020422UV9.data = this.dataService.dataROC020422UV9.dataConfig;

                    this.chartCHE041201L59.update();
                    this.chartHER8301121X4.update();
                    this.chartNUT840801733.update();
                    this.chartOCO160809URA.update();
                    this.chartHER980609NC1.update();
                    this.chartROC020422UV9.update();

                    localStorage.setItem("lastUpdate", new Date().toLocaleString());
                },
                response => {
                    this.ShowDashboardLoading = false;
                    this.sharedService.catchHttpResponseError(response);
                },
                () => {
                    this.ShowDashboardLoading = false;
                });
    }

    private setActions(_acciones: any[]): void {
        this.cleanActions();
        for (let _accion of _acciones) {
            switch (_accion.nombreAccion) {
                case "GetIntercambio": this.GetIntercambio = true; break;
                case "GetCSV": this.GetCSV = true; break;
                case "PostRetransmitir": this.PostRetransmitir = true; break;
            }
        }
    }

    private cleanActions() {
        this.GetIntercambio = false;
        this.GetCSV = false;
        this.PostRetransmitir = false;
        this.showCheckInTable = true;
        this.displayedColumns = ['isChecked', 'no', 'serie', 'folio', 'descripcionEstatus', 'fechaAlta'];
    }

    ngAfterViewInit() {
        let bottomMargin: number = 15;

        if (this.mostrarDashboard) {

            this.chartCHE041201L59 = new Chart('barChartCHE041201L59', {
                type: 'bar',
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    showLines: true,
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    },
                    plugins: {
                        datalabels: {
                            anchor: 'end',
                            align: 'top',
                            formatter: Math.round,
                            font: {
                                weight: 'bold'
                            }
                        }
                    },
                    tooltips: {
                        mode: 'label',
                        enabled: true
                    },
                    legend: {
                        display: true,
                        position: 'top',
                        fullWidth: true,
                        labels: {
                            generateLabels: (chart) => {

                                chart.legend.afterFit = function () { this.height = this.height + bottomMargin; };

                                var legend = chart.data.datasets.map(function (dataset: any) {
                                    return {
                                        datasetIndex: 0,
                                        fillStyle: dataset.backgroundColor,
                                        strokeStyle: dataset.borderColor,
                                        lineWidth: dataset.borderWidth,
                                        text: dataset.label
                                    }
                                });
                                return legend;
                            }
                        },
                        onClick: (e, legendItem) => { }
                    },
                    onClick: (evt, elements: any[]) => {
                        if (elements.length == 2)
                            this.detallePorMes(elements[0]._model.label, this.dataService.dataCHE041201L59.idCia, this.dataService.dataCHE041201L59.logo, this.dataService.dataCHE041201L59.nombre, this.dataService.dataCHE041201L59.rfc);
                    }
                }
            });


            this.chartHER8301121X4 = new Chart('barChartHER8301121X4', {
                type: 'bar',
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    showLines: true,
                    tooltips: {
                        mode: 'label',
                        enabled: true
                    },
                    legend: {
                        display: true,
                        position: 'top',
                        fullWidth: true,
                        labels: {
                            generateLabels: (chart) => {

                                chart.legend.afterFit = function () { this.height = this.height + bottomMargin; };

                                var legend = chart.data.datasets.map(function (dataset: any) {
                                    return {
                                        datasetIndex: 0,
                                        fillStyle: dataset.backgroundColor,
                                        strokeStyle: dataset.borderColor,
                                        lineWidth: dataset.borderWidth,
                                        text: dataset.label
                                    }
                                });
                                return legend;
                            }
                        },
                        onClick: (e, legendItem) => { }
                    },
                    onClick: (evt, elements: any[]) => {
                        if (elements.length == 2)
                            this.detallePorMes(elements[0]._model.label, this.dataService.dataHER8301121X4.idCia, this.dataService.dataHER8301121X4.logo, this.dataService.dataHER8301121X4.nombre, this.dataService.dataHER8301121X4.rfc);
                    }
                }
            });

            this.chartNUT840801733 = new Chart('barChartNUT840801733', {
                type: 'bar',
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    showLines: true,
                    tooltips: {
                        mode: 'label',
                        enabled: true
                    },
                    legend: {
                        display: true,
                        position: 'top',
                        fullWidth: true,
                        labels: {
                            generateLabels: (chart) => {

                                chart.legend.afterFit = function () { this.height = this.height + bottomMargin; };
                                var legend = chart.data.datasets.map(function (dataset: any) {
                                    return {
                                        datasetIndex: 0,
                                        fillStyle: dataset.backgroundColor,
                                        strokeStyle: dataset.borderColor,
                                        lineWidth: dataset.borderWidth,
                                        text: dataset.label
                                    }
                                });
                                return legend;
                            }
                        },
                        onClick: (e, legendItem) => { }
                    },
                    onClick: (evt, elements: any[]) => {
                        if (elements.length == 2)
                            this.detallePorMes(elements[0]._model.label, this.dataService.dataNUT840801733.idCia, this.dataService.dataNUT840801733.logo, this.dataService.dataNUT840801733.nombre, this.dataService.dataNUT840801733.rfc);
                    }
                }
            });

            this.chartOCO160809URA = new Chart('barChartOCO160809URA', {
                type: 'bar',
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    showLines: true,
                    tooltips: {
                        mode: 'label',
                        enabled: true
                    },
                    legend: {
                        display: true,
                        position: 'top',
                        fullWidth: true,
                        labels: {
                            generateLabels: (chart) => {

                                chart.legend.afterFit = function () { this.height = this.height + bottomMargin; };

                                var legend = chart.data.datasets.map(function (dataset: any) {
                                    return {
                                        datasetIndex: 0,
                                        fillStyle: dataset.backgroundColor,
                                        strokeStyle: dataset.borderColor,
                                        lineWidth: dataset.borderWidth,
                                        text: dataset.label
                                    }
                                });
                                return legend;
                            }
                        },
                        onClick: (e, legendItem) => { }
                    },
                    onClick: (evt, elements: any[]) => {
                        if (elements.length == 2)
                            this.detallePorMes(elements[0]._model.label, this.dataService.dataOCO160809URA.idCia, this.dataService.dataOCO160809URA.logo, this.dataService.dataOCO160809URA.nombre, this.dataService.dataOCO160809URA.rfc);
                    }
                }
            });

            this.chartHER980609NC1 = new Chart('barChartHER980609NC1', {
                type: 'bar',
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    showLines: true,
                    tooltips: {
                        mode: 'label',
                        enabled: true
                    },
                    legend: {
                        display: true,
                        position: 'top',
                        fullWidth: true,
                        labels: {
                            generateLabels: (chart) => {

                                chart.legend.afterFit = function () { this.height = this.height + bottomMargin; };

                                var legend = chart.data.datasets.map(function (dataset: any) {
                                    return {
                                        datasetIndex: 0,
                                        fillStyle: dataset.backgroundColor,
                                        strokeStyle: dataset.borderColor,
                                        lineWidth: dataset.borderWidth,
                                        text: dataset.label
                                    }
                                });
                                return legend;
                            }
                        },
                        onClick: (e, legendItem) => { }
                    },
                    onClick: (evt, elements: any[]) => {
                        if (elements.length == 2)
                            this.detallePorMes(elements[0]._model.label, this.dataService.dataHER980609NC1.idCia, this.dataService.dataHER980609NC1.logo, this.dataService.dataHER980609NC1.nombre, this.dataService.dataHER980609NC1.rfc);
                    }
                }
            });

            this.chartROC020422UV9 = new Chart('barChartROC020422UV9', {
                type: 'bar',
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    showLines: true,
                    tooltips: {
                        mode: 'label',
                        enabled: true
                    },
                    legend: {
                        display: true,
                        position: 'top',
                        fullWidth: true,
                        labels: {
                            generateLabels: (chart) => {

                                chart.legend.afterFit = function () { this.height = this.height + bottomMargin; };

                                var legend = chart.data.datasets.map(function (dataset: any) {
                                    return {
                                        datasetIndex: 0,
                                        fillStyle: dataset.backgroundColor,
                                        strokeStyle: dataset.borderColor,
                                        lineWidth: dataset.borderWidth,
                                        text: dataset.label
                                    }
                                });
                                return legend;
                            }
                        },
                        onClick: (e, legendItem) => { }
                    },
                    onClick: (evt, elements: any[]) => {
                        if (elements.length == 2)
                            this.detallePorMes(elements[0]._model.label, this.dataService.dataROC020422UV9.idCia, this.dataService.dataROC020422UV9.logo, this.dataService.dataROC020422UV9.nombre, this.dataService.dataROC020422UV9.rfc);
                    }
                }
            });

            /*Obtiene datos de BD*/
            this.loadDashboards();
        }
    }

    detallePorMes(nombreMesLabel: string, ciaDetalle: number, logoCia: string, nombreCia: string, rfcCia: string) {
        this.spinnerService.show();
        this.nombreMes = nombreMesLabel;
        this.cia = ciaDetalle;
        this.logoCia = logoCia;
        this.nombreCia = nombreCia;
        this.rfcCia = rfcCia;

        let detalles = this.dataService.GetDetalleMes(this.nombreMes, this.cia);
        detalles.subscribe(
            (data) => {
                this.dMes = new DetalleMes();
                this.dMes = this.dataService.SetDetalleMes(data);
                this.ShowDashboard = false;
            },
            response => {
                this.spinnerService.hide();
                this.sharedService.catchHttpResponseError(response);
            },
            () => {
                this.spinnerService.hide();
            });
    }

    clearSelectedEstatus() {
        this.selectedNoEnviados = false;
        this.selectedEnviados = false;
        this.selectedErrores = false;
    }

    searchByEstatus(idEstatus: number) {
        this.ShowTable = false;
        this.isActionButtonsVisible = false;

        var total = 0;
        switch (idEstatus) {
            case 1:
                total = this.dMes.noEnviado;
                this.clearSelectedEstatus();
                this.selectedNoEnviados = true;

                this.showManualGetCSV = false;
                this.showManualGetIntercambio = false;
                this.showManualPostRetransmitir = false;

                this.showCheckInTable = true;
                this.displayedColumns = ['isChecked', 'no', 'serie', 'folio', 'descripcionEstatus', 'fechaAlta'];
                break;
            case 2:
                total = this.dMes.enviadoTimbrar;
                this.clearSelectedEstatus();
                this.selectedEnviados = true;

                this.showManualGetCSV = true;
                this.showManualGetIntercambio = true;
                this.showManualPostRetransmitir = true;

                this.showCheckInTable = true;
                this.displayedColumns = ['isChecked', 'no', 'serie', 'folio', 'descripcionEstatus', 'fechaAlta'];
                break;
            case 3:
                total = this.dMes.errorTimbrar;
                this.clearSelectedEstatus();
                this.selectedErrores = true;

                this.showManualGetCSV = true;
                this.showManualGetIntercambio = true;
                this.showManualPostRetransmitir = false;

                this.showCheckInTable = true;
                this.displayedColumns = ['isChecked', 'no', 'serie', 'folio', 'descripcionEstatus', 'fechaAlta'];
                break;
        }

        if (total > 0) {
            this.spinnerService.show();

            this.dataSource = new MatTableDataSource<any>();
            this.selectionCheckBox = new SelectionModel<any>(true, []);

            let resultEstatus = this.dataService.GetDetallesEstatus(this.nombreMes, this.cia, idEstatus);
            resultEstatus.map(response => response).subscribe((data) => {

                this.ShowTable = true;

                this.interval = setInterval(() => {
                    this.dataSource = new MatTableDataSource(data);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;

                    clearInterval(this.interval);
                }, 200);

            },
                response => {
                    this.spinnerService.hide();
                    this.sharedService.catchHttpResponseError(response);
                },
                () => {
                    this.spinnerService.hide();
                });
        }
        else
            this.toastr.error('No existen registros con este estatus', 'Sin Datos');
    }

    descargarCsv() {
        this.spinnerService.show();
        var datosTablaResumen = [
            {
                "cia": "Cia",
                "serie": "Serie",
                "folio": "Folio",
                "fechaProcesaTxt": "Fecha Construye Txt",
                "fechaProceso": "Fecha Seguimiento",
                "estatus": "Estatus",
                "detalles": "Detalles"
            }];

        for (let doc of this.selectionCheckBox.selected) {

            var s = this.cia;

            datosTablaResumen.push(
                {
                    "cia": s,
                    "serie": doc.serie,
                    "folio": doc.folio,
                    "fechaProcesaTxt": doc.fechaAlta,
                    "fechaProceso": doc.historico[0].fechaProceso,
                    "estatus": doc.descripcionEstatus,
                    "detalles": doc.historico[0].mensaje + " " + doc.historico[0].contenido
                }
            );
        }

        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();
    }

    descargarArchivosIntercambio() {

        this.spinnerService.show();

        let retransmision: any[] = [];
        for (let data of this.selectionCheckBox.selected) {
            retransmision.push({
                rutaReproceso: data.rutaReproceso,
                cia: this.cia,
                rfcCia: this.rfcCia,
                serie: data.serie,
                folio: data.folio,
                fechaEnvio: data.historico[0].fechaProceso,
                fechaTxt: data.fechaAlta,
                estatus: data.descripcionEstatus
            });
        }


        this.sharedService.
            DescargarArchivosIntercambio(retransmision).
            subscribe(
                (data) => {
                    var fileContentResult = data[0].archivo;
                    var errores = data[0].errores;


                    if (fileContentResult != null) {
                        var dataBlob = this.sharedService.b64toBlob(fileContentResult.fileContents, fileContentResult.contentType);
                        saveAs(dataBlob, fileContentResult.fileDownloadName);
                    }

                    if (errores.length > 0) {
                        var dataDetails = { tipoModal: 'errorFolios', data: { titulo: 'Error en descarga de ' + errores.length + ' archivo(s)', foliosError: errores } };

                        this.dialog.open(DialogTimeLineComponent, {
                            width: '80%',
                            height: 'auto',
                            data: dataDetails,
                            panelClass: 'custom-dialog-container2'
                        });
                    }
                    else
                        this.toastr.success('Se descargo un total de ' + retransmision.length + ' archivo(s) de intercambio', 'Descarga completa');
                },
                response => {
                    retransmision = [];
                    this.spinnerService.hide();
                    this.toastr.error(response, 'Error en comunicaci�n con el servidor');
                },
                () => {
                    retransmision = [];
                    this.spinnerService.hide();
                });
    }

    retransmitirDocumentos(observaciones: string) {
        if (observaciones == '') {
            this.toastr.error('Los motivos de retransmisi�n son obligatorios.', 'Error');

            let element: HTMLElement = document.getElementById('btnSend') as HTMLElement;
            element.click();
        }
        else {

            let retransmision: any[] = [];
            if (this.selectionCheckBox.selected.length > 0) {

                this.spinnerService.show();

                for (let data of this.selectionCheckBox.selected) {
                    retransmision.push({
                        rutaReproceso: data.rutaReproceso,
                        cia: this.cia,
                        rfcCia: this.rfcCia,
                        serie: data.serie,
                        folio: data.folio,
                        fechaEnvio: data.historico[0].fechaProceso,
                        fechaTxt: data.fechaAlta,
                        estatus: data.descripcionEstatus
                    });
                }

                let user = this.localstorageservice.GetAuthorizationUser();
                this.sharedService.
                    ReprocesarDocumentos(retransmision, observaciones, user).
                    subscribe(
                        (data) => {
                            if (data.length > 0) {

                                var dataDetails = { tipoModal: 'errorFolios', data: { titulo: 'Error en reprocesamiento de ' + data.length + ' archivo(s)', foliosError: data } };

                                this.dialog.open(DialogTimeLineComponent, {
                                    width: '80%',
                                    height: 'auto',
                                    data: dataDetails,
                                    panelClass: 'custom-dialog-container2'
                                });
                            }
                            else
                                this.toastr.success('Se realizo el reprocesamiento de ' + retransmision.length + ' archivo(s), favor de esperar de 5 a 10 minutos para visualizar la respuesta en Seguimiento Entregas', 'Reprocesamiento finalizado');
                        },
                        response => {
                            retransmision = [];
                            this.spinnerService.hide();
                            this.sharedService.catchHttpResponseError(response);
                        },
                        () => {
                            retransmision = [];
                            this.spinnerService.hide();
                        });
            }
            else
                this.toastr.error("No se encuentra ningun documento seleccionado para retransmitir", "Sin documentos seleccionados");
        }
    }

    regresar() {
        window.location.reload();
    }

    changeTab(vista: number) {
        this.ciaSelectedTimbrados = 0;
        this.subTitulo = vista == 1 ? '(Dashboard - Seguimiento Timbrados)' : vista == 2 ? '(Estatus SFTP)' : '(Dashboard - Timbrados)';

        this.ShowSeriesTimbrados = false;

        if (vista == 3)
            this.ShowDashboardTimbrados = true;
        else
            this.ShowDashboardTimbrados = false;

        //this.dataSftp = this.sftpservice.GetStatus();
    }

    resumenSoloTimbrados(cia: number) {
        this.ciaSelectedTimbrados = cia;
        this.ShowDashboardTimbrados = false;
        this.ShowSeriesTimbrados = true;

        var serieA = 0, serieB = 0, serieC = 0, serieD = 0, serieP = 0;
        for (let d of this.timbradosCiasSeries) {
            if (d.Cia == cia) {
                switch (d.Serie) {
                    case 'A': serieA = d.Timbrados; break;
                    case 'B': serieB = d.Timbrados; break;
                    case 'C': serieC = d.Timbrados; break;
                    case 'D': serieD = d.Timbrados; break;
                    case 'P': serieP = d.Timbrados; break;
                }
            }
        }

        var rfc = '', logo = '';
        switch (cia) {
            case 1:
                rfc = 'HER8301121X4';
                logo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMMAAADDCAYAAAA/f6WqAAAgAElEQVR4nO2dd5QdR53vv933zg2TRzPSjPIoBytYEeSEhWENBhFkMAZskx7s44DX7HkPlgXe7uEsx6THsgssi1nAxIXzjA3YYIPBNg5ylCUra0ZxNNJogiaHm7vfH327u7q6qru6b5g7cv/mzEx3VX0qdXXVr379u30lVRM4iSRJUFUVkiQBgHHM4ui0upAMydJ58hgyb6d60emmg+H1jVveAcMOLxcjud4JgQTyKpGwyL3gdJcHEsjlIrJIouBGCOTVIGFaT+eJyD7AKW0xGC9SyUwglSkywJ/56U0GK1yPc1s96A2zU348hgwT2fRPFxNI4eLUl3ScSL+LMGGWlcjtWBfWzl2SJOYK4lYRUYa+8ZxWmOliRK1RAePM0JMha0zw4nwxgTUpkEA0Kdia5CfOb35O9QO8qSnlYnQuYCrfIhmsDIEEkhch02oggbwaxPVm8LNTFxG/C5IXK0MlMYF4k+mwJsmsSFZC0tTIMjuyjvW0PIZO44Vxa9h0M7y6i6QNGLt10Yl1K0OUCfMqTZqgSNE3QryBQTNOm04nU5tbxZ1mZyezWjkYmnUyFgQMm3EyW/NEj/fLhOlB6HUAus2MvDAWL8rkIzDVcRITrxxB+tIgoCjsdCWSyNxWtN7ydsc0bhYU3uRRbCZxugvj+w4i3dsPNZdzrHOxRY7HMe+jt3HjRdsjssrQ8V4ZSVGUghTd6TCZDT/2FM796/cwdewEVKgA9M70Uo/CmPrNG7Hu1z/0wJZfxvceQNfXv4PxvQfy10jvK9E262n9M5HmWdj60qMeaz49Iuyb5CTl8s1Rczmc/dI3cfEnvwL0u9laE4C4OVSoliHPrqVfpnzt9iqqqqLn+z9F19e/CzWXhQRAgsRpj5SfUKxD3rkPvDGl7ic3VUiUEXroVinS9bXv4OKPf8W5ECrzGEQaeo4rlKnUvuv92X3o+sq3jZrSg5NSQJjhxWTK0U9+yrBtoJ02GW7h9EaHdeyWF1kpJ2b0hX3o+cEvtHREl5NHltmIc1xMphJXhsTZbpy9+98A0K0zz+lwJykG46ef3MaLqMezF2ZGOOqpqorz3/khVKW8mz9RYfUBq5/K4Qx34Z6fQEmlbHWUjDVNXP8vFsObPN3aQ0+SrHFUTEc9y57B67FbnAjDEzJNdmgYY8+/bMw0fF2eL6VkWH3gpZ+KxajZHIb++ITDLM5eU52lUIZdV9E+YKUpFePJUW+6nK2mOk5ByWZh1dwBQDU2hsifa7HWNKViKm3PkLpwEdmRUcYcrlqGp9X+xrvli8MAlddPPBG2JonchaWS7Ni44+zECyk1U2l7hszIKAD+/C1R/7Vj5zYUg6m0fuJJeLorICosQ6qpl0r5I1anl4th1LlIJj9hRlG4mr3ZAhCrn/ugLpzxLn76oBhiuGOI7tynS9gLtjWGX8vyMG4WNTcpBsPZtVnixCxD5WKswtps89Lwzv0yMgDbXsDJbUJV7Q50ZBgrnMfQaXgMUQvoz1H1czqeFVYaxtpW0XNWXCkY1pm9PexnK8Vm/LRHZFJwG7NemZnjqEddAv5A5YcVn4GtnqxwXjzvGY5fRqslufkn+jQfazcSWFMVn7HXUaQ99BhwWy1Izi/jaE1yWiHcznk3mFN+ToyYpkqeA04DuDiMmPCscE4Xyg+j1zCfkqvoUdMV6EFeCsZre5zCvYooI7SBdpqt/JhbfTXI09bMnB1LybitCG7pyLhiMACoOVol+o2bG3FcOsZve3h8KZiiOOoBKMmGxpI/dyYi5yHVkrrUjJcZzUmKzZBrHP10hLXVtjsnFpMR1/95ajkvLW+z7ZcpmqOel5nND0PP1ea5dkQ73ZWDEV0ZRKSYjGr7ax2c1phSM+Jt89IHTuq4X4a7MpCbEP282LM9Kx13hqDMdmY4nYIOLx3D8qeabjM025ypWuLYPVkqRmxlsOXkoS+LtbJanjM4mbfoQa6HebnreW4dIvZkFd5nzlKL04aQbh+rz3jHfhnArZ9IBYbeI5WKsfeJp/ZQkzIZRobzLFBemDAZ6dU1w41hpXMri5c3z0+GJ3SaUjB+HMREj30zDiuD1XPIaR0sJsO+5n76QDSNX2ZGOOoBds2U7HaVSiUBRHjpmOnqCyfh1Yh3k/Od7orDAJXZTyyZEY56ADizk3NIqZnp3h+wxHElY6QJHPVMCRz1isYw6jwNZlanlcFqKXNXHIvDeJfpMkQEjnpFZESsYk5SDMZJeTFnbJEyysVYhfccgJWGd+6XCRz1fDPWtoqes+JKwbDO7O0JHPVICRz1CmJgqycrnBfv5Hvjh9FqSW7+iT7Nx5JGAZooDWOvo0h7WGZStxWAZ8IVZQJHvYIYMeFZ4ZwulB9Gr2E+JVfRo6Yr0IO8FIzX9jiFexVRJnDUK4BxWxHc0pFxxWAAUHN04KjnhZkxb9Qjt2akNYe3dVTLwIgsv16kOBto9qYf0NpjtYvBNqsXmwG8jQ9bezy68xTCzJg36vHcDFihbgpPsRi3vivlks5jeP3E0vrd2lwMhq6fiExHvwEe3qjHOuZtWMhjnqlRZJNEHns10/lZq7wyha4MTn3il3HqJ1aMW5uLwXjpJ3psiTJ+yqGZMA3QjaAhJ91WdMPNuwkc8yH+WvV5yZaK/Sa44jNO7aHjWTe520ThlbHWjBSWO4mpEJaW8dceui+YpRWZcXXUc3JwcpvFnPLj5cu1rhB/Sf2VlQqW+BIznP6g2+PUb7y0vhhGbdk1dw4rJlOsPnBLy8tblJkWRz1fFijKXkFu4vT5yDqHSyVnKnO/ZbaIfFu5GWf9RJ91M1x8BqjUfrLLtDnqec2H9+EeM4xcoKWyMOWwonkX1kqnWs6d3p5aCqYy+8kuM8xRjxfjzYGuXMx0mFf5Vh5zRqfXQ54Uj/EmfvqgGDJjbgZ+1/BnLJHc/DK5ySmM7z8kTJdDpjpPcdpjXe1mgqPedAjXa9WLiYvUCen9hVO+ogzA1lxN3d68CCpl0SgVM9lxAod2f4jJ6HO01f5itgJGfma5lysD2K856/qT4uTpwBojTvl6YcJ0pFMFWaZWVoWdzt2Ez+gXgzbcaUfWTS9tECw3Q2weqRzYigy14bzMGIA9CYIRTwrLnE8f8565+GHCvLtK1ALgxNAd4NQRbox902Y/k5gXpvwMm1MZx68exus4cAorFcNdGVgwa+Dz7nanhrt1Bvuhm9vWjJXnTGB4KS4vRmR8OYnTw95iMYGjXgkY89aQqDS8PC5fBvA2PmzuJQJssZjAUa8EjKlfl8cZrpIZQFzl9pu+WEzgqFcGxi0NK/5yYpxmahG/LBHGTzk0EzjqlYTR05gKFG9dmz4HunIx7AGuH/MmSyMHDzdFoUzgqFcSxolgy+XMBI56Avl5kUp01OMxuuZcLme4SmYAf/r8dEjgqFciptzOcJXMBI56RRb+3GIqM5XiqKelYe01eGkvd8abOOn8pZQZczPwu4Y/Y4nkViqmspzhKpmxynTdCED+jXpenyCz0ui/bqwfBrBak1Tos46a/yF1fDLN9DBmCtUSYo215nG5MoD9mpPHvDFC/9L5sNKz8vXCBI56JWFmhgNduRjAPn5sBGNFCBz1OIx902Y/Cxz1KpcJHPU8VtaRcd2asfKcCQwvxeXFiIwvJ3F62FssJnDUKwFj3hoSlYaXx+XLAN7GB63GBI56DAkc9WYmA4ir3H7TF4sJHPXKwLilYcVfTkzgqMcJc7oJHPMh/to3cNZUgaNeJTHsAa4fB456DvkGjnqXHxM46gnk50UCR72ZyQD+9PnpkMBRr0TMTHCgKxcTOOoVWfhzi6nMBI56lcp4Eyedv5QyY24GftfwZyyR3ErFVJYzXCUzVpmuGwEIHPVKwpgpVEuINdaax+XKAPZrTh7zxgj9S+fDSs/K1wsTOOqVhJkZDnTlYgD7+LERjBUhcNTjMPZNm/0scNSrXCZw1PNYWUfGdWvGynMmMLwUlxcjMr6cxOlhb7GYwFGvBIx5a0hUGl4ely8DeBsftBoTOOoxJHDUm5kMIK5y+01fLCZw1CsD45aGFX85MYGjHifM6SZwzIf4a9/AWVMFjnqVxLAHuH5ccY56tOgVd5rZ6bQi56JWBJ41yaqLWi8MqbdrR3YdvlyMNS0ogmg3FX85MrY0nBmaPualocP8WKZ4TJiVQMRqJFqJYup/tEmTtyiac7Q0TYy5OtCDiGSsoZcrkw9hjJ1CzPosK6Yb58Z4siZx3as9hvtl7PMyqHNTfSk1I4WrUNVQ51DX8ouSzSI3Og6APYvbHOgovmSM4MNWr1JsZtp9k5z0O0Zq4y9DYaPSkbp78ZnaDWux/v4fCda7PDK+/xAO7f5g/syu3KiUAghbitIxM0Fk8kTfJ4jqW4U+pfb+YE6CrpTA9gvGeSkZ97a5tYu1ZBfOsOsJsFY/uo2lYOwi2h7eWOGpOnScV8ZyM9C7e/K/yKeVeIPbSSXSf8UY0mFO+0vHk7N6aRkqhDGIRfun6AysT2VUzv9pYQTbI2K8ofMVsU45MZbvgXbb6fOeKejnToXSadxWFZtJl7DtWL0j2ZeJjCkdY4qTk5lTvxWTAVFnUANVD9NncfZDzOIzftvDM+U7sWR5fhibNcmviuQ3jVtDzHO7FmrV8O07AD2sVIxIe+h4kf72y1hrZ8nNFkeqMpwaFIUxYny0x2ny5I3TQpiSbaCLaVLNx7ooK/Snk9nzeXEZMXGbCXkqlleGVVtrqOlQwWp3KRiROrs5e5aLKYqjXjmENyvRWzczjd3yXWzGy+N/ETNzURiHlYHvdFc6hqyrn/Y4SbGZaTetiov9gY+TykPGlZIxakfpw15uFF6YH4Z2pjMHMr3qqUZbyPYWnymsPW5CqlqiLI8JswLdznkFiAwE/0K/oYiMcaLKxAjO6Lz4YjGst1jw2kOnKzVj4X30gS7kGBPZHIsyzOcM+jH5n5fGiSHjneLcGECbaVTjhz62xsM4Lh1D9odI/3kxLBTEMH/pOKvBuJRMMfuAFhHjgxcmcNQrgOFdXKd2ijipFcLwNXkznqcGloKxpRFsT+Co58JUmqOewbr0Bavf3PrVD0O2hGyPNc7U9OkBXhrGXkdv7WFL4Khnm8tBnetzuX0OKwlTpL1RcR3O7HU3dXmJ+s8iS8AEjnpi4m3Dbc56rK2jNR1p6ygVU4liztV0CwJHPWcJHPV8M+5tc2uXk3HCP8OuJ8Ba/QJHPTIucNTzzVAhrM1s4KhnZwTbI2K8ofMNHPU4l4mMKR1jSuCox2b8tidw1HNg9MWXVghAhNE7AD2sVIxIe+h4kf72y1hrZ8nNFhc46tmZwFGvIEZMAkc9f+0RUaWKyQSOegUwgaOeO0PWNXDUK5oEjnqBox47H68sjwkc9YrFBI56royFDxz12HFuDKDNNIGjngDD/KXjAkc9VnjgqFcAw7u4Tu0MHPUCRz1PwrU6UN3LW1RVIz5w1Asc9cSZwFGvECZw1BNjAkc9MfG24TZnPdbW0ZqOtHWUiqlEMedqugWBo56zBI56vhn3trm1y8k44Z9h1xNgrX6Box4ZFzjq+WaoENZmNnDUszOC7REx3tD5Bo56nMtExhSLkSQZkixDilQh3FhvoQNHPTbjtz2Bo54Doy++tEIAIozeAehhbowUjaCqqRGRtjmItM1GZHYLqmY3I9LSjHBzE6pmNSLc2IBwQx1CtTWQYzHh9tDxIv3tl6levQIb7r8XmaERZAaHkRkcQmZgEOmBQe1/Xz8yl4aQSyQBRTHzZ9cg/5/cHdAmBHemkPYEjnr8WBdlhe90J0ciqGqZhdiCeYjMa0N0bitiixcgtmgBogvmoqqlGXIs6rm+rqICai4HqArUXH7wKQpUYiAatQ+FAH1WDIe0CxQKMbPlzXSheAy1m9Y7MzkF2dFRpPsvIXWxH+meXqQuXETqwkUku3uQOt+D7MgolGzW6MHAUa/CRMRRTwqHEZ0/F9WrV6B69XJUr1iG+PJ2ROe1IVRb48kUpyoKclMJ5MYmkBkeRnZoBJnhUeTGxpEdGUV2fAK5sQnkJqe036kpKFMJ5BJJKMkklFQaajYLNZvTboBczsgXOcbNEA7nGyNBqgoDkgQ5HIIUiUCORiDHYpDjMYSq4whVxyHXVCNcV4tQXQ3C9fUI19ch3FivrWBNjahqatBWseq4VfUIhxCe1YSq5lmoWbOS2e7s2DhS5y8iebYbiTNdSJw6i8TJM0ic7YYyOZVXgth7Ou1v4KhXYrE+8JEgITq/DbUbrkDtlVegdv1aVK9egXBjPXOppMNyo+NI9fYjdaEHqZ4+pHt6ke4bMH4zg0PITSWgpjNg7SfsteOrZGQ8ndZgshmTSWjpsm6MUzmSDCkSQagmjqqWZkRmNyPSOlv7nduK6LxWROe1IdI2B+HGBrN/JAlVjQ2oamxA7brVRn9JkgQllULy/EVMHT+ByaOdmDx8HJNHO5C5NATz+vB3ZZb+YgxGL4OaZLyyPGbmOOpJMmpWLUP9tk2o37YJdVs2INI2B5Isc5HcVALJM+cwdeoskme6kDhzDsmz3Uh2X0B2dBzIz9YChRN/nVLw09AGypIzqgo1lUI2lUJ2aASJzlNsIBRCuLYG0YXzDNUxvmQRYksWI75kEcKzGo3rKUejqF7Wjupl7Wh5yxu1YnI5pC72YeLAEUy8chjj+w5h4vBxqOk0p4b5elago56kasI1b9qsOgIWAV48ebPQliinOmSGRgBVRXhWoy0OANScgtSFHkwe6cDksROYOn4CU52nkDzfA+QUYk3hb7UlY89Bp/PD6GnMm4inYVudPyqMkWSEmxpRvWIJqlcsQ/WqZZr6uWq5Re2kzaBKKoWJA0cx9tJ+TB07gZXf+bKruZSeTJ0mV1YawFkFEmJYN4NTAXQat4HtdpOxwh0ZVUVmYBDjrxzWZqMDRzB5pAPZ0THOJWWrFaTaUmxGN8u6PnwiBumMYmQJsUULUHPFKtSuW4PaDWtRc8VqhOprbfnwBiDvOuvxRj08GGJ45lhRRlIURYh0G8Ci4Z4ZRUGy6zzGXtyHsRf3Y/zlg0h2n9cqn09CD1JzjrZalUCkKyWjrxisG4hkzAGnznhGDocRX9qO2k3rUb91I+q2bERs0XzAQY3VRVTVKTUjqX5soCUUVVWRGbiE0T0vYeSZFzD6/MtI9/SK0vn/XvYs5WJ4+XjNY+YwkbY5qNu6EQ2v3YqGHVsRa1/ouMebbpn2m0FVVUBRMHm0A0OPPY3hx5/B1LFOqNkskYqcm3mXiWdjmQ7GmsaaD20TMmffy5mBJCM6fy4artmOput2oH7HVlQ1NqCSxHIz0Lo/KawNjajliMWouRzG9h7A0B8fx+Cjf/Uw+88UEZlZWUrHq4ORIlWo27wBs264Fk03XKetGpx9BcDesxqluGykRRnmysCrkJu4mVdVVcXU0U4M/PZhXPrDX5C+2EfNIiztnNy6WT2UTHsICE4LM3MoP8PbpOqWJ7plThvbVwUjyahetQzNN74ezTe9AdUrl3InXd7AZoV5ZWzWJFGTqIgVSZfM0AgGfvsI+u97EJPHO1GI0EpK6RgJkCVAkiHJkvkEOB7TjmNRyNGI9oQ4FoVcVQWpKgw5EgFCsnYe1twppGjUk66s5nKGnV7N5qBkMkBOgZJOQ81koGRyUJJJqOkMlHQaSjKlPfVOJLUn4HnfI10FZW2GRfug3AwAVK9ejpZdN6LlbTciOn+ulsblORiZxu3m4DHC1iTPogITB46g9+f3YfDhvyCXTFkGpVXTNsNY64NKxZPpAXuedJhUVQU5HkNVU4PmitCkuSyEG+o1F4aGeoTraxGqr0O4thah2hqE6mogx+Pa4I/HgFI8SCyhKMkUlEQSSiKhuZVMTCI3PoHsxKTmUjI+gezIGHJj48iMjGkuJiOjyA6PIDsyZrqTgD3LsweN88rghVEBSLKMhtdsxpx3vw2zbtypXQcXKcTKVPybIZfD0J+fRM8PfoHxfQeNZdF5bna6NRyoUAjh2lrDxSDSNsd0OZjTgsjsZlS1zEKooR6hmuqCmlWIFM3MXC5GUZGbnER2bFzzfh0YROZS3vu1/xLS/ZeQ7u1Hum8A2dExKMkUsQrQG2pQ4czacRhTqhob0fL2N6HtfbsRX7G0sk2rSiaLSw/9CRe+ey8Sp85y09m3WM4PgORoFJG22Yi1L0Rs8ULEFs1HdOF8zQN17hyE6+s0j88KEy97rZnKqKoKZSqBzMgo0j19SPVcROp8L1IXejQP2O4LSPdfgpJIOmyldQuUfTVhMrKMhh1bMffD70XT666CFAoVrT0F3wyqomDw4cfQ/c3vIXG6C6TzrohtQS88FIsh1r4I1SuXoXrlUsSXL0F8meZxKsdjXKuAa/2mgXG7OE7uApcTA2jqWmbgEjQP2HPa76mzSJ45h9TFPqhKTkj9tavCEuIrl2H+x25Hy9tuhBQOezL0GLnwNtC8xvE6Y+LgEZz54jcwvu+gUCV0keMx1Kxdhdr1a1CzbjVq1q5CfMkiSNGIZ8uVFykXE4i7qIqC3MQUEqfPYqrzNKY6TmresB0nkR0c9pRXrH0hFnzyI5j99jcbRgtbeS4baIBhTSKFZ7sFgO5//R7Of/deqEoOPJOobkKrmjMb9ds35R/Tb0D1quWa/z5VjpsliyyfrpObjbqcDM8/i/d8hpf2VckoCtJ9A5g8chwTh45r/mcHjyA7PEqsHuYmmzyvXrUcK77xRVSvXcld3VjX0Ihn3QzcxES4mkpj9MV9GH78GYw8sQfJ7gtaGgBydRwNr92CxtddhYartiG+rN1SMbfNnNuNOZMZp3wCxmR00eOTZ89h/OWDGNv7Csae36f5pyn58VZTjeY3vR5z3r0L9ds2ebL8WcZ3sRz1EifPYOSp5xBdOB+NV29HqKaamV4kr0qVTCaDXE5BKCSjqqrKFp/LKVCUHFQVkGUJ4bD9s1OKPiCgtdcywaimTUYmLqhIvqSoqopEIolMJoNYLIZoXv302reVzKR6ejG65yVAVdH85hsQqqspuJxp902qZFFVFV1d3Xh53wF0dXVjYnwC2VwOoVAINTXVWNK+CLt370JXVzfuf+AhJJMp5HJZY9DG43EsXDgfO3Zsw6KFC9DXN4Af3fsLAEB7+0K899abLeX95je/x/GOkwCAD9xxK7LZLO779e+0fPM2f1mWUVNTjaVLFuOaa16LlpZmg5+YnMQzTz+Pw0eOYWxsHMinb22dje3bNmPTpg2QK9hRbrpl2j/2Wakb1HQ6jd89+AgOHToK2gCcy+UwOjaO8YlJSJKEZDKF0fznKWRZRjQaRSaTwejYOMaOHMOxY5247bZbUFNdjUQiAUBFKpmylZlKpzGVSECCCkVRkEqZ+QJAJFKFbDaLkZFRvLz/AI4e68CHP/R+tLW1ore3Dz/7+X0YGx83Vp1wOIR0JouLF/vwuwcfQUfnSbznlnciVIGm6EoQy83A2jSScW6bIJ7wGFI94JXHO+ZtcPXzQhhVVXH/Aw/h2LFOQAWqa2pw9VXbsXRZO+KxONLpNPr7BxCPx2zL7ubNG/CWm25ELpfFU08/h6eeehaKouDZZ1/AG9+wUy+d226J+EvKpk0bsOutNyKdzuDJp/bguedeQjKZwhNPPIPdu3fhl796AOP5G2Hrliuxc+e1iMWiOHu2G7/57e8xMTGJ48dP4K9P7sHrd15r6QO3Pqf7qVyM0zXkbdjJOK/MjHqjnttmiyV+mBMnTuPYsU6oqoqa2mr87cc+gGuv3YH58+Zi1qxGtLbOxvr1a7FixTKyJKiqClmSjT3Fa7ZvMWKnphJmfTwopqqaz1eWEQ6HEY/HsPP6a409Yn//APbvP4jh4REAwOLFC7Fr15tQW1uDcDiMFSuW4ubdu4y8nn/+JaTTaeFrR0o5Ga+Trp6mEEZ2qiB5btnkUcdu2w5WGpJl8axwsuIsYcX5YQ4fOWaUveO129CY97vPZnNIJJJIJlNIJlNIJJLI6a+AIaqqqipyuRxefPFlox3Lly814x3uBlV1HigAcO7c+Xw6oLauFh0dJ4xytmzeaGvX0qXtaGrSPj+eTKZx4cJFo57kf5F+KhdDs3S8k/hlZswb9bxYnwplBi8NGZ6Uc+e2GsyRI8dw/wMPgXwc+uY3vQFNTY2GenPg4GGcOHkaU1MJpJIpyLKMdevW4HXXXY1LlwYBWJ1PbBeO+It8ahVAd/cFPPro4xgdG8exYx3GrLZ1y5X465N7jFybm2cx+2DWrCYMDQ1DAjA2Pu54vdyuU7kYlvrEO9fDCmFm0Bv1yliGZM7emUzWYHRVRVUVZLM5i7qTv6xIp9NIpzNQ8m/Ni8di2LJ5I8LGk1HrumA3rVIXMH/e19ePvr5+o4KxWBQ7d16LDRuuwFNPP2uky1o+IWiKHq4CFrOwk7nRjwm8mIyIKlVMZsa8Ua+cMnt2C7q7LwAAOjpOYO3aVQCAtWtXY9Wq5Th46CgefPARC6N1o4RNmzbib964E2fOdOHX9z+IRCKJ+379O3zqro8jEqkyZqEUobfr/6emEsZxLBZDImGez5s3F6tWLUc4HEJLczPa2xcZG/jZs1swMDAIQEX3+QtYsmSxpW7pdBq9vf1GXq1zZjvu/aztYuvg5WKcpNjMjDI6i+xPisFs3HCFDuOVA4ex/5VDUFUVoZCMSCSCcCikK/dEQXm9MxRCPB7DFVesxupVKwBVxeTkJDpPnERjYwNisSigqujt7Tc2vQAwOjqGnp6LAFTE43Fjn6KXM3duK3Zefw2uvWYH1qxZadwIkiRh/bq1Rl2ef34vxscnLG3fs+cFpJJJQFUxf95cQ5Xi9RcrzGmwlYtxysfLNeYxM+eNemCbxkrBtLcvwpYtV2Lvy68Aiorf/Ob32Lt3P5YsWYxIVRXOdnXbH/lLEiTVWuaKFUtx5OhxAEBn5ymsX7cWV25cj+df2ItcLoef/Lgq2LMAABBsSURBVPRX2J53H9i7dz8yGe2Fklu2EGqVwGy6Zs1KLF22BKdPn8XExCTu+f6PsX3bZtTW1eLkydM4fPgYIEkIhUK46aY3+jJCOEm5GF3I6+ikfnlluM8ZyMHNSuMUx2NpW75bOB1H15FX10IZSZKw6603or6uFk8/8zwymQzOdV/AuXMXAEnNbxAkyzhl9cXy5UshyzIURUFn5ykoioIbbrgOvX39OHv2HAYHh/DIHx8HdKdGCVi1ajl2Xn8NlS/bzKzXWZZlvOeWd+L+Bx5CZ+dJjI6O4c9/eRLkpqaurha7d+/CwoXzbRMX3Vc8e/x0M7w+EA13ZVRNmANDP6YrS6ZxG9hOA5yWSmSmphLoPHEKvRf7MDExCUVVEI/F0DSrCfPmtmLRogUYHh7By/sOAAAWLVqAtWtWGXk9++yLGB3TniLv2LEdjQ31UBQFR4924OTJ0xgbn4AkSWhqbMCqVcsNE6wkSRgYuKStTgAWLpiPdevWuG5Ou7q6cexYJwYHh6CoKupqa9DevghXXLGauXEWuabTwejiRf1xmvxEmMp/o95lLn7aHDClYQJHvUACyUvFOerlkkmkewfsr4sPhRBbvICp76X7B5Abn7SESVVh7a0XDfVQUilkBkdsnIhIIRmR1tnaxxcHh6AwHOx4ItdUI9Iyy/JBJlJUVUW6tx8i7hlSSEa4oV7oG4aUdBqZS94+LWaILCHaNge5RBLZ4VF/eVBSNXsWZIbLe6VJxTnqjTz5HDr+56ftFW1swLaX/gQ1FLItd2e//C1c+u0jNqbtjluw9IufwdiL+3H0jk+61pMlkXlt2PLMQxh97iUc+/CnPJAqIGkDuGHHVrTe9i40XrXN2v50Gvuuf0f+C1HyDO/lCJIEORpBbPFCNFy1DbPfeRNq16+x6OG6TBw6hsPv+oi1Lq6fRtck3NiA7fsfw/ATe9D5iX8QYtzK2fDQz1C7bo0Z6rKR1tvDSsdqLy/OK1OhjnrWY6eJ05q3arA6Y9TJyInOzc5oKR09iFwZVSsc2ZFRDD7yGI6+/+PovOvz2psiaMsT9d8apxp5KckUJjtO4OK9v8TBt9+O4x/7X8j0X2JbRxzydyyHk48II1QOZ4yQ4mfSJS2BfpmKdNTTB67Z2fwVy2TMoU4OejO99aYg8ycZPUyiygXgmVGpn4EH/4iOT37W8k2bcGHsJZv9N/TnJ3Hgbbdj8vgJxjW0MyLlsHrWa91ohqwzIPYkmmcZEtVE/DAy3Ymsgc2K4904dBreDeUkEsxvoTe/jd6ep3VFkSw/xtAk4mGLZzFS3jnOzMPsTHGGrpGebviJPei/70GqD5wZ66+VSfcP4NhH/h7ZoRFGnmzGuRz6+vivm87QebLGHOuXFDqcla5QpiId9cx51llFsq8o5MBnqUPWUDkaRdPrroKTLlzV3GiZbQHJUk64rhbz//YOC5PuG8Dgn/6KdL/pWEeW3POjX2LOLW+nai4ZRwAw/6O3a5v/TAaJE2cw8swLyOafV6gUk+q5iK6vfhvLvvp/bO0lz+RIBE3XX81tKwCEarU3D0baZmPW3+x0TAsAuakpjD7zArWGm3WLtM5GdN5cX6Z2EVWqmExFOuqZTs52ZYW7/yD+agxrVrcehRsasOo/vyb8UmC6XgAQqq3Bgk982JZ28Wc+ic5PfQHDjz2dv4VMJnHyDFLnexBpnW3JmUzXdtu7tW++yUt2bBznv3svev7r5/mXCVuZgd8+jIV3fdR8Ua/lBs9f7Po6rL7n60L6dP3mDai/5+tmDgxGVRSc+NQXqBbAqJsUiWDlt+5GVf67+ETUI1GjTCmYCnXUI7VyFRJD77QTqoXTGeusroe7bI85+yB6xwCqXuRyHKqtwfKv/pP2NkB6p6EqSJw6CyWdARS6PtZ8dQnV1WLxP9yJpV/8jKU2xnEmg0t/+IuttuZaY9bNaeDwZk4W0/ODn+PSQ48yytGO2j//96jfvqngcpxEVPUWYWRWoNt5sSrFF6subpnVeRsrjg5rbMgYOj63dIZVjZUHXS9681fV3ITqVcupdmjH2ZExQNVvUJYuzq5T6/tvRtPOa5jM6J4XqR6x96HbYGPFs8JGnn4eXV/7D6MkurzZN78Vbbe/u+ByWGK5JkVkKs5RDyD3DNoZAOQmp9B51+cBRkMmXjlsmf30T6lZ6kb81fPOjo6h887PMbcMc+94D+q2XcnIw1oOq/1ke6SQTLH5GhAPoaz5Wo0F9LIuSRLmfuhWDD/xDNEmLc1U5ymoeUsV3XoJErLj45o1iyFtt9+Chtdsts3O5PXS/6fO96Dzri9AtX2PtlZOzfo1WPalf+TmQbeNVw7N0MKL88swN9B6JZwqT6cVOeeqOMxZ3jwDoKkBDz9m2xqberOZlsyDZRnRGTWVwuDDpGqRrw+AphuuM24G6+pgLYfVBv04NzmFqc7TTCK6YK7l3NoOa770oKnbdqX2VJv4/gQASPdfMr4Lz75jAJRUGoN/+Ete9bSW1PT6a13bAwBKIomOj38G2eERe10BhGc1YvV/fg1SNAKWsNrDOualocNEx5QIYzOtso5Zs7loJfyrTabuqRozMWtfYP+1273hiZFsLF0nq57P7PhcDmfv/ndkx8dtTLipATWrV1D5mse2VY26RqFYDFXNTXZGyWnf2kO0yF5/uhyin6lyWBvmU5+/G5NHjoPVb3I4jJXfuhuReW3cuguVwzCB0sKb3QthPFmTnJ4kewl3i7POkeQsxp6XSRuSdm7fY9AzoRPD068lok7kuZrNYvjxZzB5+DjUTAa5ZAqjz76ExInTzHJb37sbciwKJf9VVRIk6r+17izR1SyasdeVyI9TjpHORY/v+dF/591e7HkDwKLP3InGq7dz6+wkfqyaxWa4zxn87uyLY6rV9w7mmb6021Uk682iz3Y2fV6QYakQrPqpxIwqV1Vh1g3XYeKVw7hwz0/z5ZH7F7Ps2o1X2Eyx+q2vMm9Mu6iqikz+I6M0I0Ws6okZzy5HdN0e2fMiur7ybaO+ep66tOy6EfM+8j7B3AoT3n6jUIZ7M4hsQOgMeRseHuO2wyfnLzkaw9w73s38xvnhx59G4sSZfGrOKmU51s5CtTVofd/NzA109Yqltjpa86Nm/HAIiz79CYy+sA8T+w9Z6q6nbHnbjVj6pX+0fTeZ87oHox7GBvbceSiTUzYm3NgAOWL1DiXrGYrH0HbHLcz8q1ea7aWvY/LCRZy46wvM/QgAVK9egWV3f85m3OCpQbxySMaoPzVuREzDfhnmzcCyitCVYzWSV7iIGmVlrGqSCgnheAyLP/NJgPJalSQJ6b6B/M1gzlkqkS+MGNU6eGY1YfFn77S11X2fY58bVVUFJAlzdr8FE/sPMTfD9a/ZjFCt/W3R5ozN3kDTMvjI40wmtmSRMVnYe1BCqKYG7Z/9O+6ExSorl9Q2zOnBQcZqq6Iq/+AyVFvD5FnluImo5YnOlzaJe2Ve1Y56vPzIDrKXQZdjZWa98XXEgLT+dH3125zPCBD9nP9REgnmzJoZGMSF//o5k7E+4OIZEqyzLfmfNVhOf/7LmDx0jNkeSQ5hxTf/BbHFCxhtEi+HxbC0BzeWrLcfRshRj1UI3TCe1UDEAkWLxPhh5WlZIYiUNMPLOzs6ilze+kLXkS7HXi9iA00wVXNaUHflOks99PS5sXH0/ff93L4gmYnDx211Spw5h6Mf/Dtkh4aZTMtNb7C1U08DALmJCeQmp2wTGqvtAND70/+HgQf+YCtHz3nhnf8Djddfxe030XJEJlg6nJemEEbYmuTHMuTfmiReD3s+/JuAltzoOPa/fjdlprRK1ewWrL3335k50nXQ/zffdAPje+60uP5fP4T5H/8g8Q2l5I1r5nnu/35XK79lFtJ9lzD63EsY+uPjxiftaKbhqm2oWb/GwQKmfdng/htuRlUL/71JobparPvlPUj3DaDry99itlc/D9XXYnzvK9y8dKlZu0r4q4fdr2/pmGn/2CdbrBovb4DbGVIIhlKVTG0bSPf2Id3bRzFmusg8Uq0RW9mab3oDur7yLajZHKw7AiDZdR6TRzpQu2Et5Hhc++pW45WQZtp0bz9O/u9/purL2lmokGtqsOSfP80YBHYm3TeAdF8/I0+tnHD+5WXjB45ASaUc8lJx9l++4Vo3QPukW2ROC4af2ANIMhqv3mY4FPqRUlmTCnLUE1V7PIll4KrEsbVMqyWK1Qxi+auvo7RnliZtLdO2J4hEXG8FvU6RtjlovO4qIi+SVDH02NMAALkqjOjCeZRuz2bo//qPHI9j1be/bFiD9PY6Me7lAFDtOzevdSPDhx59EhOvHMHkkeNG+53E69jyMxZppiBHPZZJrNAbRHP3lRi/9jJ1ibUvdGTiSxcjFIsbmr6pmvB/6X1HfMkiSKEwtwyybpIk5W3u7LJG/rrH6KfWW99p2YV4qV/dxnVYf98P0bTT+hmF2ML5CNXVObTJqRw9j3keGLdyAClShdzUFLJj45A5rhqsviynWKZU1oaHtykhj3kMy2LkxtZuWIvG63ZoFhlJsv5S5evSdtvNaLhqGxAKMRm5phpLv/RZVLU0A7Lk6VeStTwic1vR/rlPaZ9BkGUi3uxCsm71r92Khqu3W+ZH/Xfi8HEkTmg+S3M/dCsWf/ZOzYWBtuaQJ5IEqSqM+LJ2zLn1HVj7s//A+gd+jOq1K239KseiWHb35/J19dZe3RJWvWYlWt9/s/FmD9KKRrfH/FWpOHN9iC9djPiydlSvXIrognncCdevQUck3I2p2Dfq5aYSVp1VkhBuqHdmkknDNwfQPslGP+BSU2lPq5ckScaXtevlKOmM4bEpSRLkWJSZZ/LMORx8xweQy78ImJQ579qFZV/7J0tYbmwcucl8u/X8JAlyNAopEka4sYHYeLP7gL4+XtsLSfN90hllKoH0wCDjc9viEp3fBjkadR07ZHt08XqtCmGMN+q5ZeQ2gOlzsYdXYmWUii0HM/rsS+j4+KeRpd/rFAph3a++j/qtG4X6VSQuYApjhF4vWcggDQRInu1G97/dg+HHnkZ2cgq6shFbMA8bfvczhJsapreCgQBAYa+XFDFpvVqF1Te5ZBLpC71IDwxCzeUQndeG2OKFxr7ET38GjKnNeOFYjOebgawsq+JuYfSxUREPDEs1E6lnuRiybU4M3VcBY1fTWdfDz1gRYZjPGVTVbuWhK8dqpNOGmSWSJBm/IozIZotOUykMjwsYPsObdFk8feP5YSrSUY/H6DcOT1hx08XQK4TIUh4w7BuBFe8kfpmCN9DlsgSw4slzkeNyMX4MDgHj3O/lYILvZwgkkLxU6EvEAgmELyL7NT9M5TnqCZbppexyM4EULl770k/f00zFOeq5iRdb8kxgAmHLdPRlxTnqOTF0+WQYr/7TxTj1o1O+AeM8/liMaLgbw1STaFutm2VI9Fy08jxGdMWabka0nbybKmDYz3VEJutCGJlVAdZsR98QTncfXSmRML9MOWeOYjD0BWE9lAoY7w/zeGV5YQJHvUACyUvgqFci8dM3AeOfAQp31PNsWi1UxWGpYF4ZN3a6Gd45K2+n/F7NDN3nbvo+T8X3wgSOemVieFzA8JlyO+r9fxf0X8Hf1ExBAAAAAElFTkSuQmCC';
                break;
            case 60:
                rfc = 'CHE041201L59';
                logo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMMAAADDCAYAAAA/f6WqAAAgAElEQVR4nO2dd5QdR53vv933zg2TRzPSjPIoBytYEeSEhWENBhFkMAZskx7s44DX7HkPlgXe7uEsx6THsgssi1nAxIXzjA3YYIPBNg5ylCUra0ZxNNJogiaHm7vfH327u7q6qru6b5g7cv/mzEx3VX0qdXXVr379u30lVRM4iSRJUFUVkiQBgHHM4ui0upAMydJ58hgyb6d60emmg+H1jVveAcMOLxcjud4JgQTyKpGwyL3gdJcHEsjlIrJIouBGCOTVIGFaT+eJyD7AKW0xGC9SyUwglSkywJ/56U0GK1yPc1s96A2zU348hgwT2fRPFxNI4eLUl3ScSL+LMGGWlcjtWBfWzl2SJOYK4lYRUYa+8ZxWmOliRK1RAePM0JMha0zw4nwxgTUpkEA0Kdia5CfOb35O9QO8qSnlYnQuYCrfIhmsDIEEkhch02oggbwaxPVm8LNTFxG/C5IXK0MlMYF4k+mwJsmsSFZC0tTIMjuyjvW0PIZO44Vxa9h0M7y6i6QNGLt10Yl1K0OUCfMqTZqgSNE3QryBQTNOm04nU5tbxZ1mZyezWjkYmnUyFgQMm3EyW/NEj/fLhOlB6HUAus2MvDAWL8rkIzDVcRITrxxB+tIgoCjsdCWSyNxWtN7ydsc0bhYU3uRRbCZxugvj+w4i3dsPNZdzrHOxRY7HMe+jt3HjRdsjssrQ8V4ZSVGUghTd6TCZDT/2FM796/cwdewEVKgA9M70Uo/CmPrNG7Hu1z/0wJZfxvceQNfXv4PxvQfy10jvK9E262n9M5HmWdj60qMeaz49Iuyb5CTl8s1Rczmc/dI3cfEnvwL0u9laE4C4OVSoliHPrqVfpnzt9iqqqqLn+z9F19e/CzWXhQRAgsRpj5SfUKxD3rkPvDGl7ic3VUiUEXroVinS9bXv4OKPf8W5ECrzGEQaeo4rlKnUvuv92X3o+sq3jZrSg5NSQJjhxWTK0U9+yrBtoJ02GW7h9EaHdeyWF1kpJ2b0hX3o+cEvtHREl5NHltmIc1xMphJXhsTZbpy9+98A0K0zz+lwJykG46ef3MaLqMezF2ZGOOqpqorz3/khVKW8mz9RYfUBq5/K4Qx34Z6fQEmlbHWUjDVNXP8vFsObPN3aQ0+SrHFUTEc9y57B67FbnAjDEzJNdmgYY8+/bMw0fF2eL6VkWH3gpZ+KxajZHIb++ITDLM5eU52lUIZdV9E+YKUpFePJUW+6nK2mOk5ByWZh1dwBQDU2hsifa7HWNKViKm3PkLpwEdmRUcYcrlqGp9X+xrvli8MAlddPPBG2JonchaWS7Ni44+zECyk1U2l7hszIKAD+/C1R/7Vj5zYUg6m0fuJJeLorICosQ6qpl0r5I1anl4th1LlIJj9hRlG4mr3ZAhCrn/ugLpzxLn76oBhiuGOI7tynS9gLtjWGX8vyMG4WNTcpBsPZtVnixCxD5WKswtps89Lwzv0yMgDbXsDJbUJV7Q50ZBgrnMfQaXgMUQvoz1H1czqeFVYaxtpW0XNWXCkY1pm9PexnK8Vm/LRHZFJwG7NemZnjqEddAv5A5YcVn4GtnqxwXjzvGY5fRqslufkn+jQfazcSWFMVn7HXUaQ99BhwWy1Izi/jaE1yWiHcznk3mFN+ToyYpkqeA04DuDiMmPCscE4Xyg+j1zCfkqvoUdMV6EFeCsZre5zCvYooI7SBdpqt/JhbfTXI09bMnB1LybitCG7pyLhiMACoOVol+o2bG3FcOsZve3h8KZiiOOoBKMmGxpI/dyYi5yHVkrrUjJcZzUmKzZBrHP10hLXVtjsnFpMR1/95ajkvLW+z7ZcpmqOel5nND0PP1ea5dkQ73ZWDEV0ZRKSYjGr7ax2c1phSM+Jt89IHTuq4X4a7MpCbEP282LM9Kx13hqDMdmY4nYIOLx3D8qeabjM025ypWuLYPVkqRmxlsOXkoS+LtbJanjM4mbfoQa6HebnreW4dIvZkFd5nzlKL04aQbh+rz3jHfhnArZ9IBYbeI5WKsfeJp/ZQkzIZRobzLFBemDAZ6dU1w41hpXMri5c3z0+GJ3SaUjB+HMREj30zDiuD1XPIaR0sJsO+5n76QDSNX2ZGOOoBds2U7HaVSiUBRHjpmOnqCyfh1Yh3k/Od7orDAJXZTyyZEY56ADizk3NIqZnp3h+wxHElY6QJHPVMCRz1isYw6jwNZlanlcFqKXNXHIvDeJfpMkQEjnpFZESsYk5SDMZJeTFnbJEyysVYhfccgJWGd+6XCRz1fDPWtoqes+JKwbDO7O0JHPVICRz1CmJgqycrnBfv5Hvjh9FqSW7+iT7Nx5JGAZooDWOvo0h7WGZStxWAZ8IVZQJHvYIYMeFZ4ZwulB9Gr2E+JVfRo6Yr0IO8FIzX9jiFexVRJnDUK4BxWxHc0pFxxWAAUHN04KjnhZkxb9Qjt2akNYe3dVTLwIgsv16kOBto9qYf0NpjtYvBNqsXmwG8jQ9bezy68xTCzJg36vHcDFihbgpPsRi3vivlks5jeP3E0vrd2lwMhq6fiExHvwEe3qjHOuZtWMhjnqlRZJNEHns10/lZq7wyha4MTn3il3HqJ1aMW5uLwXjpJ3psiTJ+yqGZMA3QjaAhJ91WdMPNuwkc8yH+WvV5yZaK/Sa44jNO7aHjWTe520ThlbHWjBSWO4mpEJaW8dceui+YpRWZcXXUc3JwcpvFnPLj5cu1rhB/Sf2VlQqW+BIznP6g2+PUb7y0vhhGbdk1dw4rJlOsPnBLy8tblJkWRz1fFijKXkFu4vT5yDqHSyVnKnO/ZbaIfFu5GWf9RJ91M1x8BqjUfrLLtDnqec2H9+EeM4xcoKWyMOWwonkX1kqnWs6d3p5aCqYy+8kuM8xRjxfjzYGuXMx0mFf5Vh5zRqfXQ54Uj/EmfvqgGDJjbgZ+1/BnLJHc/DK5ySmM7z8kTJdDpjpPcdpjXe1mgqPedAjXa9WLiYvUCen9hVO+ogzA1lxN3d68CCpl0SgVM9lxAod2f4jJ6HO01f5itgJGfma5lysD2K856/qT4uTpwBojTvl6YcJ0pFMFWaZWVoWdzt2Ez+gXgzbcaUfWTS9tECw3Q2weqRzYigy14bzMGIA9CYIRTwrLnE8f8565+GHCvLtK1ALgxNAd4NQRbox902Y/k5gXpvwMm1MZx68exus4cAorFcNdGVgwa+Dz7nanhrt1Bvuhm9vWjJXnTGB4KS4vRmR8OYnTw95iMYGjXgkY89aQqDS8PC5fBvA2PmzuJQJssZjAUa8EjKlfl8cZrpIZQFzl9pu+WEzgqFcGxi0NK/5yYpxmahG/LBHGTzk0EzjqlYTR05gKFG9dmz4HunIx7AGuH/MmSyMHDzdFoUzgqFcSxolgy+XMBI56Avl5kUp01OMxuuZcLme4SmYAf/r8dEjgqFciptzOcJXMBI56RRb+3GIqM5XiqKelYe01eGkvd8abOOn8pZQZczPwu4Y/Y4nkViqmspzhKpmxynTdCED+jXpenyCz0ui/bqwfBrBak1Tos46a/yF1fDLN9DBmCtUSYo215nG5MoD9mpPHvDFC/9L5sNKz8vXCBI56JWFmhgNduRjAPn5sBGNFCBz1OIx902Y/Cxz1KpcJHPU8VtaRcd2asfKcCQwvxeXFiIwvJ3F62FssJnDUKwFj3hoSlYaXx+XLAN7GB63GBI56DAkc9WYmA4ir3H7TF4sJHPXKwLilYcVfTkzgqMcJc7oJHPMh/to3cNZUgaNeJTHsAa4fB456DvkGjnqXHxM46gnk50UCR72ZyQD+9PnpkMBRr0TMTHCgKxcTOOoVWfhzi6nMBI56lcp4Eyedv5QyY24GftfwZyyR3ErFVJYzXCUzVpmuGwEIHPVKwpgpVEuINdaax+XKAPZrTh7zxgj9S+fDSs/K1wsTOOqVhJkZDnTlYgD7+LERjBUhcNTjMPZNm/0scNSrXCZw1PNYWUfGdWvGynMmMLwUlxcjMr6cxOlhb7GYwFGvBIx5a0hUGl4ely8DeBsftBoTOOoxJHDUm5kMIK5y+01fLCZw1CsD45aGFX85MYGjHifM6SZwzIf4a9/AWVMFjnqVxLAHuH5ccY56tOgVd5rZ6bQi56JWBJ41yaqLWi8MqbdrR3YdvlyMNS0ogmg3FX85MrY0nBmaPualocP8WKZ4TJiVQMRqJFqJYup/tEmTtyiac7Q0TYy5OtCDiGSsoZcrkw9hjJ1CzPosK6Yb58Z4siZx3as9hvtl7PMyqHNTfSk1I4WrUNVQ51DX8ouSzSI3Og6APYvbHOgovmSM4MNWr1JsZtp9k5z0O0Zq4y9DYaPSkbp78ZnaDWux/v4fCda7PDK+/xAO7f5g/syu3KiUAghbitIxM0Fk8kTfJ4jqW4U+pfb+YE6CrpTA9gvGeSkZ97a5tYu1ZBfOsOsJsFY/uo2lYOwi2h7eWOGpOnScV8ZyM9C7e/K/yKeVeIPbSSXSf8UY0mFO+0vHk7N6aRkqhDGIRfun6AysT2VUzv9pYQTbI2K8ofMVsU45MZbvgXbb6fOeKejnToXSadxWFZtJl7DtWL0j2ZeJjCkdY4qTk5lTvxWTAVFnUANVD9NncfZDzOIzftvDM+U7sWR5fhibNcmviuQ3jVtDzHO7FmrV8O07AD2sVIxIe+h4kf72y1hrZ8nNFkeqMpwaFIUxYny0x2ny5I3TQpiSbaCLaVLNx7ooK/Snk9nzeXEZMXGbCXkqlleGVVtrqOlQwWp3KRiROrs5e5aLKYqjXjmENyvRWzczjd3yXWzGy+N/ETNzURiHlYHvdFc6hqyrn/Y4SbGZaTetiov9gY+TykPGlZIxakfpw15uFF6YH4Z2pjMHMr3qqUZbyPYWnymsPW5CqlqiLI8JswLdznkFiAwE/0K/oYiMcaLKxAjO6Lz4YjGst1jw2kOnKzVj4X30gS7kGBPZHIsyzOcM+jH5n5fGiSHjneLcGECbaVTjhz62xsM4Lh1D9odI/3kxLBTEMH/pOKvBuJRMMfuAFhHjgxcmcNQrgOFdXKd2ijipFcLwNXkznqcGloKxpRFsT+Co58JUmqOewbr0Bavf3PrVD0O2hGyPNc7U9OkBXhrGXkdv7WFL4Khnm8tBnetzuX0OKwlTpL1RcR3O7HU3dXmJ+s8iS8AEjnpi4m3Dbc56rK2jNR1p6ygVU4liztV0CwJHPWcJHPV8M+5tc2uXk3HCP8OuJ8Ba/QJHPTIucNTzzVAhrM1s4KhnZwTbI2K8ofMNHPU4l4mMKR1jSuCox2b8tidw1HNg9MWXVghAhNE7AD2sVIxIe+h4kf72y1hrZ8nNFhc46tmZwFGvIEZMAkc9f+0RUaWKyQSOegUwgaOeO0PWNXDUK5oEjnqBox47H68sjwkc9YrFBI56royFDxz12HFuDKDNNIGjngDD/KXjAkc9VnjgqFcAw7u4Tu0MHPUCRz1PwrU6UN3LW1RVIz5w1Asc9cSZwFGvECZw1BNjAkc9MfG24TZnPdbW0ZqOtHWUiqlEMedqugWBo56zBI56vhn3trm1y8k44Z9h1xNgrX6Box4ZFzjq+WaoENZmNnDUszOC7REx3tD5Bo56nMtExhSLkSQZkixDilQh3FhvoQNHPTbjtz2Bo54Doy++tEIAIozeAehhbowUjaCqqRGRtjmItM1GZHYLqmY3I9LSjHBzE6pmNSLc2IBwQx1CtTWQYzHh9tDxIv3tl6levQIb7r8XmaERZAaHkRkcQmZgEOmBQe1/Xz8yl4aQSyQBRTHzZ9cg/5/cHdAmBHemkPYEjnr8WBdlhe90J0ciqGqZhdiCeYjMa0N0bitiixcgtmgBogvmoqqlGXIs6rm+rqICai4HqArUXH7wKQpUYiAatQ+FAH1WDIe0CxQKMbPlzXSheAy1m9Y7MzkF2dFRpPsvIXWxH+meXqQuXETqwkUku3uQOt+D7MgolGzW6MHAUa/CRMRRTwqHEZ0/F9WrV6B69XJUr1iG+PJ2ROe1IVRb48kUpyoKclMJ5MYmkBkeRnZoBJnhUeTGxpEdGUV2fAK5sQnkJqe036kpKFMJ5BJJKMkklFQaajYLNZvTboBczsgXOcbNEA7nGyNBqgoDkgQ5HIIUiUCORiDHYpDjMYSq4whVxyHXVCNcV4tQXQ3C9fUI19ch3FivrWBNjahqatBWseq4VfUIhxCe1YSq5lmoWbOS2e7s2DhS5y8iebYbiTNdSJw6i8TJM0ic7YYyOZVXgth7Ou1v4KhXYrE+8JEgITq/DbUbrkDtlVegdv1aVK9egXBjPXOppMNyo+NI9fYjdaEHqZ4+pHt6ke4bMH4zg0PITSWgpjNg7SfsteOrZGQ8ndZgshmTSWjpsm6MUzmSDCkSQagmjqqWZkRmNyPSOlv7nduK6LxWROe1IdI2B+HGBrN/JAlVjQ2oamxA7brVRn9JkgQllULy/EVMHT+ByaOdmDx8HJNHO5C5NATz+vB3ZZb+YgxGL4OaZLyyPGbmOOpJMmpWLUP9tk2o37YJdVs2INI2B5Isc5HcVALJM+cwdeoskme6kDhzDsmz3Uh2X0B2dBzIz9YChRN/nVLw09AGypIzqgo1lUI2lUJ2aASJzlNsIBRCuLYG0YXzDNUxvmQRYksWI75kEcKzGo3rKUejqF7Wjupl7Wh5yxu1YnI5pC72YeLAEUy8chjj+w5h4vBxqOk0p4b5elago56kasI1b9qsOgIWAV48ebPQliinOmSGRgBVRXhWoy0OANScgtSFHkwe6cDksROYOn4CU52nkDzfA+QUYk3hb7UlY89Bp/PD6GnMm4inYVudPyqMkWSEmxpRvWIJqlcsQ/WqZZr6uWq5Re2kzaBKKoWJA0cx9tJ+TB07gZXf+bKruZSeTJ0mV1YawFkFEmJYN4NTAXQat4HtdpOxwh0ZVUVmYBDjrxzWZqMDRzB5pAPZ0THOJWWrFaTaUmxGN8u6PnwiBumMYmQJsUULUHPFKtSuW4PaDWtRc8VqhOprbfnwBiDvOuvxRj08GGJ45lhRRlIURYh0G8Ci4Z4ZRUGy6zzGXtyHsRf3Y/zlg0h2n9cqn09CD1JzjrZalUCkKyWjrxisG4hkzAGnznhGDocRX9qO2k3rUb91I+q2bERs0XzAQY3VRVTVKTUjqX5soCUUVVWRGbiE0T0vYeSZFzD6/MtI9/SK0vn/XvYs5WJ4+XjNY+YwkbY5qNu6EQ2v3YqGHVsRa1/ouMebbpn2m0FVVUBRMHm0A0OPPY3hx5/B1LFOqNkskYqcm3mXiWdjmQ7GmsaaD20TMmffy5mBJCM6fy4artmOput2oH7HVlQ1NqCSxHIz0Lo/KawNjajliMWouRzG9h7A0B8fx+Cjf/Uw+88UEZlZWUrHq4ORIlWo27wBs264Fk03XKetGpx9BcDesxqluGykRRnmysCrkJu4mVdVVcXU0U4M/PZhXPrDX5C+2EfNIiztnNy6WT2UTHsICE4LM3MoP8PbpOqWJ7plThvbVwUjyahetQzNN74ezTe9AdUrl3InXd7AZoV5ZWzWJFGTqIgVSZfM0AgGfvsI+u97EJPHO1GI0EpK6RgJkCVAkiHJkvkEOB7TjmNRyNGI9oQ4FoVcVQWpKgw5EgFCsnYe1twppGjUk66s5nKGnV7N5qBkMkBOgZJOQ81koGRyUJJJqOkMlHQaSjKlPfVOJLUn4HnfI10FZW2GRfug3AwAVK9ejpZdN6LlbTciOn+ulsblORiZxu3m4DHC1iTPogITB46g9+f3YfDhvyCXTFkGpVXTNsNY64NKxZPpAXuedJhUVQU5HkNVU4PmitCkuSyEG+o1F4aGeoTraxGqr0O4thah2hqE6mogx+Pa4I/HgFI8SCyhKMkUlEQSSiKhuZVMTCI3PoHsxKTmUjI+gezIGHJj48iMjGkuJiOjyA6PIDsyZrqTgD3LsweN88rghVEBSLKMhtdsxpx3vw2zbtypXQcXKcTKVPybIZfD0J+fRM8PfoHxfQeNZdF5bna6NRyoUAjh2lrDxSDSNsd0OZjTgsjsZlS1zEKooR6hmuqCmlWIFM3MXC5GUZGbnER2bFzzfh0YROZS3vu1/xLS/ZeQ7u1Hum8A2dExKMkUsQrQG2pQ4czacRhTqhob0fL2N6HtfbsRX7G0sk2rSiaLSw/9CRe+ey8Sp85y09m3WM4PgORoFJG22Yi1L0Rs8ULEFs1HdOF8zQN17hyE6+s0j88KEy97rZnKqKoKZSqBzMgo0j19SPVcROp8L1IXejQP2O4LSPdfgpJIOmyldQuUfTVhMrKMhh1bMffD70XT666CFAoVrT0F3wyqomDw4cfQ/c3vIXG6C6TzrohtQS88FIsh1r4I1SuXoXrlUsSXL0F8meZxKsdjXKuAa/2mgXG7OE7uApcTA2jqWmbgEjQP2HPa76mzSJ45h9TFPqhKTkj9tavCEuIrl2H+x25Hy9tuhBQOezL0GLnwNtC8xvE6Y+LgEZz54jcwvu+gUCV0keMx1Kxdhdr1a1CzbjVq1q5CfMkiSNGIZ8uVFykXE4i7qIqC3MQUEqfPYqrzNKY6TmresB0nkR0c9pRXrH0hFnzyI5j99jcbRgtbeS4baIBhTSKFZ7sFgO5//R7Of/deqEoOPJOobkKrmjMb9ds35R/Tb0D1quWa/z5VjpsliyyfrpObjbqcDM8/i/d8hpf2VckoCtJ9A5g8chwTh45r/mcHjyA7PEqsHuYmmzyvXrUcK77xRVSvXcld3VjX0Ihn3QzcxES4mkpj9MV9GH78GYw8sQfJ7gtaGgBydRwNr92CxtddhYartiG+rN1SMbfNnNuNOZMZp3wCxmR00eOTZ89h/OWDGNv7Csae36f5pyn58VZTjeY3vR5z3r0L9ds2ebL8WcZ3sRz1EifPYOSp5xBdOB+NV29HqKaamV4kr0qVTCaDXE5BKCSjqqrKFp/LKVCUHFQVkGUJ4bD9s1OKPiCgtdcywaimTUYmLqhIvqSoqopEIolMJoNYLIZoXv302reVzKR6ejG65yVAVdH85hsQqqspuJxp902qZFFVFV1d3Xh53wF0dXVjYnwC2VwOoVAINTXVWNK+CLt370JXVzfuf+AhJJMp5HJZY9DG43EsXDgfO3Zsw6KFC9DXN4Af3fsLAEB7+0K899abLeX95je/x/GOkwCAD9xxK7LZLO779e+0fPM2f1mWUVNTjaVLFuOaa16LlpZmg5+YnMQzTz+Pw0eOYWxsHMinb22dje3bNmPTpg2QK9hRbrpl2j/2Wakb1HQ6jd89+AgOHToK2gCcy+UwOjaO8YlJSJKEZDKF0fznKWRZRjQaRSaTwejYOMaOHMOxY5247bZbUFNdjUQiAUBFKpmylZlKpzGVSECCCkVRkEqZ+QJAJFKFbDaLkZFRvLz/AI4e68CHP/R+tLW1ore3Dz/7+X0YGx83Vp1wOIR0JouLF/vwuwcfQUfnSbznlnciVIGm6EoQy83A2jSScW6bIJ7wGFI94JXHO+ZtcPXzQhhVVXH/Aw/h2LFOQAWqa2pw9VXbsXRZO+KxONLpNPr7BxCPx2zL7ubNG/CWm25ELpfFU08/h6eeehaKouDZZ1/AG9+wUy+d226J+EvKpk0bsOutNyKdzuDJp/bguedeQjKZwhNPPIPdu3fhl796AOP5G2Hrliuxc+e1iMWiOHu2G7/57e8xMTGJ48dP4K9P7sHrd15r6QO3Pqf7qVyM0zXkbdjJOK/MjHqjnttmiyV+mBMnTuPYsU6oqoqa2mr87cc+gGuv3YH58+Zi1qxGtLbOxvr1a7FixTKyJKiqClmSjT3Fa7ZvMWKnphJmfTwopqqaz1eWEQ6HEY/HsPP6a409Yn//APbvP4jh4REAwOLFC7Fr15tQW1uDcDiMFSuW4ubdu4y8nn/+JaTTaeFrR0o5Ga+Trp6mEEZ2qiB5btnkUcdu2w5WGpJl8axwsuIsYcX5YQ4fOWaUveO129CY97vPZnNIJJJIJlNIJlNIJJLI6a+AIaqqqipyuRxefPFlox3Lly814x3uBlV1HigAcO7c+Xw6oLauFh0dJ4xytmzeaGvX0qXtaGrSPj+eTKZx4cJFo57kf5F+KhdDs3S8k/hlZswb9bxYnwplBi8NGZ6Uc+e2GsyRI8dw/wMPgXwc+uY3vQFNTY2GenPg4GGcOHkaU1MJpJIpyLKMdevW4HXXXY1LlwYBWJ1PbBeO+It8ahVAd/cFPPro4xgdG8exYx3GrLZ1y5X465N7jFybm2cx+2DWrCYMDQ1DAjA2Pu54vdyuU7kYlvrEO9fDCmFm0Bv1yliGZM7emUzWYHRVRVUVZLM5i7qTv6xIp9NIpzNQ8m/Ni8di2LJ5I8LGk1HrumA3rVIXMH/e19ePvr5+o4KxWBQ7d16LDRuuwFNPP2uky1o+IWiKHq4CFrOwk7nRjwm8mIyIKlVMZsa8Ua+cMnt2C7q7LwAAOjpOYO3aVQCAtWtXY9Wq5Th46CgefPARC6N1o4RNmzbib964E2fOdOHX9z+IRCKJ+379O3zqro8jEqkyZqEUobfr/6emEsZxLBZDImGez5s3F6tWLUc4HEJLczPa2xcZG/jZs1swMDAIQEX3+QtYsmSxpW7pdBq9vf1GXq1zZjvu/aztYuvg5WKcpNjMjDI6i+xPisFs3HCFDuOVA4ex/5VDUFUVoZCMSCSCcCikK/dEQXm9MxRCPB7DFVesxupVKwBVxeTkJDpPnERjYwNisSigqujt7Tc2vQAwOjqGnp6LAFTE43Fjn6KXM3duK3Zefw2uvWYH1qxZadwIkiRh/bq1Rl2ef34vxscnLG3fs+cFpJJJQFUxf95cQ5Xi9RcrzGmwlYtxysfLNeYxM+eNemCbxkrBtLcvwpYtV2Lvy68Aiorf/Ob32Lt3P5YsWYxIVRXOdnXbH/lLEiTVWuaKFUtx5OhxAEBn5ymsX7cWV25cj+df2ItcLoef/Lgq2LMAABBsSURBVPRX2J53H9i7dz8yGe2Fklu2EGqVwGy6Zs1KLF22BKdPn8XExCTu+f6PsX3bZtTW1eLkydM4fPgYIEkIhUK46aY3+jJCOEm5GF3I6+ikfnlluM8ZyMHNSuMUx2NpW75bOB1H15FX10IZSZKw6603or6uFk8/8zwymQzOdV/AuXMXAEnNbxAkyzhl9cXy5UshyzIURUFn5ykoioIbbrgOvX39OHv2HAYHh/DIHx8HdKdGCVi1ajl2Xn8NlS/bzKzXWZZlvOeWd+L+Bx5CZ+dJjI6O4c9/eRLkpqaurha7d+/CwoXzbRMX3Vc8e/x0M7w+EA13ZVRNmANDP6YrS6ZxG9hOA5yWSmSmphLoPHEKvRf7MDExCUVVEI/F0DSrCfPmtmLRogUYHh7By/sOAAAWLVqAtWtWGXk9++yLGB3TniLv2LEdjQ31UBQFR4924OTJ0xgbn4AkSWhqbMCqVcsNE6wkSRgYuKStTgAWLpiPdevWuG5Ou7q6cexYJwYHh6CoKupqa9DevghXXLGauXEWuabTwejiRf1xmvxEmMp/o95lLn7aHDClYQJHvUACyUvFOerlkkmkewfsr4sPhRBbvICp76X7B5Abn7SESVVh7a0XDfVQUilkBkdsnIhIIRmR1tnaxxcHh6AwHOx4ItdUI9Iyy/JBJlJUVUW6tx8i7hlSSEa4oV7oG4aUdBqZS94+LWaILCHaNge5RBLZ4VF/eVBSNXsWZIbLe6VJxTnqjTz5HDr+56ftFW1swLaX/gQ1FLItd2e//C1c+u0jNqbtjluw9IufwdiL+3H0jk+61pMlkXlt2PLMQxh97iUc+/CnPJAqIGkDuGHHVrTe9i40XrXN2v50Gvuuf0f+C1HyDO/lCJIEORpBbPFCNFy1DbPfeRNq16+x6OG6TBw6hsPv+oi1Lq6fRtck3NiA7fsfw/ATe9D5iX8QYtzK2fDQz1C7bo0Z6rKR1tvDSsdqLy/OK1OhjnrWY6eJ05q3arA6Y9TJyInOzc5oKR09iFwZVSsc2ZFRDD7yGI6+/+PovOvz2psiaMsT9d8apxp5KckUJjtO4OK9v8TBt9+O4x/7X8j0X2JbRxzydyyHk48II1QOZ4yQ4mfSJS2BfpmKdNTTB67Z2fwVy2TMoU4OejO99aYg8ycZPUyiygXgmVGpn4EH/4iOT37W8k2bcGHsJZv9N/TnJ3Hgbbdj8vgJxjW0MyLlsHrWa91ohqwzIPYkmmcZEtVE/DAy3Ymsgc2K4904dBreDeUkEsxvoTe/jd6ep3VFkSw/xtAk4mGLZzFS3jnOzMPsTHGGrpGebviJPei/70GqD5wZ66+VSfcP4NhH/h7ZoRFGnmzGuRz6+vivm87QebLGHOuXFDqcla5QpiId9cx51llFsq8o5MBnqUPWUDkaRdPrroKTLlzV3GiZbQHJUk64rhbz//YOC5PuG8Dgn/6KdL/pWEeW3POjX2LOLW+nai4ZRwAw/6O3a5v/TAaJE2cw8swLyOafV6gUk+q5iK6vfhvLvvp/bO0lz+RIBE3XX81tKwCEarU3D0baZmPW3+x0TAsAuakpjD7zArWGm3WLtM5GdN5cX6Z2EVWqmExFOuqZTs52ZYW7/yD+agxrVrcehRsasOo/vyb8UmC6XgAQqq3Bgk982JZ28Wc+ic5PfQHDjz2dv4VMJnHyDFLnexBpnW3JmUzXdtu7tW++yUt2bBznv3svev7r5/mXCVuZgd8+jIV3fdR8Ua/lBs9f7Po6rL7n60L6dP3mDai/5+tmDgxGVRSc+NQXqBbAqJsUiWDlt+5GVf67+ETUI1GjTCmYCnXUI7VyFRJD77QTqoXTGeusroe7bI85+yB6xwCqXuRyHKqtwfKv/pP2NkB6p6EqSJw6CyWdARS6PtZ8dQnV1WLxP9yJpV/8jKU2xnEmg0t/+IuttuZaY9bNaeDwZk4W0/ODn+PSQ48yytGO2j//96jfvqngcpxEVPUWYWRWoNt5sSrFF6subpnVeRsrjg5rbMgYOj63dIZVjZUHXS9681fV3ITqVcupdmjH2ZExQNVvUJYuzq5T6/tvRtPOa5jM6J4XqR6x96HbYGPFs8JGnn4eXV/7D6MkurzZN78Vbbe/u+ByWGK5JkVkKs5RDyD3DNoZAOQmp9B51+cBRkMmXjlsmf30T6lZ6kb81fPOjo6h887PMbcMc+94D+q2XcnIw1oOq/1ke6SQTLH5GhAPoaz5Wo0F9LIuSRLmfuhWDD/xDNEmLc1U5ymoeUsV3XoJErLj45o1iyFtt9+Chtdsts3O5PXS/6fO96Dzri9AtX2PtlZOzfo1WPalf+TmQbeNVw7N0MKL88swN9B6JZwqT6cVOeeqOMxZ3jwDoKkBDz9m2xqberOZlsyDZRnRGTWVwuDDpGqRrw+AphuuM24G6+pgLYfVBv04NzmFqc7TTCK6YK7l3NoOa770oKnbdqX2VJv4/gQASPdfMr4Lz75jAJRUGoN/+Ete9bSW1PT6a13bAwBKIomOj38G2eERe10BhGc1YvV/fg1SNAKWsNrDOualocNEx5QIYzOtso5Zs7loJfyrTabuqRozMWtfYP+1273hiZFsLF0nq57P7PhcDmfv/ndkx8dtTLipATWrV1D5mse2VY26RqFYDFXNTXZGyWnf2kO0yF5/uhyin6lyWBvmU5+/G5NHjoPVb3I4jJXfuhuReW3cuguVwzCB0sKb3QthPFmTnJ4kewl3i7POkeQsxp6XSRuSdm7fY9AzoRPD068lok7kuZrNYvjxZzB5+DjUTAa5ZAqjz76ExInTzHJb37sbciwKJf9VVRIk6r+17izR1SyasdeVyI9TjpHORY/v+dF/591e7HkDwKLP3InGq7dz6+wkfqyaxWa4zxn87uyLY6rV9w7mmb6021Uk682iz3Y2fV6QYakQrPqpxIwqV1Vh1g3XYeKVw7hwz0/z5ZH7F7Ps2o1X2Eyx+q2vMm9Mu6iqikz+I6M0I0Ws6okZzy5HdN0e2fMiur7ybaO+ep66tOy6EfM+8j7B3AoT3n6jUIZ7M4hsQOgMeRseHuO2wyfnLzkaw9w73s38xvnhx59G4sSZfGrOKmU51s5CtTVofd/NzA109Yqltjpa86Nm/HAIiz79CYy+sA8T+w9Z6q6nbHnbjVj6pX+0fTeZ87oHox7GBvbceSiTUzYm3NgAOWL1DiXrGYrH0HbHLcz8q1ea7aWvY/LCRZy46wvM/QgAVK9egWV3f85m3OCpQbxySMaoPzVuREzDfhnmzcCyitCVYzWSV7iIGmVlrGqSCgnheAyLP/NJgPJalSQJ6b6B/M1gzlkqkS+MGNU6eGY1YfFn77S11X2fY58bVVUFJAlzdr8FE/sPMTfD9a/ZjFCt/W3R5ozN3kDTMvjI40wmtmSRMVnYe1BCqKYG7Z/9O+6ExSorl9Q2zOnBQcZqq6Iq/+AyVFvD5FnluImo5YnOlzaJe2Ve1Y56vPzIDrKXQZdjZWa98XXEgLT+dH3125zPCBD9nP9REgnmzJoZGMSF//o5k7E+4OIZEqyzLfmfNVhOf/7LmDx0jNkeSQ5hxTf/BbHFCxhtEi+HxbC0BzeWrLcfRshRj1UI3TCe1UDEAkWLxPhh5WlZIYiUNMPLOzs6ilze+kLXkS7HXi9iA00wVXNaUHflOks99PS5sXH0/ff93L4gmYnDx211Spw5h6Mf/Dtkh4aZTMtNb7C1U08DALmJCeQmp2wTGqvtAND70/+HgQf+YCtHz3nhnf8Djddfxe030XJEJlg6nJemEEbYmuTHMuTfmiReD3s+/JuAltzoOPa/fjdlprRK1ewWrL3335k50nXQ/zffdAPje+60uP5fP4T5H/8g8Q2l5I1r5nnu/35XK79lFtJ9lzD63EsY+uPjxiftaKbhqm2oWb/GwQKmfdng/htuRlUL/71JobparPvlPUj3DaDry99itlc/D9XXYnzvK9y8dKlZu0r4q4fdr2/pmGn/2CdbrBovb4DbGVIIhlKVTG0bSPf2Id3bRzFmusg8Uq0RW9mab3oDur7yLajZHKw7AiDZdR6TRzpQu2Et5Hhc++pW45WQZtp0bz9O/u9/purL2lmokGtqsOSfP80YBHYm3TeAdF8/I0+tnHD+5WXjB45ASaUc8lJx9l++4Vo3QPukW2ROC4af2ANIMhqv3mY4FPqRUlmTCnLUE1V7PIll4KrEsbVMqyWK1Qxi+auvo7RnliZtLdO2J4hEXG8FvU6RtjlovO4qIi+SVDH02NMAALkqjOjCeZRuz2bo//qPHI9j1be/bFiD9PY6Me7lAFDtOzevdSPDhx59EhOvHMHkkeNG+53E69jyMxZppiBHPZZJrNAbRHP3lRi/9jJ1ibUvdGTiSxcjFIsbmr6pmvB/6X1HfMkiSKEwtwyybpIk5W3u7LJG/rrH6KfWW99p2YV4qV/dxnVYf98P0bTT+hmF2ML5CNXVObTJqRw9j3keGLdyAClShdzUFLJj45A5rhqsviynWKZU1oaHtykhj3kMy2LkxtZuWIvG63ZoFhlJsv5S5evSdtvNaLhqGxAKMRm5phpLv/RZVLU0A7Lk6VeStTwic1vR/rlPaZ9BkGUi3uxCsm71r92Khqu3W+ZH/Xfi8HEkTmg+S3M/dCsWf/ZOzYWBtuaQJ5IEqSqM+LJ2zLn1HVj7s//A+gd+jOq1K239KseiWHb35/J19dZe3RJWvWYlWt9/s/FmD9KKRrfH/FWpOHN9iC9djPiydlSvXIrognncCdevQUck3I2p2Dfq5aYSVp1VkhBuqHdmkknDNwfQPslGP+BSU2lPq5ckScaXtevlKOmM4bEpSRLkWJSZZ/LMORx8xweQy78ImJQ579qFZV/7J0tYbmwcucl8u/X8JAlyNAopEka4sYHYeLP7gL4+XtsLSfN90hllKoH0wCDjc9viEp3fBjkadR07ZHt08XqtCmGMN+q5ZeQ2gOlzsYdXYmWUii0HM/rsS+j4+KeRpd/rFAph3a++j/qtG4X6VSQuYApjhF4vWcggDQRInu1G97/dg+HHnkZ2cgq6shFbMA8bfvczhJsapreCgQBAYa+XFDFpvVqF1Te5ZBLpC71IDwxCzeUQndeG2OKFxr7ET38GjKnNeOFYjOebgawsq+JuYfSxUREPDEs1E6lnuRiybU4M3VcBY1fTWdfDz1gRYZjPGVTVbuWhK8dqpNOGmSWSJBm/IozIZotOUykMjwsYPsObdFk8feP5YSrSUY/H6DcOT1hx08XQK4TIUh4w7BuBFe8kfpmCN9DlsgSw4slzkeNyMX4MDgHj3O/lYILvZwgkkLxU6EvEAgmELyL7NT9M5TnqCZbppexyM4EULl770k/f00zFOeq5iRdb8kxgAmHLdPRlxTnqOTF0+WQYr/7TxTj1o1O+AeM8/liMaLgbw1STaFutm2VI9Fy08jxGdMWabka0nbybKmDYz3VEJutCGJlVAdZsR98QTncfXSmRML9MOWeOYjD0BWE9lAoY7w/zeGV5YQJHvUACyUvgqFci8dM3AeOfAQp31PNsWi1UxWGpYF4ZN3a6Gd45K2+n/F7NDN3nbvo+T8X3wgSOemVieFzA8JlyO+r9fxf0X8Hf1ExBAAAAAElFTkSuQmCC';
                break;
            case 77:
                rfc = 'NUT840801733';
                logo = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gKgSUNDX1BST0ZJTEUAAQEAAAKQbGNtcwQwAABtbnRyUkdCIFhZWiAH3wADAAgAAQAsAAVhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtkZXNjAAABCAAAADhjcHJ0AAABQAAAAE53dHB0AAABkAAAABRjaGFkAAABpAAAACxyWFlaAAAB0AAAABRiWFlaAAAB5AAAABRnWFlaAAAB+AAAABRyVFJDAAACDAAAACBnVFJDAAACLAAAACBiVFJDAAACTAAAACBjaHJtAAACbAAAACRtbHVjAAAAAAAAAAEAAAAMZW5VUwAAABwAAAAcAHMAUgBHAEIAIABiAHUAaQBsAHQALQBpAG4AAG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAMgAAABwATgBvACAAYwBvAHAAeQByAGkAZwBoAHQALAAgAHUAcwBlACAAZgByAGUAZQBsAHkAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1zZjMyAAAAAAABDEoAAAXj///zKgAAB5sAAP2H///7ov///aMAAAPYAADAlFhZWiAAAAAAAABvlAAAOO4AAAOQWFlaIAAAAAAAACSdAAAPgwAAtr5YWVogAAAAAAAAYqUAALeQAAAY3nBhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbcGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW2Nocm0AAAAAAAMAAAAAo9cAAFR7AABMzQAAmZoAACZmAAAPXP/bAEMACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0Mv/bAEMBCQkJDAsMGA0NGDIhHCEyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAZABkAMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABQYBAwQHAv/EAEYQAAICAQIDBQMIBwYGAQUAAAABAgMEBREGEiETMUFRYSJxsRQjMoGRocHRFTVCUmJz8CQlMzRy4RZDU2OCklR0g5Oy8f/EABoBAQADAQEBAAAAAAAAAAAAAAABAgUDBAb/xAA1EQACAgIABAMGAwkAAwAAAAAAAQIDBBESITFBBRNRFDJhcYGxIqHwIyQzNXKRwdHhFSU0/9oADAMBAAIRAxEAPwCzgA+LPuAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYAMgwSeJoGo5kVKFDhB/tWPlLwrlY9QWznZbCtbm9EaCw/8HZ6W/b4+/l1/I4snh3U8ZOTo7SK8a3v9x2liXxW3FnGObRJ6UkRYDUotxaaa791swefR6U9gAAkAAgAAEjYAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABjfrszJ0YFCydSxqpd0rEn7i0Y8UlEpOXDFt9i1cPaHXRRHMyYJ3S9qKkukF5+8+tQ4qxsacqsaDvmns5b7RX5nRxNlTw9IlGt8rtar3XgvH7iheBsZOR7KlTV19TFxcf2tu67n6FjfGObv/l8fby6/md2JxfRZJRyqZVb9OaD5l+ZTweKHiGRF7cj3T8Nx5LXDo9AzdLwNaoVsXFya9m6t9f9/rKXqOm5GmZDqvj7L6wmu6SPrTNVv0u7nre9b+lW+6X5Muso4ev6Wv2oS7n4wl+Z7Gq82O48p/c8SlbgS1LnD7Hnm4N+dhXYGXPHuXtR7nt0a8GfenaddqeTGmlbeMpPuivMyvKm58GuZsO6Ch5m+RoqptyLVVTXKycu6MVuyfw+EcixKWVbGlfuxXMywY+JgaFhObcYJfTsl3yf9eBA5/Ft1knDCrVcP35rdv6vA0li0Y6TyHt+hkvLyMltY60vUkocIafFLey+T8+ZL4Gu7g/ElH5nIthLw5tpIrNmr6hY95Ztz90tvgbaOINSx5R2ypWL92zqmR7Thvk4cizxc5LasM6loeXpq7SyCnV/1IdV9a8CMTPQNJ1ijWaJVzgo2pe3W+qa9PQquv6YtNztq01RYuaHp5o55WLCMfNqe4nXEzJyn5Ny1IigAZxpgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA34F6xtQx733QsTfuNBgtGXC1Jdik4qUXF9y/cRYk8/SX2UeacGrIpeJQZew9pJprwfQuvDGbmXYqouom6Yr2Ln0W3kTVmDiXS5rMaqUu/eUFubluKsxK2L0zApy3ht1SW1s8w3HMvrPUFgYaXTFpXurR8W6Xg2raeJS9/4Eji/CZdpfkd//ADEe8PzPMu7vJTQ9WlpuZFyb+Tze1i8vUsGdwljWxcsOTqn4Rb3i/wAipZmHfg3ypvrcJr7H6o8k6LsWSl6HsryKMyDh69i66/pa1PAVtKUr61vW1+0vI3afiUaHpTlZJRcVzXTfizm4WzXk6Y6JvedD5ev7r7iO4tz3KyGDB+yvbn6+S/E1p2VQh7UlzaMeFdsp+yN8k/yIfVdVu1XJc5txqi/Yr8l+ZwbdNh0B8/OyVknKXVn0ldca4qMVpIAH1XVbc9qq5zflGLZCTb5EtpLbOzRrp0axjSg3u5qL28U+hZeMIRem1TffG3p9aZz8P8PXU3wzMyPI49YVvv382auLs6NlteFW9+zfPP0fgjWhGVOHJWct9DGsnG7Ng6+eupWQF0BkG2AAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANyQO/oWXh7QFkQjmZcfm31rrf7Xq/T0IjSMD9I6lVQ/8Pfmm/4V/X3noVjjjY0ptJQri308Ekafh+NGe7Z9EZHieXKGqodWR2q63jaQo1uDnc47xhHpsvV+BCY2s6xrOYqMacKYvq3GP0V5tsgcvJnmZVmRY93ZJv6vAuvDWnrE0yNrXzl/tv3eCO9d1mVdwxeoo4W0VYlClJbm/UkXOGBh8+RdKShH2rJvdsqWXxZl2ZHNi8tVUekYyjzN+8zxXqLyM35FB/NVfS2ffL/YjtG056nnxqe6qiuab9PIrk5Vk7VTSy2Lh1wpd962W3QdSztSrdmRjwhV4WJ7cz9x16rpdWp4zrsSU19CfjFnV83jUdFGFcF7kkirW8XTWfN10xnipbRXdJ+u57rJwqrUL5b2Z9cLLrHOiOtEJXfn6Hm3Vwkq7F7MotbpmpLK1LMbUZ3X2Pd7L+thqObLUc2zJnFRclslvvski7aLTh4GkV2wnBc8FKdja6v3mRRT583BS/AuZtX3+zwU3Hc3yIXD4OusSnlXxr374wXM19fcS1PCum1fTjZa/wCOf4I3T4k0qE+X5SpesYto3xuwNYx5QhbG6t96jLZr8TUqx8VcoJNmRbk5T5zbSNaw9Hw11qxa/wDVt+J82a9pWKuVZFba/ZrW/wACra3oM9NfbVb2Y8n3vvj7/wAyGXezyXZ06ZcCgkz204Fd8eN2N7LPqPFkrIOvBrcN/wDmT7/qRWnKU5OUm3JvdtvvZjYGbdkWXPc2alGNXQtQQABwPQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADBkwAW3g3HTjkZLXXdQX2bv8AAm9cm69Ey5L/AKbX29CP4YnXRoLtlNKKnKUn5dTsw9VwdYjbTB8y22cJrbmXn7j6XHUY48a982j5XJcpZErNckzz2qDsshDxlJR+/Y9ShGNNMYrpGEdvqSKbqWgy07UKcjHTnjO2Lfi4dV9xb793i2beMH8Dj4fTKnjU1zO/iN8b+BwfI8zvtd+TZdLvsm5fay38H40Y6dbkbLmsntv6IpaL9wvt+gqtv3pfE8fhv4r238T3eKPhx0l6o5OLs104kMWuTUrt3Lb91f7lM3LDxhv+lal4ditvtZXzl4hNzyGn2O3h1ahjxa78y7cP6ZRTpMbr6oSncuaXOt9o+C+wpl9kJXWqpyVPO3CO/RLfoX63rwy+z/8Ai9Nv9J57v3I7Z6VcIQijz+HN2TsnJ9x0a7jZRdbjXRtqscJx7pI+DGxmrk9o1XFSWmeh6dl163pO9kVvJOFkfX+upQsqh4mXbjy765OJaeDOZ4+W/wBjnW3v26/gQvEW36dydvNb/YjUy35mNC2XUyMKPlZU6o9OpFgAyTZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABhmQSD6jbZGqVaskoS6uKl0fvRmi63GujbVNxnF7qS8D4BPE9p76FXGLTWupe9G16nUYKm/lhk7fRfdL3fkTT2cGvBrY8qTcWmns13NeBYtM4qtoSqzk7a10Vi+kl6+ZtYviSf4bf7mFl+GST46enp/ogciiePfOqcZRkm1s1s2XHg+9T02ynxrsb29H1O+Nml61SlvTev3ZfSX4n1p+kYum32WY3PHnW0oOW6LY2I6rfMg04splZqup8ucWpIguMqH2mLkbdGnW395VU+nQ9N1DT6dSx+wubUd1LeL2aaOTH0fS9N+d7OtOP/Mte7X2lcnAlbc5p6TLYviMaaVBrbR8cPysu0SFd9UouKcFzLbmj/XQqmtaRZpuTJqLePJtwn4L0ZYdR4rxsdOGJFX2fvd0V+Z0YOv4Go1Ku6UK7JLZ12dz9z8S9saLoqlz5ruUqlkUSd6h+F9ihm3Hx7su5VUQdk34Lw9/oX16DpFr5/klXXr7LaXxMzyNK0atpdjSv3YdZP6u880fDWuc5LR65eKqS1XBtjAxatE0jayS9lOdkvN/10KDlZEsrKtvl9KyTkyR1rXbNUl2dadeMn0i++XqyJ38Djm5EZ6rr91HbBxp17ss96QABnmkAAAAAAAAAAYG+z2J0RsyAASAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANgAAm0902n5rvO2rV9RpSVebcl5OW/xOIF4zlD3XopKuEveWyRlr2qSW3y2xe7ZHFdkXZD3uunY/OUtzWCZWzl70m/qRGmuPOMUvoY2/pmfrAOZ0PpTklspSS8kz5fUAnbI0kAAQSAASAACAAAAAASGdWJTU4W5F6cqqtkop7c8n3Lfw9fcSvZWu2vHjZgc9kFONEqNk01ulvt37epG40XkadfjQW9sZq6MV3ySTTS8/Pb3kj+lqP0lTFulUuiNcr0vbg+TZvfv7+h7qeBQXFyMvI43N6563/wjMqmqVFeXRFxrnLklW3vyTXh7mupyHddF42lVUWdLbLe15fFR22Tfv6nCeW5ake2h7iAAcjuAAAAAAAAADD27mZMepKIfQtup8P136XVk4dajbGtOUF+2tviVLquj7z1DC/yOP8Ay4/Aq3Euidm55+NH2X/iwS7v4kbGbhbgrYfUw8DOam6rH8mVkGE+ncNzHRuEvw9p+PqWbbVkKTiquZcstuu6McQYGPp2fCnHUlHs03u9+u7OnhDpq1i86n8UfHFcubW5LyrijQcI+xKWuezN45+3cG+Wjbw9o2JqeNfPIU+aNmycZbdNtzRxFpmNpt9EMdSXNBuXNLfxJbgt/wBmyl/GvgcPGLf6SoX/AGd/vZ1nXWsJT1z/AOnGFljz3DfL/hXgAZJsmPQt2pcPafi6VflVxs5o180d5vYqPqX/AFyW3DFz864r4GjhQhKFnEt6Rl59k4WVqL1t/wCin6RgV6lqEceyc4pxb3gvL3lifBuM+7Mt/wDVFUxcu/Cu7XHscJ7Nb7bnTLWtTlvvnXfaUx7caENWw2zpkU5U57qnpFgfBlX/AMyz/wBEFwZTv/nbP/RHzwnl5OVk5Mb8iyzaCa5pb+Jt4sysjGjiqi6dbk5b8r237j3qGK6PP4DPdmWsjyOPmY/4Nxl35d31RRA65plWlZldNVk5qcOZuW3Tq14e41x1nUod2dd9poys3IzrIzybXZKK2TaPDfdjSr1XDTNCinKjYnZPaLHp3DOFm6ZRfOy5Sshu+WS2Nr4Y0qqfLZmWJrwdkV+BKcPvfQcTz5H8WU3XnvrmXv4T2+5HttjTTTGfAnvX2PBTK+++dfmNa39yxLhXTLovsr7ffGakRGqcM34NTuon21Uer6bSS/Eh8fJuxbo20WOEl3bP4no+n5Kz9NpyGl85HqvuK0Rx8pOKjplsieThyUnPiTPM9x5pnZq2OsXVMmmHSMZ+z7u/8TjZkSjwycTZjJTgpLui7R4S0+W0+e7ZpdFIpt8FVkWwjvyxm0t/Rnp9D3xqmvGC+B5he+bItfnOT+80/Eaq4Ri4rWzK8MtssnPje9GcfHty7400x5pyeyRbaOHdN07G7bUZxsa73N7RXuRo4OxYuORlNbyTVcfRbbs4+LMmdmqfJ232dUU1Hw3fiVqrhTj+fNbb6FrrbL8nyIPhS6ktRLhvLsVFddHM+i3i1v8AWcOucPY+Lizy8afZxj1dcnuvqKz/AFuTGdrbzdFoxZc3axfzkmujS7vwI9pqtrkrIpPsS8S6q2Lqk2u+yHABmGsNtyw6jw/DD0KvJipfKI7St3ffv6fYcOgYfy3V6oyW9dfzkvq7vv2L9dTHIx7KZr2ZxcX9Zq4WIrapSkuvJGPn5jqtjGL6c2eXA2ZFMsbJsomvark4s1mY009M14tSW0ZjKUJqUZOMk9009mjrWq5W+/zXP+/2Ueb377HGCYzlHkmUnVCb3JGZznZY5zk5Sb3cm92zABVtt7ZdLS0gACCQAAAAAAAAAY8DJh+RK6kMvmoZ1un6DiZFW3MuzTT8Vt1RIYWXRqOFG6vaUJLZxfh5pkNxD04Yxl/L+BXtH1azS8vfdyom9rIL4r1N6eX5V6jL3WkfOV4fnUOcfeTZv4g0V6dk9tUn8msfT+F+RDeJ6fKOPqOF3Kym2P2nn+q6XZpeU65byql1rn5r8zx52J5b8yv3We/w/N8xeVZ7yO/hL9cy/lv8DTxO99fu9IxX3G3hN/3y/wCVI5+JH/f+R6bfAq//AIl8yyX7+/6SZ4L/AMLLX8Ufgzh4vf8AetXpSviyQ4Mj/Z8uX8cV9xH8X/raH8pfFnez+Xo89X8xl+uxAAAyH1NsF5197cMP1UF8CjF34ie3DUF5utGjhP8AZW/Iys/ndV8/9FHMmPAyZxqFl4N/z2T/AC18Tbxn34f/AJ/gaeDf8/k/y18Tdxn9LD/8/wADYj/L3+u5iS/mS/XYqoAMY3D0HhvroON6J/FlN1z9eZn8x/BFx4b/AFBj+5/Ej87hWWZnW5HyxQVkubbs99vvN7IpndjVqC30+x89jX10ZVkpvXX7lP8AHY9G0bHliaNjVW+zJQ3fpv1I7G0LTdIksnKvU5R+jK1pJP0Rwa1xLG6uWLgt8r6Sta23XkvzOePXHDTstfP0OmTZLOarqX4fUhNWyI5WrZN0OsJT9l+i6fgcbCXiH3GRKTlPifdmzCHBBRXZHqGG98Gh/wDbi/uPMZveyT82z03C/V+P/Kj8DzKf05e81vFPdh+vQyPCPfs/XqW/g22LxMmnf2o2KX1Nf7HxxPo919qzceDm1HlnFLd9PErumajZpeZG+v2k1tOL/aRf9P1LG1KrnpsTlt1g++PvRfFlXkUeTN80csuNuNkefFcmeadd2jP1HomoaHg6hvKyrlsf/Mh0f+5TtX0S/S5czfaUN7KxLb6mjxZGBZSuJc0aGN4jVc+F8mRj7gDZi48srKqx49ZWSUTxRXE9Lue6UlFNvsW3huiGBo92oXLbnTl/4ruN/DOpyzqciu2W9kbHNf6Wzn4nyI4Ok0YFb259lt/DH+kQOg5qwtXpm3tCb7OfXwZs+cse2FS6Lr9TCVDyKbLn1fT6HbxdhOjUIZMV7N0ev+pf0iAPQOIsL5bpFqS3sq+cj9Xf9x594nk8Rq8u5tdGe7wy7zKVF9UZABnmiAAAAAAAAAAAAAAADDMhdWvUlEPoXTiVNcOUrxUofApXeXnipbaD7rIFH8jQ8SWrkvgjN8Le6X82TnD2tPAu+T3y/s030f7j8/cW3PwadTwnTZs01vGS8H5o818C18M611jgZE/SqT//AFO2BlJ/sbenY4eIYjT8+rqupo0DDtweI50XLaUa5dfCS80cHEf6+yfq+BfZUVTuhc4rtIJpS8dmUPiX9fZH/j8C+ZQqcfhXqVwb3fk8T68JN8GNfJMpePaJ/cR/GK21Wp+dS+LN/BuQlfk0N9ZRUkvd3/FG3jHFk4Y+Sluo7wk/LfqhJcfh+l2IjLg8Rbl3/wBFTABim6F1aLtxR7OgQj/HBfYVXScWWZquPUk9uZSl6JdSwcYZS5MbFXfzOxr07kaWMuDGsm+/Iysp8eVVBduZUvAyY26AzjULLwav7dk/y18Tdxn9LD/8/wADVwb/AJzKf/bXxN3Ga6Yb/wBf4GzFf+vf67mJL+ZL9diqAAxTcPQeG/1Bje5/EiKtang8R5WPkTbx7Ldlu9+R9NtvQl+HFtoOL7n8WU3XF/feav8AufgjdyLZVUVyj8PsfPY1Ubsi2Evj9y76tp1eqYMqntzr2q5eTPO7a50Wzqti4zg2pJ+DLfwtrDyKvkN8t7a1vCT/AGo+X1GOKNH7ap51EfnIL5yK/aXn9RXKqWTUr6+pfEtliXPHt6fr7lOHgPeGYq6m72PT8P8AV+P/ACo/A8yn9OXvPT8Tpg0L/tx+B5jYtrZLybNjxT3Ifr0MXwj37P16nzsZjOyqanXOUJLucXszZHEvsxJ5Ma26oNRlLyZp8DJacdM2NxltdSyaVxTdXONOc+etvbtP2o+/zLXk0V5uHOqaTrsjseYPrsu/0PSdNk69ExpWvbalNt+W35Gz4fkSsUoWc9IwvEseFTjOvltnnE48lkoPbeLaf1Fj4Rwe1ybcycfZqXLH/U/9iuWy7S6c1+1Jy+1l5qitC4ZcmtrI18z/ANb/AN2eTBrTtlY/djzPbn2tUxrXvS5H3laroU7pRyZUzsg3H2q99tvDuNC1Dhvffkx1/wDZ/wBik7tt7vd+fmC0vEptt8KKx8LglriZ6fj5NObjq2manXLomjzzVMP5Dqd9G20VLePufVE/wdmf42HJ93zkF8fwM8YYO8Kc2K6x+bn7vA9OT+84qtXVfpnkxP3XLdT6P9IqYMGV3GIfQAAEAAAAAAAAAAAAAGzHi5ZNUV4zivvNZmE5VzjOHSUWmn5NFotJ7fQrJNppF64oW+g2ek4v7yh+87snWM/ModN17lXLvTS8DhPVmXxvmpRXY8eDjzorcJvuZCfK092mvFAM8mz26L1w9rP6Qx+wukvlNa6/xrzK3xJ+vb/dH4Ebj5NuLkQvplyzg90z7zs2zOypZNqipyS3Ue491uX5tCrl1Rn04Xk5Dsj7rR9admz0/OqyYdeV9Y+a8UX+NmJrOBKKaspsW0l4r/c83ZuxsvIxLO0x7Z1y84vv95GLl+QnCS3Fk5mF57U4vUkTeXwll12P5LOFsPBSfK0c9fC+pzltKuuC83NfgfVfFepwW0nVZ6uH5MW8V6lZHaPZQ9Yw/M6t4L/Fz+RyivEEuHl8ydw8LD4awp332KVsl1m+9+iRUNQzbNQzbMmfTmfSPkvBGrIysjLtc8i2dkvOT7vyNXczhkZKsiq4LUUd8XEdcnZY9yZkAHkPcWfgxb3Zcv4Yr72buM1/Z8WS/ekvuIDTdWv0p2dhGD7TbfmXdsfWo6zk6pXCF8YJQe65VsaSya/ZPJ7mU8W15nndv+EeADMNU9D0Bcug4a/g/FlO4gW2u5frJP7kbMXiTPxcavHr7JQrWy3huyPy8qzNyp5FvLzz7+XuNLKyq7KI1x6rX2MrExLKsiVkuj39z4punj3wuqlyzg04v1PRtNz69TwY3QS69Jx8n4o822O3T9VytLlN47W0/pKS3XvKYWX5EmpdGdM/D9ojuPvI6+INIen5Ttqj/ZrH7P8AC/IhvFEtlcQ52bjToujS4SX7mxEnHIdbs3X0Z3xlaquG3qj1OhcuPVH+FL7jzHIXLlWrynJfeTK4sz0klCnZdO5kHZN2TnZLbeTbex6c7JrujFQ7Hk8PxbaJSc+5c+GaaLdDnVJxn2kpdpHfu9Ps2InO4VzKLW8WKuqfct9pL02IbHyr8O1WY9sq5+cWS8OLdRhHaSom/Nx2+DJWRj2VKFqaa9CHjZNVrnS00/U2adwtlW3xlmRVVSe7i3u5ehJcSavDHxXgUSTtmtpbfsR8iDyeI9SyYuPbKqL/AOnHZ/aRG733k25Pru/ErLKqqrcMdde7LRxLbbFZkNcuiRK8PYPy3V601vXV85Lf07l9pM8Y5XLRj4sX9J88vcu77yA03V8jS+17CFb7TbdyRqz8+3Usjt7uVS2UUo92yKwvrhiuuPvMvPHssy1ZL3V0OVdxkA8JonZpGX8i1ai7faKltL3Poz0DPxo52Bbjy/bjsn6+D+08ya8Scr4rz4VRrSqaitt3F7s0sLLhVCULOjMnPw7LZxsq6ohZQlXZKE1tKLaa8mjBtysmWXlTvnGMZWPdqPduajOkkm+HoakN8K4uoABUsAAAAAAAAAAAAADHe0Ab3i2RxIZW3zcpuCfk0aC3YWNTfw5j4Nj5bsmM7a2/3k9ypTjKucq5R2lFtNeTR6cijylFrozyY2R5rlF9U/yMNdNkb8rFniZDps2U0k2vetzu0DEhfnO+7ZY+NHtZt93TuXx+w3cUKL1Ou+P0bqYzQVH7B2v1/Ie0fvCqXp+ZCg3YuLdm5MceiHNOX2L3krPStIxX2WTqcncukuyjvGL9SsKZTXEunxOlmRCD4X1+HMhDr0zDhqGfHHstVUWn7T8fQ36hozxaFlY98cnFf7cP2fecunYvy/PpxnNwU5bcyXd0JVUoWqMo/n1Ku2M6nOEvr6fQ+cyiONmXUxsVkYS2Ul4mnoz7yKVRk20p78k3Hfu32ZJYmixniLLzcmOLjv6PN9KXuIVUrJtRRMro11qUn/0ijBOw0bTs3evA1FSuS3ULY7cxDX02UXTqtg4WQezTIsolWk30JqyIWPS6/E19DPRk1VoKng4+ZZlRrx7IuVkpL6Hkl5tkdnVYdVyjh3ythy7uUltsyZ0ShHikRDJhObhE5h7iXxdFgsWOVqOTHFpl9FNbykvPY+npGBlqS03P7S9LdVWrZy9xZYtjW1/bZR5lSetvl31yIYHfqemPTlj80pN3V87jJbcr8jg8DlOEoS4ZdT0V2RsjxR6Abn3TDtrq699ueSjv73sTVvD9OLdY83MVWPF7Qly+1Y/HZFq6J2LcTnbkV1Phl1IHZjZ7EzfotFmFLK0zJeRGD2nW4+0vsMrSMHF5a9Rz+zva3dda35PeX9ls3/nfI5+2Va339NcyF6ok9O0urNwMm+eVGuVS3UX49N9/wPjU9KeA6ra7Vdj2reFkfE+cHTVl4Wbkdo4vHipcu30t9/s7hCuUbOGUd8n3E7Yzq44S1zXb49DhXcZAPOeseIO7P09YuLjZNdjspvjunttyvyOWimeTk10QW8rJKKLyrlGXCznG2Moca6GuEVOcY7pJtLd9yO/VtOp0+2uNWQrlOO780atSxa8HNnjV29rybKUttuvibNV079HZFdXac/PWp77bbHTg4YSTjzX5HHj4pwalyfb1OEx18jv03SrdSlNqUaqa1vO2fcv9zsenaJJ9nHVZ8/cpuHs7kQx5zjxdiZ5VcJcL5v4LZw06f22mZGb2m3YSUeXl3339dzi8SyfILtP4c1Gq3Zp2RlGcXvGS6dUV2EJWTUIRcpSeyS8WXvq4OFa56K493Hxy3tJ8jHpsYJz9C4OFCK1LP7O2S37KpczRj9BU5DhPT8yORU5qM1t7UE/FoeyWfDfpsj22rr29dPRC94N+djfI86/G5nLspcvNt39DQeeUXF6Z6oyUkpIAAqWAAAAAAAAAAAABjfoZPqmvtbqq/wB+aX2stFbeiJPS2Tus3TwZaTGvpOiiM/rf/wDDRxBRXZOnUqP8LKju9l3T26/16GOJpqeszinuoQjFenQ6eH8nHtpng5uzqg+3hzeDXV/n9potqyyVLfJ9PoZUU66YXpc+/wAma83+6tDpwV0vyvnbvReCMazvbpOk5Hf804N+7YjdRzZahqNuRLuk/ZXlHwJK7a7hDHb+lTkNfU9/zKKas44R6JcvoX4HX5cpe83z+qOjh1VVaZn5E7lTLZV9rtvyLY41p2kLp+ml/wDiZ8aLmVVdtiZTaxsqPLJ/uvwZ928NahGfzMYXVP6NkJLqiyfHTDhjxa/IrJKF0+Objv8AM7sF6Xg0ZNP6VjdVfDlcHBrr5kZw/wDr3E/1/gdNun4uk6fasyULc2xbV1wl/h+rOXh9/wB+4i/jfwZDbVlcJJLX+yYpOq2cW3tdX8jXdWrtcnXL6Mslp/8AsdXEt87dXnS9410JQhFdy6HDmzcNVvnF7SjdKSfqpEzl40OIKo5uHOCy1FRupk9m9vFFVucZwj13v5ou2q5Vzl01r5NldjJwkpwbUovdNPqic4i2ur07MaSsvo3n07+78z5x+Gsrn585142PHrOTkt9vQ5dZz687LjGhbY9Mezr9UvEqoyrpkp8t619O5bjjbfFw563t/Psd+q2OPDGlVp7KSbfrsRGnVK/UsaqfWMrEnv79yS1bZ6BpC8eWRD12Spurth9KDUl70RfJK2LfRKJOPFumSXVuX3JHiHIsyNXujNtQqfJGPgkiMjKUJKcJOMo9U14MsObhQ19LOwJRV7S7amUtnv5nNVw/fW1bqDjjY8XvKUpLd+iJtotna5x5p9GVpyKoVKEuTXJo3cS2yvjp10/pTo5n9ZA+CJ/ieVU3gSpW1bo3in5eBX13FMz+Mzpg/wACJvw/87R/Nj8USXFF0rNasg3vGuKSXl03I3D6Z2O/+7D4o7eIuuu5D93wQjv2dr4iSTyov4M7OFLOTNyer2VDl9jRA2TnbZKyUm5SfNJ+bJnhnZZWXv3fJ5EJ4/UTY/2EF8xVFe0WP5E5b7fB9Dl1cMhpeneNF/U+s/yo/iJbf8G1devyl/iY0Z7aPrCb6uuP4ndc7I/0/wCDyv8Agy/q/wAkMzABnGsTmkbajpWVpc385H52jfzXev68z50OtYlOVql0elEeStPxm/6+8jMLKnhZdWRDvhLdrzXiiY4jzKHCrExNlS/n58vi5dUe+ucXX5kuseXz9P7GZbCSs8qPuz5/L1/uQM5ytslOb3lJ7t+bJvinpn4//wBPEgic4na+XYzXX+zx/E4we6Zt/A7zWr60vRmdTk8bh3TsarpG9Oyxr9p9Pz+4gvf3+ZPYVlGr6VDTbrI1ZFT3onLua8jnXDep9pySqhGK75ua228zpdXO1xnBbWl9DlRbClShY9PbOrGyJ28H5tU22qpxUN/J7dDTwxCLz7rZx5nTRKcV6nfZXi43DGZjUWq2cJR7Sa7nLp3e4hNJz/0dnxta5q3vCa84s6yfl21OfZHKK8yq1QXV/wCjkttnfbOyxtzm95PzOzRcieLq2NKDftTUJLzT6HblaBbbLt9MlDIx59YqMusfQ36XpUdNzaL9RshGbklVTF7ycn4v0Ryhj3K5S+PU62ZNLocV6dCN1z9eZn8z8ER536499dzNn07T8EcB57/4svmz14/8KPyQABxOwAAAAAAAAAAAAMdd014GQAOu73ABO31I12MeBnd7bbsADRhrf0PuN11UdoW2RXlGTSPkEqTXQhxT5MNt7tttvxZO8O4E5ZlOe51xorcnLeXVbLbuIIx17vA6UzVc1JrejlfXKcOCL1s3Zlitzb5wfsysk0/Tc1RlKEk4tpruaYBzcm3xHRQSjwn1ZbbcuWyyye370mz42MgNt82WUUuge7a6mO4yCBoRlKEt4Np+aM2W2WdbJznt3c0tzAJ4nrSHCt7H2/WACpJjql6mXu3u29wCSNBbrubABHbQ0Y67bbvYym13NoAnY0EACCQYZkAjRjwXmZ6vv6gEp6GkY23a9DZK+6UOR22OH7rk9vsPgEqTRDin1Cb22W6XkACCdH1XZZX/AIdk4b9/LJoxKUpzcpSbl5vqzAJ4n0I4VvY6976sAEFgACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/9k=';
                break;
            case 92:
                rfc = 'OCO160809URA';
                logo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAb1BMVEX///8AAADIyMijo6O/v78mJiaUlJQJCQn19fXPz8/j4+ONjY14eHimpqYYGBgeHh7T09MTExODg4NLS0utra3Y2Nhqamqamprt7e1lZWUjIyOAgIA9PT11dXVJSUno6Og4ODgxMTG6urpdXV1VVVVJFdwnAAADbElEQVR4nO3d6XaqMBSGYcARe7DOVetQ297/NR5RCIKiCMGd0Pf51bXrsvurjYQYqOMAAAAAAAAAAAAAAAAAAAAAQAV7z5duoVaDH/foQ7qN2vQ/3bPet3Qr9QjcxG4u3Y1+3tBNWSylO9Jr8Ote6Uo3pZEagBmNGY6t2/mONiPp3nRoD3MDHq2sH46D3b18oTfpFivpbx/lC82k2yzvo0i+o4OlM7n7AzDNxuE43xTPF7JtOBYbgGlWDceiAzDNnuH4PS4V8OhnL917Ec8OwLRJX7r/R5aLKvlChg/HbtV8Rx1POkW+bw35Qr8D6SS3VRuAaRPpMDcsV/ryhQLpQFlvevO5pg1HXQMwzaDhWPkIkceUlzF43GpZhhz/nzhLelZLOtvJsr6A7kI63Em/8QmdTn0JDTkqtuN+1v46aS5Zl4grHVWZx6VPVbqY0X6or3svzXFHV/3CL84M1cFM/RUnCf249E+VLqYMgZogmXNAnG+/dqdPBTUlvHhG02hLaCwSRkhoMBJGSGgwEkZIaLA/lbD8uYUtCXfTiNqr0IsrU7V2vFaljn0JyyOhKBKSkITySGh/Qi0fYdS6V8Gf6mhR1OHu7upye5lMM8zfBjiS7k2TTW5CzZsN5ORezfEu3ZkuuZ8H9KQ70yX3zUZrwm4QURcjDONKMIlL01lUmf1o/dkvSZhspIwryTm+ektLVjF07IhTXpOw/DpNdSTUg4QncgnHQessfttLCtF1aL1ZplBPwqs+ZpnCMNtYwYRDVYuWNt+z3SWP8OpMqL4/yvYxyj7pRR9PJbx6Zk8moZ/twychCUlIwj+e8MbM28KE3iCiPixcx5WB2vm+2EeVfc68weSEepCQhCT8EwlLn1toTqj73GLstSPRQv+wnSkkj9C6hpR11Ue28N6+0cdrzvElkdB+JLQfCe1HQvu9JuHc6Z+pa0w7cSWZYG1ViVV9VvUNW4lq/lobCUlIQhKSkIQkJKEtCQvt3Lt5dZ4tCbeTiJrzj+PKRN1YaqNKOfcbfkFCVvVZ1RfR/ISZnez+LNaYhKtznvNde5df0u3UaLOs91ZkBuhp3iJvoG6d91ozwsF5/BjLORrvjGukTZ135jRCy2n4i3gID4gl7vFvjdV5TtMfeQ1l4T/NAAAAAAAAAAAAAAAAAAAAAPDAf+iFbkp4HhwDAAAAAElFTkSuQmCC';
                break;
        }

        var total = serieA + serieB + serieC + serieD + serieP;
        this.ciaSeriesTotales = { 'sA': serieA, 'sB': serieB, 'sC': serieC, 'sD': serieD, 'sP': serieP, 'total': total, 'logo': logo, 'rfc': rfc };
    }

    showDashboardByNS(serie: string) {
        this.spinnerService.show();

        this.dataService.GetDetalleCiaSerie(this.ciaSelectedTimbrados, serie).subscribe(
            (data) => {
                var data2018: any[] = [], data2019: any[] = [];
                var _labels = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];

                var colors = ['rgba(0, 115, 183, 1)', 'rgba(210, 214, 222, 1)', 'rgba(77, 128, 123, 1)'];
                var inxColor2018 = 0, inxColor2019 = 0;
                for (let d of data) {
                    for (let m of d.mesesPac) {
                        var _dataTimbrados = [];

                        for (let mesPC of m.meses)
                            _dataTimbrados.push(mesPC.timbrados);

                        if (d.anio == 2018) {
                            data2018.push(
                                {
                                    label: m.pac,
                                    backgroundColor: colors[inxColor2018],
                                    data: _dataTimbrados,
                                    datalabels: {
                                        align: 'end',
                                        anchor: 'end',
                                        color: '#222d32',
                                        font: {
                                            weight: 'bold',
                                            size: 12
                                        },
                                        formatter: Math.round
                                    }
                                }
                            );
                            inxColor2018++;
                        }
                        else {
                            data2019.push(
                                {
                                    label: m.pac,
                                    backgroundColor: colors[inxColor2019],
                                    data: _dataTimbrados,
                                    datalabels: {
                                        align: 'end',
                                        anchor: 'end',
                                        color: '#222d32',
                                        font: {
                                            weight: 'bold',
                                            size: 12
                                        },
                                        formatter: Math.round
                                    }
                                }                            
                            );
                            inxColor2019++;
                        }
                    }
                }

                if (this.chart2018 != undefined)
                    this.chart2018.destroy();
                if (this.chart2019 != undefined)
                    this.chart2019.destroy();

                this.chart2018 = new Chart('barChart2018', {
                    type: 'bar',
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        showLines: true,
                        tooltips: {
                            mode: 'label',
                            enabled: true
                        },
                        legend: {
                            display: true,
                            position: 'top',
                            fullWidth: true,
                            labels: {
                                generateLabels: (chart) => {

                                    chart.legend.afterFit = function () { this.height = this.height + 15; };

                                    var legend = chart.data.datasets.map(function (dataset: any) {
                                        return {
                                            datasetIndex: 0,
                                            fillStyle: dataset.backgroundColor,
                                            strokeStyle: dataset.borderColor,
                                            lineWidth: dataset.borderWidth,
                                            text: dataset.label
                                        }
                                    });
                                    return legend;
                                }
                            }
                        }
                    }
                });
                this.chart2019 = new Chart('barChart2019', {
                    type: 'bar',
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        showLines: true,
                        tooltips: {
                            mode: 'label',
                            enabled: true
                        },
                        legend: {
                            display: true,
                            position: 'top',
                            fullWidth: true,
                            labels: {
                                generateLabels: (chart) => {

                                    chart.legend.afterFit = function () { this.height = this.height + 15; };

                                    var legend = chart.data.datasets.map(function (dataset: any) {
                                        return {
                                            datasetIndex: 0,
                                            fillStyle: dataset.backgroundColor,
                                            strokeStyle: dataset.borderColor,
                                            lineWidth: dataset.borderWidth,
                                            text: dataset.label
                                        }
                                    });
                                    return legend;
                                }
                            }
                        }
                    }
                });

                this.interval = setInterval(() => {
                    this.chart2018.data = {
                        labels: _labels,
                        datasets: data2018
                    };

                    this.chart2019.data = {
                        labels: _labels,
                        datasets: data2019
                    };

                    this.chart2018.update();
                    this.chart2019.update();

                    clearInterval(this.interval);
                }, 300);
            },
            response => {
                this.spinnerService.hide();
                this.sharedService.catchHttpResponseError(response);
            },
            () => {
                this.spinnerService.hide();
            });
    }

    applyFilter(clearData: boolean/*filterValue: string*/) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    showDetails(data: any): void {
        var dataDetails = { tipoModal: 'timeline', data: data };
        this.dialog.open(DialogTimeLineComponent, {
            width: '80%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}