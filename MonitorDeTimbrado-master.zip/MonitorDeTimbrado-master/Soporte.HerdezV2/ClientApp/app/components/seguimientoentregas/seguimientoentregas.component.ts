﻿import { Component, ViewChild, OnInit, ViewContainerRef } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { SwalComponent } from '@toverux/ngx-sweetalert2';
import { saveAs } from 'file-saver';

import 'rxjs/add/observable/of';

import { SeguimientoEntregasService } from './seguimientoentregas.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';

import { Concentrado } from './seguimientoentregas.model';
import { debounce } from 'rxjs/operator/debounce';

@Component({
    providers: [SeguimientoEntregasService, SharedService],
    selector: 'seguimientoentregas',
    styleUrls: ['./seguimientoentregas.style.css'],
    templateUrl: './seguimientoentregas.component.html'
})

export class SeguimientoEntregasComponent implements OnInit {

    private VIEW_ID: number = 2;
    /*Variables de acción*/
    PostBusqueda: boolean = false;
    GetIntercambio: boolean = false;
    GetCSV: boolean = false;
    PostRetransmitir: boolean = false;

    interval: any;

    consultaLista: any[] = [];
    retransmision: any[] = [];
    folios: string = '';
    isTableVisble: boolean = false;
    isConcentrado: boolean = false;
    isActionButtonsVisible: boolean = false;
    isSearchCleanVisible: boolean = false;
    showCheckInTable: boolean = true;
    concentrado: Concentrado = new Concentrado();
    filterValue: string = '';

    displayedColumns = ['isChecked', 'rfc', 'serieFolio', 'estatus', 'fechaHoraTxtAS400', 'fechaHoraGeneraTxt', 'fechaEnvioCarvajal', 'fechaHoraTimbre', 'uuid', 'rfC_PAC' ];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);

    httpBusqueda: Observable<any[]>;

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;
    @ViewChild('deleteSwal') private deleteSwal: SwalComponent;

    private _busquedaService: SeguimientoEntregasService;
    private _sharedService: SharedService;

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, busquedaService: SeguimientoEntregasService, sharedService: SharedService, private spinnerService: Ng4LoadingSpinnerService, public dialog: MatDialog, private localstorageservice: LocalStorageService) {
        this.toastr.setRootViewContainerRef(vcr);
        this._busquedaService = busquedaService;
        this._sharedService = sharedService;
        this.isSearchCleanVisible = false;
    }

    ngOnInit() {
        this.showCheckInTable = true;
        this.setActions(this.localstorageservice.GetActions(this.VIEW_ID));
    }

    private setActions(_acciones: any[]): void {
        this.cleanActions();
        for (let _accion of _acciones) {
            switch (_accion.nombreAccion) {
                case "PostBusqueda": this.PostBusqueda = true; break;
                case "GetIntercambio": this.GetIntercambio = true; break;
                case "GetCSV": this.GetCSV = true; break;
                case "PostRetransmitir": this.PostRetransmitir = true; break;
            }
        }

        if (!this.GetIntercambio && !this.GetCSV && !this.PostRetransmitir)
            this.showCheckInTable = false;
    }

    private cleanActions() {
        this.PostBusqueda = false;
        this.GetIntercambio = false;
        this.GetCSV = false;
        this.PostRetransmitir = false;
        this.showCheckInTable = true;
    }

    iniciarBusqueda() {
        this.spinnerService.show();

        if (this.isConcentrado)
            this.obtenerResumenDeDocumentos();
        else {
            this.consultaLista = [];
            var menorA3 = false;
            let listaFolios = this.folios.split("\n");

            var listaFoliosClean = [];
            for (var i = 0; i < listaFolios.length; i++) {
                if (listaFolios[i])
                    listaFoliosClean.push(listaFolios[i]);
            }

            if (listaFoliosClean.length > 0) {

                for (let folio of listaFoliosClean) {
                    var arrayData = folio.split(/\s+/);

                    if (arrayData.length != 3)
                        menorA3 = true;
                    else {
                        this.consultaLista.push(
                            {
                                Cia: arrayData[0].trim(),
                                Serie: arrayData[1].trim(),
                                Folio: arrayData[2].trim()
                            });
                    }
                    
                }

                if (menorA3) {
                    this.spinnerService.hide();
                    this.folios = '';
                    this.toastr.error('Tiene que mandar la informaci&oacute;n en el formato indicado [ Cia Serie Folio ] ', 'Formato incorrecto');
                    return;
                }

                this.obtenerResumenDeDocumentos();
            }
            else {
                this.spinnerService.hide();
                this.toastr.error('Para iniciar la busqueda tiene que ingresar el o los documentos a consultar', 'Sin documentos por buscar');
            }
        }
    }

    actualizarResultadosFolios() {
        this.spinnerService.show();
        this.obtenerResumenDeDocumentos();
    }

    descargarCsv() {
        this.spinnerService.show();
        var datosTablaResumen = [];

        if (this.isConcentrado) {
            datosTablaResumen.push({
                "concentrado": "Concentrado",
                "rfc": "Rfc",
                "serie": "Serie",
                "folio": "Folio",
                "fechaHoraTxtAS400": "Fecha Alta de Txt en AS400",
                "fechaProcesaTxt": "Fecha Genera Txt en Server",
                "fechaEnvioCarvajal": "Fecha Envío PAC",
                "fechaHoraTimbre": "Fecha Timbre",
                "estatus": "Estatus",
                "detalles": "Detalles",
                "rfcPac": "Rfc Pac"
            });
        }
        else {
            datosTablaResumen.push({
                "rfc": "Rfc",
                "serie": "Serie",
                "folio": "Folio",
                "fechaHoraTxtAS400": "Fecha Alta de Txt en AS400",
                "fechaProcesaTxt": "Fecha Genera Txt en Server",
                "fechaEnvioCarvajal": "Fecha Envío PAC",
                "fechaHoraTimbre": "Fecha Timbre",
                "estatus": "Estatus",
                "detalles": "Detalles",
                "rfcPac": "Rfc Pac"
            });
        }
            
        
        for (let doc of this.selectionCheckBox.selected) {

            var detalle = doc.detalles == null ? '' : doc.detalles.replace(/\r/gm, ' ');

            if (this.isConcentrado)
                datosTablaResumen.push(
                    {
                        "concentrado": this.concentrado.almacen + this.concentrado.tipo + this.concentrado.numero,
                        "rfc": doc.rfc,
                        "serie": doc.serie,
                        "folio": doc.folio,
                        "fechaHoraTxtAS400": doc.fechaHoraTxtAS400,
                        "fechaProcesaTxt": doc.fechaHoraGeneraTxt,
                        "fechaEnvioCarvajal": doc.fechaEnvioCarvajal,
                        "fechaTimbre": doc.fechaHoraTimbre,
                        "estatus": doc.estatus,
                        "detalles": detalle,
                        "rfcPac": doc.rfC_PAC
                    }
                );
            else
                datosTablaResumen.push(
                    {
                        "rfc": doc.rfc,
                        "serie": doc.serie,
                        "folio": doc.folio,
                        "fechaHoraTxtAS400": doc.fechaHoraTxtAS400,
                        "fechaProcesaTxt": doc.fechaHoraGeneraTxt,
                        "fechaEnvioCarvajal": doc.fechaEnvioCarvajal,
                        "fechaTimbre": doc.fechaHoraTimbre,
                        "estatus": doc.estatus,
                        "detalles": doc.estatus == 'Timbrado' ? doc.uuid : detalle,
                        "rfcPac": doc.rfC_PAC
                    }
                );
        }

        if (this.selectionCheckBox.selected.length > 0) {
            new Angular2Csv(datosTablaResumen, 'Resumen');
            this.toastr.success('Se realizo la descarga del resumen de ' + this.selectionCheckBox.selected.length + ' documento(s)', 'Descarga Finalizada');
        }
        else
            this.toastr.error('No se encuentra seleccionado ningun registro para realizar la descarga de detalles', 'Sin elementos para descargar');

        this.spinnerService.hide();
    }

    descargarArchivosIntercambio() {
        this.spinnerService.show();

        this.retransmision = [];
        for (let data of this.selectionCheckBox.selected) {
            this.retransmision.push({
                rutaReproceso: data.rutaReproceso,
                cia: data.cia,
                rfcCia: data.rfc,
                rfcPac: data.rfC_PAC,
                serie: data.serie,
                folio: data.folio,
                fechaEnvio: data.fechaEnvioCarvajal,
                fechaTxt: data.fechaHoraGeneraTxt,
                estatus: data.estatus
            });
        }
        

        this._sharedService.
            DescargarArchivosIntercambio(this.retransmision).
            subscribe(
            (data) => {
                //var dataBlob = new Blob([data[0].archivo], { type: 'application/zip' });
                var fileContentResult = data[0].archivo;
                var errores = data[0].errores;


                if (fileContentResult != null) {
                    var dataBlob = this._sharedService.b64toBlob(fileContentResult.fileContents, fileContentResult.contentType);
                    saveAs(dataBlob, fileContentResult.fileDownloadName);
                }

                if (errores.length > 0) {
                    var dataDetails = { tipoModal: 'errorFolios', data: { titulo: 'Error en descarga de ' + errores.length + ' archivo(s)', foliosError: errores } };

                    this.dialog.open(DialogTimeLineComponent, {
                        width: '80%',
                        height: 'auto',
                        data: dataDetails,
                        panelClass: 'custom-dialog-container2'
                    });
                }
                else
                    this.toastr.success('Se descargo un total de ' + this.retransmision.length + ' archivo(s) de intercambio', 'Descarga completa');
            },
            response => {
                this.retransmision = [];
                this.spinnerService.hide();
                this._sharedService.catchHttpResponseError(response);
            },
            () => {
                this.retransmision = [];
                this.spinnerService.hide();
            });
    }

    obtenerResumenDeDocumentos() {
        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;

        if (this.isConcentrado) {
            if (this.concentrado.almacen != undefined && this.concentrado.tipo != undefined && this.concentrado.numero != undefined) {
                this.displayedColumns =
                    this.showCheckInTable
                    ? ['isChecked', 'concentrado', 'rfc', 'serieFolio', 'estatus', 'fechaHoraTxtAS400', 'fechaHoraGeneraTxt', 'fechaEnvioCarvajal', 'fechaHoraTimbre', 'uuid', 'rfC_PAC' ]
                    : ['concentrado', 'rfc', 'serieFolio', 'estatus', 'fechaHoraTxtAS400', 'fechaHoraGeneraTxt', 'fechaEnvioCarvajal', 'fechaHoraTimbre', 'uuid', 'rfC_PAC' ];

                this.httpBusqueda = this._busquedaService.GetEstatusFoliosByConcentrado(this.concentrado);
            }
            else {
                this.toastr.error('Todos los datos son obligatorios para realizar la busqueda de documentos', 'Error en datos de busqueda.');
                this.spinnerService.hide();
                return;
            }
        }
        else {
            this.httpBusqueda = this._busquedaService.GetEstatusFoliosByFolios(this.consultaLista);
            this.displayedColumns =
                this.showCheckInTable
                ? ['isChecked', 'rfc', 'serieFolio', 'estatus', 'fechaHoraTxtAS400', 'fechaHoraGeneraTxt', 'fechaEnvioCarvajal', 'fechaHoraTimbre', 'uuid', 'rfC_PAC' ]
                : ['rfc', 'serieFolio', 'estatus', 'fechaHoraTxtAS400', 'fechaHoraGeneraTxt', 'fechaEnvioCarvajal', 'fechaHoraTimbre', 'uuid', 'rfC_PAC'];
            debugger
        }

        this.httpBusqueda.subscribe(
            (data) => {
                if (data.length > 0) {
                    this.isTableVisble = true;
                    debugger
                    console.log(data);
                    this.interval = setInterval(() => {

                        this.dataSource = new MatTableDataSource(data);
                        this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;

                        clearInterval(this.interval);
                    }, 200);
                    this.toastr.success('La consulta regreso un todal de ' + data.length + ' registro(s)', 'Consulta finalizada');
                }
                else {
                    this.toastr.warning('No se encontraron documentos', 'Validar datos de consulta.');
                }
            },
            response => {
                this.spinnerService.hide();
                this._sharedService.catchHttpResponseError(response);
            },
            () => {
                this.spinnerService.hide();
            });
    }

    retransmitirDocumentos(observaciones: string) {
        this.retransmision = [];
        if (this.selectionCheckBox.selected.length > 0) {

            if (observaciones == '') {
                this.toastr.error('Los motivos de retransmisión son obligatorios.', 'Error');

                let element: HTMLElement = document.getElementById('btnSend') as HTMLElement;
                element.click();
            }
            else {
                this.spinnerService.show();

                for (let data of this.selectionCheckBox.selected) {
                    this.retransmision.push({
                        rutaReproceso: data.rutaReproceso,
                        cia: data.cia,
                        rfcCia: data.rfc,
                        serie: data.serie,
                        folio: data.folio,
                        fechaEnvio: data.fechaEnvioCarvajal,
                        fechaTxt: data.fechaHoraGeneraTxt,
                        estatus: data.estatus,
                        rfcPac: data.rfC_PAC
                    });
                }

                let usuario = this.localstorageservice.GetAuthorizationUser();
                this._sharedService.
                    ReprocesarDocumentos(this.retransmision, observaciones, usuario).
                    subscribe(
                        (data) => {
                            if (data.length > 0) {

                                var dataDetails = { tipoModal: 'errorFolios', data: { titulo: 'Error en reprocesamiento de ' + data.length + ' archivo(s)', foliosError: data } };

                                this.dialog.open(DialogTimeLineComponent, {
                                    width: '80%',
                                    height: 'auto',
                                    data: dataDetails,
                                    panelClass: 'custom-dialog-container2'
                                });
                            }
                            else
                                this.toastr.success('Se realizo el reprocesamiento de ' + this.retransmision.length + ' archivo(s).', 'Reprocesamiento');
                        },
                        response => {
                            this.retransmision = [];
                            this.spinnerService.hide();
                            this._sharedService.catchHttpResponseError(response);
                        },
                        () => {
                            this.retransmision = [];
                            this.spinnerService.hide();
                        });
            }
        }
        else
            this.toastr.error("No se encuentra ningun documento seleccionado para retransmitir", "Sin documentos seleccionados");
    }    

    regresar() {
        this.isTableVisble = false;
        this.isConcentrado = false;
        this.folios = '';
        this.consultaLista = []
        this.concentrado = new Concentrado();
    }

    selectedTab(type: number) {
        this.isConcentrado = type == 1 ? true : false;
    }

    showDetails(data: any): void {
        debugger

        var _historico = JSON.parse(data.historico);
        var dataDetails = { tipoModal: _historico == null ? 'mensaje' : 'mensajeSeguimiento', data: { mensaje: data.estatus == 'Timbrado' ? data.uuid : data.detalles, claseEstatus: data.claseEstatus, estatus: data.estatus, serie: data.serie, folio: data.folio, historico: _historico } };

        this.dialog.open(DialogTimeLineComponent, {
            width: '80%',
            height: 'auto',
            data: dataDetails,
            panelClass: 'custom-dialog-container2'
        });
    }

    applyFilter(clearData: boolean) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}