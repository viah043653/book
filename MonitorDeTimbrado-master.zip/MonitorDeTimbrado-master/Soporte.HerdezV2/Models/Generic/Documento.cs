﻿namespace Soporte.HerdezV2.Models.Generic
{
    public class Documento
    {
        public int Cia { get; set; }
        public string Serie { get; set; }
        public long Folio { get; set; }
    }
}