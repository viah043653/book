namespace Soporte.HerdezV2
{
    using System;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.SpaServices.Webpack;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using Microsoft.IdentityModel.Tokens;
    using System.Text;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Soporte.HerdezV2.EF;
    using Microsoft.EntityFrameworkCore;
    using Hangfire;
    using System.Collections.Generic;
    using System.Linq;
    using Soporte.HerdezV2.Models.Jobs.Cancelaciones;

    public class Startup
    {
        public static SoapEnv initSoapEnv { get; private set; }
        public static String initSoporteConnection { get; private set; }
        public static String initAdministracionFEConnection { get; private set; }
        public static String initServicioCorreosConnection { get; private set; }

        public static String initSecret { get; set; }

        public static String initConnectionStringAS400_Desarrollo { get; set; }
        public static String initConnectionStringAS400_Produccion { get; set; }

        public static String initRutaTemporal { get; private set; }
        public static String initRutaNotasCargoChedraui { get; private set; }
        public static String initRutaFolderCorreos { get; private set; }
        public static String initRutaEdicomTrabajo { get; private set; }
        public static String initRutaInsumosCFDI { get; private set; }
        public static String initTemporalInstanciaTXT { get; private set; }
        public static String initPathBitacoras { get; private set; }

        public static String initRfcGenerico { get; private set; }
        public static List<string> initSeriesFactura { get; private set; }

        public static String initUsuarioDominio { get; set; }
        public static String initUsuarioNombre { get; set; }
        public static String initUsuarioPassword { get; set; }

        /*SFTP*/
        public static String initPathExeSftp { get; set; }
        public static String initNombreExeSftp { get; set; }
        public static String initResponsePathSftp { get; set; }

        /*Carvajal*/
        public static String initUsuarioSftpCarvajal { get; set; }
        public static String initPasswordSftpCarvajal { get; set; }
        public static String initHostSftpCarvajal { get; set; }
        public static String initSshHostKeyFingerprintSftpCarvajal { get; set; }

        public static String initExeAddendaPlanaCS { get; set; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            initServicioCorreosConnection = Configuration.GetSection("ConnectionStrings:ServicioCorreosDB").Value;
            initSoporteConnection = Configuration.GetSection("ConnectionStrings:SoporteFacturacion").Value;
            initAdministracionFEConnection = Configuration.GetSection("ConnectionStrings:AdministracionFE").Value;
            initConnectionStringAS400_Desarrollo = Configuration.GetSection("ConnectionStrings:AS400_Desarrollo").Value;
            initConnectionStringAS400_Produccion = Configuration.GetSection("ConnectionStrings:AS400_Produccion").Value;

            initRutaTemporal = Configuration.GetSection("Paths:DirectorioTemporal").Value;
            initRutaNotasCargoChedraui = Configuration.GetSection("Paths:CarpetaNotasCargoChedraui").Value;
            
            initRutaFolderCorreos = Configuration.GetSection("Paths:FolderCorreos").Value;
            initRutaEdicomTrabajo = Configuration.GetSection("Paths:EdicomTrabajo").Value;

            initRutaInsumosCFDI = Configuration.GetSection("Paths:InsumosCfdi33").Value;
            initTemporalInstanciaTXT = Configuration.GetSection("Paths:TemporalInstanciaTXT").Value;
            initPathBitacoras = Configuration.GetSection("Paths:LogAplicaciones").Value;

            initRfcGenerico = Configuration.GetSection("Configuracion:RfcGenerico").Value;
            initSeriesFactura = Configuration.GetSection("Configuracion:SeriesFactura").Value.Split(",").ToList();

            initExeAddendaPlanaCS = Configuration.GetSection("ExeAddendaPlanaCS").Value;

            initUsuarioDominio = Configuration.GetSection("UsuarioConnect:Dominio").Value;
            initUsuarioNombre = Configuration.GetSection("UsuarioConnect:Nombre").Value;
            initUsuarioPassword = Configuration.GetSection("UsuarioConnect:Password").Value;

            initSecret = Configuration.GetSection("AppSettings:Secret").Value;

            initPathExeSftp = Configuration.GetSection("SftpPaths:PathExe").Value;
            initNombreExeSftp = Configuration.GetSection("SftpPaths:ExeName").Value;
            initResponsePathSftp = Configuration.GetSection("SftpPaths:ResponsePath").Value;

            initUsuarioSftpCarvajal = Configuration.GetSection("SftpCarvajal:Usuario").Value;
            initPasswordSftpCarvajal = Configuration.GetSection("SftpCarvajal:Password").Value;
            initHostSftpCarvajal = Configuration.GetSection("SftpCarvajal:Host").Value;
            initSshHostKeyFingerprintSftpCarvajal = Configuration.GetSection("SftpCarvajal:SshHost").Value;

            bool esProduccion = Configuration.GetSection("EBIBROKERWs:Ambiente").Value == "Produccion";
            string segmento = esProduccion ? "EBIBROKERWs:Cancelaciones:Produccion" : "EBIBROKERWs:Cancelaciones:Test";
            initSoapEnv = new SoapEnv()
            {
                EsProduccion = esProduccion,               
                ClientID = Configuration.GetSection(string.Format("{0}:ClientID", segmento)).Value,
                User = Configuration.GetSection(string.Format("{0}:User", segmento)).Value,
                Password = Configuration.GetSection(string.Format("{0}:Password", segmento)).Value,
                Domain = Configuration.GetSection(string.Format("{0}:Domain", segmento)).Value,
                Application = Configuration.GetSection(string.Format("{0}:Application", segmento)).Value,
                Destination = Configuration.GetSection(string.Format("{0}:Destination", segmento)).Value,
                Reference = Configuration.GetSection(string.Format("{0}:Reference", segmento)).Value,
                Duplicates = int.Parse(Configuration.GetSection(string.Format("{0}:Duplicates", segmento)).Value),
                Transformation = Configuration.GetSection(string.Format("{0}:Transformation", segmento)).Value,
                SchemaGetRespuesta = Configuration.GetSection(string.Format("{0}:Schemas:GetRespuestas", segmento)).Value,
                SchemaPostCancelacion = Configuration.GetSection(string.Format("{0}:Schemas:PostCancelacion", segmento)).Value,
                CarpetaDeTrabajo = Configuration.GetSection(string.Format("{0}:CarpetaDeTrabajo", segmento)).Value
            };
            initSoapEnv.EndPoint = Configuration.GetSection("EBIBROKERWs:EndPoint").Value;

            string
                tmrPostCancelacion = Configuration.GetSection("EBIBROKERWs:Cancelaciones:Timers:PostCancelacion").Value,
                tmrGetRespuestaCancelacion = Configuration.GetSection("EBIBROKERWs:Cancelaciones:Timers:GetRespuestas").Value;

            initSoapEnv.SetTimeSpan(tmrPostCancelacion, tmrGetRespuestaCancelacion);

            services.AddMvc();

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader());
            });

            var key = Encoding.ASCII.GetBytes(initSecret);
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    RequireSignedTokens = true,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    RequireExpirationTime = false,
                    ValidateLifetime = true
                };
            });

            services.AddDbContext<AppDbContext>(options => options.UseSqlServer(initSoporteConnection));
            services.AddHangfire(x => x.UseSqlServerStorage(initSoporteConnection));
            services.AddHangfireServer();

            // configure DI for application services
            services.AddScoped<Validates.Self.IValidateUser, Validates.Self.ValidateUsers>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        //public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IBackgroundJobClient backgroundJobClient)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseWebpackDevMiddleware(new WebpackDevMiddlewareOptions
                {
                    HotModuleReplacement = true
                });
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            /*Inicia Segmento HF*/

            app.UseHangfireDashboard();

            app.UseHangfireServer(new BackgroundJobServerOptions
            { 
                Queues = new string[] { "default", "instanciatxt_queue_tran", "cancelaciones_queue_tran" }
            });

            GlobalJobFilters.Filters.Add(new AutomaticRetryAttribute { Attempts = 0 });

            /*Finaliza Segmento HF*/


            app.UseCors(x => x
                .AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials());
            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");

                routes.MapSpaFallbackRoute(
                    name: "spa-fallback",
                    defaults: new { controller = "Home", action = "Index" });
            });
        }
    }
}