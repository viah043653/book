﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class LoginService {

    private baseUrl: string = '';

    constructor(private httpClient: HttpClient) {
        this.baseUrl = '/api/';
    }

    public login(usuario: string, password: string) {
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        //return this.httpClient.post<any[]>(`${this.baseUrl}authentication?Usuario=${usuario}&Password=${password}`, { headers: headers });
        return this.httpClient.post<any[]>(`${this.baseUrl}authentication`, { Salt: usuario, Hash: password }, { headers: headers });
    }

    public changePassword(usuario: string, oldPassword: string, newPassword: string) {
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any>(`${this.baseUrl}changePassword?Usuario=${usuario}&OldPassword=${oldPassword}&NewPassword=${newPassword}`, { headers: headers });
    }
}