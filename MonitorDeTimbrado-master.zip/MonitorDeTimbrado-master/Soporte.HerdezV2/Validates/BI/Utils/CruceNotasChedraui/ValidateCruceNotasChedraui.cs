﻿namespace Soporte.HerdezV2.Validates.BI.Utils.CruceNotasChedraui
{
    using Dapper;
    using NPOI.HSSF.Util;
    using NPOI.SS.UserModel;
    using NPOI.SS.Util;
    using NPOI.XSSF.UserModel;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;

    public class ValidateCruceNotasChedraui : Connect
    {
        IWorkbook workbook = new XSSFWorkbook();
        ISheet sheet1;

        public dynamic Get()
        {
            string nombreArchivoResult = "", pathArchivoResult = "";
            
            DirectoryInfo dInfo = new DirectoryInfo(PathNotasDeCargoChedraui);
            FileInfo archivoNCBase = dInfo.GetFiles("*.csv").OrderByDescending(a => a.LastWriteTime).FirstOrDefault();

            if (archivoNCBase != null)
            {
                nombreArchivoResult = string.Format("{0}_{1}.xlsx", archivoNCBase.Name.Split('.')[0], DateTime.Now.ToString("hhmmss"));
                pathArchivoResult = Path.Combine(PathNotasDeCargoChedraui, "Tmp", nombreArchivoResult);

                if (!Directory.Exists(Path.GetDirectoryName(pathArchivoResult)))
                    Directory.CreateDirectory(Path.GetDirectoryName(pathArchivoResult));
                
                List<ReporteNota> reporteNotasDeCredito = ReporteNota.GetReporteNotaList(archivoNCBase.FullName).OrderBy(f => f.FolioFactura).ToList();
                List<ReporteBase> documentosBusqueda = ReporteBase.GetReporteBase(reporteNotasDeCredito);

                Busqueda oBusqueda = new Busqueda();
                oBusqueda.Documento = documentosBusqueda;

                List<dynamic> facturasRelacionadasNc = new List<dynamic>();
                var prms = new DynamicParameters();
                prms.Add("@xml", oBusqueda.GetXml<Busqueda>(oBusqueda), DbType.Xml);
                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                    facturasRelacionadasNc = db.Query<dynamic>("sp_ObtieneRelacionFacturaNotaCredito", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

                List<Factura> facturasGrpAS400 = Factura.GetFacturaRelacionada(facturasRelacionadasNc);

                List<ReporteEntrega> reporteEntregas = new List<ReporteEntrega>();
                foreach (var facGrp in reporteNotasDeCredito.GroupBy(r => r.FolioFactura))
                {
                    decimal toleranciaMas = 0, toleranciaMenos = 0;

                    var folioFactura = facGrp.FirstOrDefault().FolioFactura;
                    var facturaAS400 = facturasGrpAS400.Where(a => a.Numero == folioFactura).FirstOrDefault();

                    facturaAS400.Notas = facturaAS400.Notas.GroupBy(f => new { f.Serie, f.Numero }).Select(f => f.FirstOrDefault()).ToList();
                    
                    var documentosSerieC = facturaAS400.Notas.Where(n => n.Serie == "C").ToList();
                    facturaAS400.Notas.Where(n => n.Serie != "C").Select(n =>
                    {
                        toleranciaMas = n.Importe + 10;
                        toleranciaMenos = n.Importe - 10;

                        var docSerieC = documentosSerieC.Where(d => d.Importe <= toleranciaMas && d.Importe >= toleranciaMenos).FirstOrDefault();
                        if (docSerieC != null)
                        {
                            n.NotaCancela = docSerieC.Numero.ToString();
                            n.NotaCancelaImporte = docSerieC.Importe;
                            facturaAS400.Notas.Remove(docSerieC);
                        }

                        return n;
                    }).ToList();                    

                    foreach (var grp in facGrp)
                    {
                        ReporteEntrega rEntrega = new ReporteEntrega();
                        rEntrega.Factura = grp.FolioFactura;
                        rEntrega.FolioFic = grp.FolioFicNC;
                        rEntrega.TextoFinanciero = grp.TectoFinancieroNC;
                        rEntrega.TotalNC = grp.TotalNC;

                        toleranciaMas = rEntrega.TotalNC + 10;
                        toleranciaMenos = rEntrega.TotalNC - 10;

                        toleranciaMenos = toleranciaMenos < 0 ? 0 : toleranciaMenos;

                        var compTotEqual = facturaAS400.Notas.Where(n => n.Importe <= toleranciaMas && n.Importe >= toleranciaMenos && n.Serie != "C").ToList();
                        if (compTotEqual.Count > 1 || compTotEqual.Count == 0)
                        {
                            var compToFolioFic = facturaAS400.Notas.Where(n => n.FolioFic == rEntrega.FolioFic).ToList();
                            if (compToFolioFic.Count == 1)
                            {
                                rEntrega.FolioFicXml = compToFolioFic.FirstOrDefault().FolioFic;
                                rEntrega.FolioNC = compToFolioFic.FirstOrDefault().Numero;
                                rEntrega.SerieNC = compToFolioFic.FirstOrDefault().Serie;
                                rEntrega.TotalNcAS400 = compToFolioFic.FirstOrDefault().Importe;
                                rEntrega.RespuestaPAC = compToFolioFic.FirstOrDefault().RespuestaPAC;
                                rEntrega.FechaRespuesta = compTotEqual.FirstOrDefault().FechaRespuestaPAC;

                                facturaAS400.Notas.Remove(compToFolioFic.FirstOrDefault());
                            }
                        }
                        else
                        {
                            rEntrega.FolioFicXml = compTotEqual.FirstOrDefault().FolioFic;
                            rEntrega.FolioNC = compTotEqual.FirstOrDefault().Numero;
                            rEntrega.SerieNC = compTotEqual.FirstOrDefault().Serie;
                            rEntrega.TotalNcAS400 = compTotEqual.FirstOrDefault().Importe;
                            rEntrega.RespuestaPAC = compTotEqual.FirstOrDefault().RespuestaPAC;
                            rEntrega.FechaRespuesta = compTotEqual.FirstOrDefault().FechaRespuestaPAC;

                            rEntrega.FolioCancela = compTotEqual.FirstOrDefault().NotaCancela;
                            rEntrega.ImporteCancela = compTotEqual.FirstOrDefault().NotaCancelaImporte;

                            facturaAS400.Notas.Remove(compTotEqual.FirstOrDefault());
                        }

                        reporteEntregas.Add(rEntrega);
                    }

                    foreach (Nota f in facturaAS400.Notas)
                    {
                        ReporteEntrega rEntrega = new ReporteEntrega();
                        rEntrega.Factura = folioFactura;
                        rEntrega.FolioFic = "";
                        rEntrega.TextoFinanciero = "";
                        rEntrega.TotalNC = 0;

                        rEntrega.FolioFicXml = f.FolioFic;
                        rEntrega.FolioNC = f.Numero;
                        rEntrega.SerieNC = f.Serie;
                        rEntrega.TotalNcAS400 = f.Importe;
                        rEntrega.RespuestaPAC = f.RespuestaPAC;
                        rEntrega.FolioCancela = f.NotaCancela;
                        rEntrega.ImporteCancela = f.NotaCancelaImporte;
                        rEntrega.FechaRespuesta = f.FechaRespuestaPAC;

                        reporteEntregas.Add(rEntrega);
                    }
                }

                GetExcelFile(reporteEntregas, pathArchivoResult);
            }

            return new
            {
                Contenido = File.ReadAllBytes(pathArchivoResult),
                NombreArchivo = Path.GetFileName(pathArchivoResult)
            };
        }

        void GetExcelFile(List<ReporteEntrega> documentos, string pathExcelFile)
        {
            using (var fs = new FileStream(pathExcelFile, FileMode.Create, FileAccess.Write))
            {
                workbook = new XSSFWorkbook();
                sheet1 = workbook.CreateSheet("RelacionFolios");

                SetGrupos();
                SetColumnas();

                int rowIndex = 2;
                foreach (ReporteEntrega re in documentos)
                {
                    IRow rowDetalle = sheet1.CreateRow(rowIndex++);

                    bool esCancelado = !string.IsNullOrEmpty(re.FolioCancela);

                    rowDetalle = SetDetalle(rowDetalle, 0, re.Factura.ToString(), esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 1, re.FolioFic, esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 2, re.TextoFinanciero, esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 3, re.TotalNC == 0 ? "" : re.TotalNC.ToString(), esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 4, re.FolioFicXml, esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 5, re.FolioNC == 0 ? "" : re.FolioNC.ToString(), esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 6, re.SerieNC, esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 7, re.TotalNcAS400 == 0 ? "" : re.TotalNcAS400.ToString(), esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 8, esCancelado ? string.Format("C-{0}", re.FolioCancela) : "", esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 9, esCancelado ? re.ImporteCancela.ToString() : "", esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 10, (re.TotalNC != 0 && re.TotalNcAS400 != 0).ToString(), esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 11, (re.FolioFic == re.FolioFicXml).ToString(), esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 12, re.RespuestaPAC, esCancelado);
                    rowDetalle = SetDetalle(rowDetalle, 13, re.FechaRespuesta == null ? "" : Convert.ToDateTime(re.FechaRespuesta).ToString("dd/MM/yyyy"), esCancelado);
                }

                sheet1.AutoSizeColumn(0);
                sheet1.AutoSizeColumn(1);
                sheet1.AutoSizeColumn(2);
                sheet1.AutoSizeColumn(3);
                sheet1.AutoSizeColumn(4);
                sheet1.AutoSizeColumn(5);
                sheet1.AutoSizeColumn(6);
                sheet1.AutoSizeColumn(7);
                sheet1.AutoSizeColumn(8);
                sheet1.AutoSizeColumn(9);
                sheet1.AutoSizeColumn(10);
                sheet1.AutoSizeColumn(11);
                sheet1.AutoSizeColumn(12);

                sheet1.SetAutoFilter(new CellRangeAddress(1, documentos.Count, 0, 10));

                workbook.Write(fs);
            }
        }

        IRow SetDetalle(IRow rowDetalle, int columna, string mensaje, bool esCancelado)
        {
            var cellNC = rowDetalle.CreateCell(columna);
            cellNC.CellStyle = StyleDetalle(esCancelado);
            cellNC.SetCellValue(mensaje);

            return rowDetalle;
        }

        void SetGrupos()
        {
            sheet1.AddMergedRegion(new CellRangeAddress(0, 0, 0, 3));
            sheet1.AddMergedRegion(new CellRangeAddress(0, 0, 4, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(0, 0, 8, 13));

            IRow rowGrupos = sheet1.CreateRow(0);

            var cellNC = rowGrupos.CreateCell(0);
            cellNC.CellStyle = StyleGrp(HSSFColor.BlueGrey.Index, false);
            cellNC.SetCellValue("Reporte Notas De Cargo");

            var cellAS400 = rowGrupos.CreateCell(4);
            cellAS400.CellStyle = StyleGrp(HSSFColor.Grey50Percent.Index, false);
            cellAS400.SetCellValue("Datos AS400");

            var cellValidaciones = rowGrupos.CreateCell(8);
            cellValidaciones.CellStyle = StyleGrp(HSSFColor.SeaGreen.Index, false);
            cellValidaciones.SetCellValue("Validaciones");
        }

        void SetColumnas()
        {
            IRow rowEncabezados = sheet1.CreateRow(1);

            /*Grupo 1*/
            var cellGrp1Factura = rowEncabezados.CreateCell(0);
            cellGrp1Factura.CellStyle = StyleGrp(HSSFColor.BlueGrey.Index);
            cellGrp1Factura.SetCellValue("Factura");

            var cellGrp1Fic = rowEncabezados.CreateCell(1);
            cellGrp1Fic.CellStyle = StyleGrp(HSSFColor.BlueGrey.Index);
            cellGrp1Fic.SetCellValue("Folio Fic");

            var cellGrp1TextoFinanciero = rowEncabezados.CreateCell(2);
            cellGrp1TextoFinanciero.CellStyle = StyleGrp(HSSFColor.BlueGrey.Index);
            cellGrp1TextoFinanciero.SetCellValue("Texto Financiero");

            var cellGrp1TotalNC = rowEncabezados.CreateCell(3);
            cellGrp1TotalNC.CellStyle = StyleGrp(HSSFColor.BlueGrey.Index);
            cellGrp1TotalNC.SetCellValue("Total NC");

            /*Grupo 2*/
            var cellGrp2FolioFic = rowEncabezados.CreateCell(4);
            cellGrp2FolioFic.CellStyle = StyleGrp(HSSFColor.Grey50Percent.Index);
            cellGrp2FolioFic.SetCellValue("Folio Fic Xml");

            var cellGrp2FolioNC = rowEncabezados.CreateCell(5);
            cellGrp2FolioNC.CellStyle = StyleGrp(HSSFColor.Grey50Percent.Index);
            cellGrp2FolioNC.SetCellValue("Folio NC");

            var cellGrp2SerieNC = rowEncabezados.CreateCell(6);
            cellGrp2SerieNC.CellStyle = StyleGrp(HSSFColor.Grey50Percent.Index);
            cellGrp2SerieNC.SetCellValue("Serie NC");

            var cellGrp2TotalNC = rowEncabezados.CreateCell(7);
            cellGrp2TotalNC.CellStyle = StyleGrp(HSSFColor.Grey50Percent.Index);
            cellGrp2TotalNC.SetCellValue("Total NC AS400");

            /*Grupo 3*/
            var cellGrp3DocumentoCancela = rowEncabezados.CreateCell(8);
            cellGrp3DocumentoCancela.CellStyle = StyleGrp(HSSFColor.SeaGreen.Index);
            cellGrp3DocumentoCancela.SetCellValue("Documento Cancela");

            var cellGrp3ImporteCancela = rowEncabezados.CreateCell(9);
            cellGrp3ImporteCancela.CellStyle = StyleGrp(HSSFColor.SeaGreen.Index);
            cellGrp3ImporteCancela.SetCellValue("Importe Cancela");

            var cellGrp3ExisteNC = rowEncabezados.CreateCell(10);
            cellGrp3ExisteNC.CellStyle = StyleGrp(HSSFColor.SeaGreen.Index);
            cellGrp3ExisteNC.SetCellValue("Existe NC");

            var cellGrp3CoincidenciasFic = rowEncabezados.CreateCell(11);
            cellGrp3CoincidenciasFic.CellStyle = StyleGrp(HSSFColor.SeaGreen.Index);
            cellGrp3CoincidenciasFic.SetCellValue("Coincidencias en Folio Fic");

            var cellGrp3RespuestaNC = rowEncabezados.CreateCell(12);
            cellGrp3RespuestaNC.CellStyle = StyleGrp(HSSFColor.SeaGreen.Index);
            cellGrp3RespuestaNC.SetCellValue("Respuesta");

            var cellGrp3FechaRespuestaNC = rowEncabezados.CreateCell(13);
            cellGrp3FechaRespuestaNC.CellStyle = StyleGrp(HSSFColor.SeaGreen.Index);
            cellGrp3FechaRespuestaNC.SetCellValue("Fecha Respuesta");            
        }

        ICellStyle StyleDetalle(bool esCancelado)
        {
            IFont fontGrupos = workbook.CreateFont();
            fontGrupos.FontName = "Calibri Light";
            fontGrupos.FontHeight = 11;

            var styleGrp = workbook.CreateCellStyle();
            if (esCancelado)
            {
                styleGrp.FillForegroundColor = IndexedColors.LightOrange.Index;
                styleGrp.FillPattern = FillPattern.SolidForeground;
            }
            styleGrp.Alignment = HorizontalAlignment.Center;

            styleGrp.SetFont(fontGrupos);

            return styleGrp;
        }

        ICellStyle StyleGrp(short backGroundColor, bool showBorder = true)
        {
            IFont fontGrupos = workbook.CreateFont();
            fontGrupos.Color = IndexedColors.White.Index;
            fontGrupos.Boldweight = 700;
            fontGrupos.FontName = "Calibri Light";
            fontGrupos.FontHeight = 11;

            var styleGrp = workbook.CreateCellStyle();
            styleGrp.FillForegroundColor = backGroundColor;
            styleGrp.FillPattern = FillPattern.SolidForeground;
            styleGrp.Alignment = HorizontalAlignment.Center;

            if (showBorder)
            {
                styleGrp.BorderLeft = BorderStyle.Medium;
                styleGrp.BorderRight = BorderStyle.Medium;
                styleGrp.BorderTop = BorderStyle.Medium;
                styleGrp.BorderBottom = BorderStyle.Medium;
            }

            styleGrp.SetFont(fontGrupos);

            return styleGrp;
        }
    }
}
