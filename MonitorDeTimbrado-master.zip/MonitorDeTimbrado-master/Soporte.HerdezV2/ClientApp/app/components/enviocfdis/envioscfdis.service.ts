﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Headers } from '@angular/http';

@Injectable()
export class EnviosCfdisService {

    private baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }

    public GetEnvioSevenen(usuario: number, clientetext: string, dfolio: string, archivoexcel: any) {

        const frmData = new FormData();
               
        frmData.append('Files', archivoexcel.Archivo, archivoexcel.NombreArchivo);

        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostEnvCfdi?idUsuario=${usuario}&Clientetext=${clientetext}&Dfolio=${dfolio}`;

        return this.http.post<any>(postUrl, frmData, { headers: _headers });
    }

   
}