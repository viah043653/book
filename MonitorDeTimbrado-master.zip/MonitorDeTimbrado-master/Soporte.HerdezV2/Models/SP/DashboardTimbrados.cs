﻿namespace Soporte.HerdezV2.Models.SP
{
    public class DashboardTimbrados
    {
        public long IdCia { get; set; }
        public string RfcCia { get; set; }
        public string Nombre { get; set; }
        public string Logo { get; set; }
        public string Mes { get; set; }
        public long Total { get; set; }
        public long Timbrados { get; set; }
        public long NoTimbrados { get; set; }
        public string Anio { get; set; }
    }
}
