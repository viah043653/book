﻿import { Injectable } from "@angular/core";
import { NgIf } from '@angular/common';
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { CiaEstatus, DetalleMes, Empresa } from './dashboard.model'

import { Headers } from '@angular/http';

import { Chart, ChartData, Point } from 'chart.js';
    
import "rxjs/add/operator/map";

@Injectable()
export class DashboardService {
    public dashboardPrincipal: Array<any>;
    public dataCHE041201L59: Empresa = new Empresa;
    public dataHER8301121X4: Empresa = new Empresa;
    public dataNUT840801733: Empresa = new Empresa;
    public dataOCO160809URA: Empresa = new Empresa;
    public dataHER980609NC1: Empresa = new Empresa;
    public dataROC020422UV9: Empresa = new Empresa;

    private baseUrl: string;

    private _hubName: string;
    
    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }
    
    public UpdateData() {
        for (let empresa of this.dashboardPrincipal) {
            switch (empresa.rfcCia) {
                case 'CHE041201L59':
                    this.dataCHE041201L59 = this.SetData(empresa);
                    break;
                case 'HER8301121X4':
                    this.dataHER8301121X4 = this.SetData(empresa);
                    break;
                case 'NUT840801733':
                    this.dataNUT840801733 = this.SetData(empresa);
                    break;
                case 'OCO160809URA':
                    this.dataOCO160809URA = this.SetData(empresa);
                    break;
                case 'HER980609NC1':
                    this.dataHER980609NC1 = this.SetData(empresa);
                    break;
                case 'ROC020422UV9':
                    this.dataROC020422UV9 = this.SetData(empresa);
                    break;
            }
        }
    }

    public GetDashboard() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.get<any[]>(`${this.baseUrl}GetDashboard`, { headers: _headers });
    }

    public GetDashboardTimbrados() {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.get<any[]>(`${this.baseUrl}GetDashboardTimbrados`, { headers: _headers });
    }

    public GetDetalleCiaSerie(cia: number, serie: string) {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostCiaSerie?cia=${cia}&serie=${serie}`;

        return this.http.post<any[]>(postUrl, { headers: _headers });
    }

    public GetDetalleMes(mes: string, idCia: number) {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');
        
        let postUrl = `${this.baseUrl}PostMes?anio=2018&mes=${mes}&idCia=${idCia}`;

        return this.http.post(postUrl, { headers: _headers });
    }

    public GetDetallesEstatus(mes: string, idCia: number, idEstatus: number) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostMesEstatus?anio=2018&mes=${mes}&idCia=${idCia}&idEstatus=${idEstatus}`;

        return this.http.post<any[]>(postUrl, { headers: headers });
    }
 

    public SetDetalleMes(totales: any): DetalleMes {

        var detalleMs = new DetalleMes();
        var totalDocumentos: number = 0;

        for (let totalEstatus of totales) {
            totalDocumentos = totalDocumentos + totalEstatus.Documentos;
            switch (totalEstatus.Estatus) {
                case 1:
                    detalleMs.noEnviado = totalEstatus.Documentos;
                    break;
                case 2:
                    detalleMs.enviadoTimbrar = totalEstatus.Documentos;
                    break;
                case 3:
                    detalleMs.errorTimbrar = totalEstatus.Documentos;
                    break;
                case 4:
                    detalleMs.timbrado = totalEstatus.Documentos;
                    break;
                case 5:
                    detalleMs.noIdentificado = totalEstatus.Documentos;
                    break;
            }
        }

        detalleMs.totalMes = totalDocumentos;
        detalleMs.noEnviadoPorcentaje = this.Round(4, (detalleMs.noEnviado * 100) / totalDocumentos).toString() + '%';
        detalleMs.enviadoTimbrarPorcentaje = this.Round(4, (detalleMs.enviadoTimbrar * 100) / totalDocumentos).toString() + '%';
        detalleMs.errorTimbrarPorcentaje = this.Round(4, (detalleMs.errorTimbrar * 100) / totalDocumentos).toString() + '%';
        detalleMs.timbradoPorcentaje = this.Round(4, (detalleMs.timbrado * 100) / totalDocumentos).toString() + '%';
        detalleMs.noIdentificadoPorcentaje = this.Round(4, (detalleMs.noIdentificado * 100) / totalDocumentos).toString() + '%';

        return detalleMs;
    }

    Round(precision: number, number: number) {
        var factor = Math.pow(10, precision);
        var tempNumber = number * factor;
        var roundedTempNumber = Math.round(tempNumber);
        return roundedTempNumber / factor;
    };

    SetData(empresa: any): Empresa {
        let dataMeses: string[] = [];
        let dataTimbrados: number[] = [];
        let dataNoTimbrados: number[] = [];
        let empresaReturn: Empresa = new Empresa;

        for (let mes of empresa.meses) {
            if (mes.totalNoTimbrados > 0) {
                dataMeses.push(mes.nombre);
                dataTimbrados.push(mes.totalTimbrados);
                dataNoTimbrados.push(mes.totalNoTimbrados);
            }
        }

        if (dataMeses.length > 0)
            empresaReturn.ultimoMes = dataMeses[dataMeses.length - 1];

        var dataLabelsFormat = {
            align: 'end',
            anchor: 'end',
            color: '#222d32',
            font: {
                weight: 'bold',
                size: 12
            },
            formatter: Math.round
        };

        empresaReturn.muestraGrafico = dataMeses.length > 0 ? true : false;
        empresaReturn.idCia = empresa.idCia;
        empresaReturn.logo = empresa.logo;
        empresaReturn.nombre = empresa.nombre;
        empresaReturn.rfc = empresa.rfcCia;
        empresaReturn.dataConfig = {
            labels: dataMeses,
            datasets: [
                {
                    label: 'Timbrados',
                    backgroundColor: 'rgba(210, 214, 222, 1)',
                    data: dataTimbrados,
                    datalabels: dataLabelsFormat
                },
                {
                    label: 'Pendientes',
                    backgroundColor: 'rgba(60,141,188,0.9)',
                    data: dataNoTimbrados,
                    datalabels: dataLabelsFormat
                }
            ]
        };

        return empresaReturn;
    }
}