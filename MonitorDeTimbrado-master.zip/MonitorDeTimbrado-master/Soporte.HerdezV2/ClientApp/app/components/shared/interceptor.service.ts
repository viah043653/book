﻿import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import * as moment from 'moment'; // add this 1 of 4

import { LocalStorageService } from './localstorage.service';

@Injectable()
export class InterceptorService implements HttpInterceptor {

    authHeader: string = '';

    constructor(private localStorageService: LocalStorageService) {
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.authHeader = '';
        var tokenData = this.localStorageService.GetAuthorizationData();
        if (tokenData != null) {
            var tokenExpire = moment(new Date(tokenData._expireDate));
            var fechaActual = moment(new Date());

            var mon = moment.duration(fechaActual.diff(tokenExpire)).asSeconds();
            if (mon > 0 || isNaN(mon))
                this.localStorageService.RemoveAuthorizationData();
            else
                this.authHeader = "Bearer " + tokenData._token;
        }

        const authReq = req.clone({ setHeaders: { Authorization: this.authHeader } });

        return next.handle(authReq);
    }
}