﻿namespace Soporte.HerdezV2.Validates.BI
{
    using Microsoft.AspNetCore.Http;
    using Soporte.HerdezV2.Models.Tables.BI;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Xml;

    public class ValidateRegistraCfdi : Connect
    {
        public dynamic PostRegistro(IFormFileCollection files, int idUsuario)
        {
            List<dynamic> _resultRegistro = new List<dynamic>();
            bool _estatus = false;
            string _mensaje = string.Empty;

            try
            {
                var xmls = new List<CfdiReg>();

                foreach (var file in files)
                {
                    if (Path.GetExtension(file.FileName).ToUpper() == ".XML")
                    {
                        XmlDocument xmlDoc = new XmlDocument();

                        using (var ms = new MemoryStream())
                        {
                            file.CopyTo(ms);
                            ms.Flush();
                            ms.Position = 0;
                            xmlDoc.Load(ms);
                        }

                        xmls.Add(new CfdiReg(xmlDoc, file.FileName, this.PathEdicomTrabajo));
                    }
                }

                var cfdis = xmls.Where(x => x.EsCfdi).ToList();

                if (cfdis.Count > 0)
                {
                    foreach (CfdiReg cfdi in cfdis)
                    {
                        bool contieneAddendaPlana = false;
                        XmlNodeList nodosAdenda = cfdi.xml.GetElementsByTagName("cfdi:Addenda");
                        for (int i = 0; i < nodosAdenda.Count; i++)
                            if (nodosAdenda[i].InnerXml.Contains("lev1add:EDCINVOICE"))
                                contieneAddendaPlana = true;

                        string _mensajeCfdi = string.Empty;
                        if (cfdi.ExisteXmlUniversal)
                        {
                            if (!contieneAddendaPlana)
                            {
                                var process = new Process
                                {
                                    StartInfo = new ProcessStartInfo
                                    {
                                        FileName = this.PathExeAddendaPlanaCS,
                                        Arguments = Path.Combine(cfdi.CarpetaXmlUniversal, cfdi.NombreXmlUniversal),
                                        UseShellExecute = false,
                                        RedirectStandardOutput = true,
                                        CreateNoWindow = true
                                    }
                                };

                                process.Start();

                                string AddendaXml = string.Empty;
                                while (!process.StandardOutput.EndOfStream)
                                    AddendaXml = process.StandardOutput.ReadToEnd();

                                process.WaitForExit();

                                XmlDocumentFragment odocAdd = cfdi.xml.CreateDocumentFragment();
                                odocAdd.InnerXml = AddendaXml;

                                cfdi.xml.DocumentElement.AppendChild(odocAdd);
                                cfdi.xml.InnerXml = cfdi.xml.InnerXml.Replace("<cfdi:Addenda xmlns:cfdi=\"http://www.sat.gob.mx/cfd/3\">", "<cfdi:Addenda>");

                                cfdi.xml.Save(cfdi.PathEdicom33Timbrado);
                            }
                            else
                                _mensajeCfdi = "El documento cuenta con Addenda plana por lo tanto no se registrará el timbre";
                        }
                        else
                            _mensajeCfdi = "No se encontró el xml universal en la fecha de timbrado del documento";

                        Bitacora oBitacora = new Bitacora();
                        oBitacora.IdUsuario = idUsuario;
                        oBitacora.Cia = cfdi.cia;
                        oBitacora.Serie = cfdi.serie;
                        oBitacora.Folio = cfdi.folio;
                        oBitacora.Proceso = "RegCfdi";
                        oBitacora.NombreArchivo = cfdi.nombreArchivo;
                        oBitacora.Observaciones = "Registro de timbre de cfdi en AS400";
                        oBitacora.Error = _mensajeCfdi;
                        oBitacora.FechaAlta = DateTime.Now;

                        this._context.Bitacora.Add(oBitacora);
                        this._context.SaveChanges();

                        _resultRegistro.Add(new
                        {
                            cfdi.serie,
                            cfdi.folio,
                            cfdi.emisor,
                            estatus = string.IsNullOrEmpty(_mensajeCfdi),
                            mensaje = _mensajeCfdi
                        });
                    }

                    _estatus = true;
                }
                else
                {
                    _estatus = false;
                    _mensaje = "Favor de validar que el o los documentos cargados sean Cfdis version 3.3";
                }
            }
            catch (Exception ex)
            {
                _mensaje = ex.Message;
            }

            return new
            {
                Estatus = _estatus,
                Mensaje = _mensaje,
                Cfdis = _resultRegistro
            };
        }

        public dynamic GetRegistroCfdiHistorico()
        {
            try
            {

                var lstDocumentosRegistrados = from p in this._context.Bitacora.Where(b => b.Proceso == "RegCfdi")
                                               join m in this._context.Usuarios on p.IdUsuario equals m.IdUsuario
                                               select new
                                               {
                                                   p.NombreArchivo,
                                                   p.Cia,
                                                   Error = string.IsNullOrEmpty(p.Error) ? "Documento registrado" : p.Error,
                                                   p.FechaAlta,
                                                   p.Folio,
                                                   p.Serie,
                                                   m.NombreUsuario
                                               };

                return new
                {
                    Estatus = true,
                    Registros = lstDocumentosRegistrados
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    Estatus = false,
                    Mensaje = ex.Message
                };
            }
        }

        public class CfdiReg
        {
            public string nombreArchivo { get; set; }
            public XmlDocument xml { get; set; }
            public string serie { get; set; }
            public long folio { get; set; }
            public int cia { get; set; }
            public string emisor { get; set; }
            public string receptor { get; set; }
            public DateTime fechaTimbrado { get; set; }
            public string CarpetaXmlUniversal { get; set; }
            public string NombreXmlUniversal { get; set; }
            public string PathEdicom33Timbrado { get; set; }
            public bool EsCfdi { get; set; }
            public bool ExisteXmlUniversal { get; set; }
            
            public CfdiReg(XmlDocument xmlDoc, string nombreArchivo, string pathTrabajo)
            {
                this.EsCfdi = false;
                this.ExisteXmlUniversal = false;

                string _serie = ReadXmlData(xmlDoc, "cfdi:Comprobante", "Serie");
                string _folio = ReadXmlData(xmlDoc, "cfdi:Comprobante", "Folio");
                string _fechaTimbrado = ReadXmlData(xmlDoc, "tfd:TimbreFiscalDigital", "FechaTimbrado");
                string _emisor = ReadXmlData(xmlDoc, "cfdi:Emisor", "Rfc");
                string _receptor = ReadXmlData(xmlDoc, "cfdi:Receptor", "Rfc");

                if (!string.IsNullOrEmpty(_serie) || !string.IsNullOrEmpty(_folio) || !string.IsNullOrEmpty(_fechaTimbrado) || !string.IsNullOrEmpty(_emisor) || !string.IsNullOrEmpty(_receptor))
                {
                    this.xml = xmlDoc;
                    this.nombreArchivo = nombreArchivo;
                    this.serie = _serie;
                    this.folio = Convert.ToInt64(_folio);
                    this.fechaTimbrado = Convert.ToDateTime(_fechaTimbrado);
                    this.emisor = _emisor;
                    this.receptor = _receptor;

                    string _cia = string.Empty;
                    switch (this.emisor)
                    {
                        case "CHE041201L59":
                            _cia = "0600";
                            this.cia = 60;
                            break;
                        case "NUT840801733":
                            _cia = "0770";
                            this.cia = 77;
                            break;
                        case "HER8301121X4":
                            _cia = "010";
                            this.cia = 1;
                            break;
                        case "OCO160809URA":
                            _cia = "0920";
                            this.cia = 92;
                            break;
                        case "KSN200902B97":
                            _cia = "0950";
                            this.cia = 95;
                            break;
                        case "ROC020422UV9":
                            _cia = "1020";
                            this.cia = 102;
                            break;
                    }

                    this.CarpetaXmlUniversal = Path.Combine(pathTrabajo, this.emisor, "Procesado\\XMLUniversal", this.fechaTimbrado.Year.ToString(), this.fechaTimbrado.Month.ToString("00"), this.fechaTimbrado.Day.ToString("00"));
                    this.NombreXmlUniversal = string.Format("{0}{1}{2}.XML", _cia, _serie, _folio);
                    this.PathEdicom33Timbrado = Path.Combine(pathTrabajo, "CHE041201L59\\Timbrado", nombreArchivo);

                    this.ExisteXmlUniversal = File.Exists(Path.Combine(this.CarpetaXmlUniversal, this.NombreXmlUniversal));                 
                    this.EsCfdi = true;
                }
            }

            private string ReadXmlData(XmlDocument xml, string nodo, string atributo)
            {
                var nodos = xml.GetElementsByTagName(nodo);
                if (nodos.Count > 0)
                    if (nodos[0].Attributes[atributo] != null)
                        return nodos[0].Attributes[atributo].Value;

                return string.Empty;
            }
        }
    }
}
