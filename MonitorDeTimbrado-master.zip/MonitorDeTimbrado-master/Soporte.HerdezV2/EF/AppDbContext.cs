﻿namespace Soporte.HerdezV2.EF
{
    using Microsoft.EntityFrameworkCore;
    using Models.Tables.BI;
    using Models.Tables.Catalogos;
    using Models.Tables.Catalogos.RespuestasClientes;
    using Soporte.HerdezV2.Models.Jobs.Cancelaciones;

    public class AppDbContext : DbContext
    {
        private string _connect = string.Empty;

        public DbSet<Archivo> Archivos { get; set; }
        public DbSet<User> Usuarios { get; set; }
        public DbSet<Bitacora> Bitacora { get; set; }
        public DbSet<Pac> Pac { get; set; }
        public DbSet<PacCompania> PacCia { get; set; }
        public DbSet<CatClientesRespuestas> CatClientesRespuestas { get; set; }
        public DbSet<TipoDeDocumento> CatTiposDeDocumentos { get; set; }
        public DbSet<MotivosDeCancelacion> CatMotivosDeCancelacion { get; set; }
        public DbSet<CodigoErrorPublish> CatCodigosDeErroresPublish { get; set; }

        public AppDbContext(string connectionString) : base()
        {
            _connect = connectionString;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connect);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PacCompania>().HasKey(c => new { c.RfcCia, c.RfcPac });
        }
    }
}