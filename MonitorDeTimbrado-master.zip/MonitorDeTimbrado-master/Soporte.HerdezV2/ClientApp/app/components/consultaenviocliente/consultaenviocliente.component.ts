﻿import { Component, ViewChild, OnInit, AfterViewInit, ViewContainerRef, ElementRef } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { SwalComponent } from '@toverux/ngx-sweetalert2';
import { saveAs } from 'file-saver';

import 'rxjs/add/observable/of';

import { ConsultaEnvioClienteService } from './consultaenviocliente.service';
import { SharedService } from '../shared/shared.service';
import { LocalStorageService } from '../shared/localstorage.service';

import { DialogTimeLineComponent } from '../dialog/dialog.timeline.component';
import { DatePipe } from '@angular/common';

import * as moment from 'moment'; // add this 1 of 4

@Component({
    providers: [ConsultaEnvioClienteService, SharedService, DatePipe],
    selector: 'consultaenviocliente',
    styleUrls: ['./consultaenviocliente.style.css'],
    templateUrl: './consultaenviocliente.component.html'
})

export class ConsultaEnvioClienteComponent implements OnInit, AfterViewInit {

    //Date range picker
    //$('#reservation').daterangepicker();

    private VIEW_ID: number = 9;
    /*Variables de acción*/
    PostBusqueda: boolean = false;
    GetIntercambio: boolean = false;
    GetCSV: boolean = false;
    PostRetransmitir: boolean = false;

    LeyendaBusquedaAvanzada: string = 'Busqueda Avanzada';
    FoliosBusquedaAvanzada: string = '';
    
    isActionButtonsVisible: boolean = false;
    isSearchCleanVisible: boolean = false;
    showCheckInTable: boolean = true;
    filterValue: string = '';

    //displayedColumns = ['isChecked', 'RowIndex', 'RFC_Emisor', 'SerieFolio', 'FechaProceso', 'Mensaje', 'Contenido'];
    displayedColumns = ['isChecked', 'RowIndex', 'SerieFolio', 'FechaProceso', 'Contenido'];
    dataSource = new MatTableDataSource<any>();
    selectionCheckBox = new SelectionModel<any>(true, []);
    
    @ViewChild('busquedaAvanzadaDDL') busquedaAvanzadaDDL: ElementRef;

    @ViewChild(MatPaginator) public paginator: MatPaginator;
    @ViewChild(MatSort) public sort: MatSort;

    ShowTable: boolean = false;
    _clienteText: string = '';
    _clienteTextDescripcion: string = '';
    clientes: any[] = [];//[{ rfc: "CCO8605231N4", nombre: "Cadena Comercial OXXO" }, { rfc: "TCH850701RM1", nombre: "Tiendas Chedraui" }, { rfc: "CDE8401046V6", nombre: "Calimax" }, { rfc: "CCF121101KQ4", nombre: "City Fresko" }, { rfc: "NWM9709244W4", nombre: "Walmart" }];

    MesBusqueda_Inicial: Date = new Date();
    MesBusqueda_Final: Date = new Date();

    registrosPorPagina: number = 0;
    registrosPorMes: number = 0;
    paginas: number = 0;
    pagina: string = '1';

    private _busquedaService: ConsultaEnvioClienteService;
    private _sharedService: SharedService;

    myDateValue: Date;

    constructor(public toastr: ToastsManager, vcr: ViewContainerRef, busquedaService: ConsultaEnvioClienteService, sharedService: SharedService, private spinnerService: Ng4LoadingSpinnerService, public dialog: MatDialog, private localstorageservice: LocalStorageService, private datePipe: DatePipe) {
        this.toastr.setRootViewContainerRef(vcr);
        this._busquedaService = busquedaService;
        this._sharedService = sharedService;

        //this.MesBusqueda_Inicial = this.datePipe.transform(this.MesBusqueda_Inicial, 'yyyy-MM-dd');
        //this.MesBusqueda_Final = this.datePipe.transform(this.MesBusqueda_Final, 'yyyy-MM-dd');
        this.MesBusqueda_Inicial = new Date();
        this.MesBusqueda_Final = new Date();
    }

    ngOnInit() {
        this.myDateValue = new Date();
        this.setActions(this.localstorageservice.GetActions(this.VIEW_ID));
        this.getClientes();
    }

    ngAfterViewInit() { }

    onDateChange(newDate: Date) {
        console.log(newDate);
    }

    private setActions(_acciones: any[]): void {
        this.cleanActions();
        for (let _accion of _acciones) {
            switch (_accion.nombreAccion) {
                case "PostBusqueda": this.PostBusqueda = true; break;
                case "GetIntercambio": this.GetIntercambio = true; break;
                case "GetCSV": this.GetCSV = true; break;
                case "PostRetransmitir": this.PostRetransmitir = true; break;
            }
        }
    }

    private getClientes() {
        this.spinnerService.show();
        this._busquedaService.GetClientes().subscribe(
            (data) => {
                debugger
                this.clientes = data;
                
                this.spinnerService.hide();
            },
            response => {
                this.ShowTable = false;
                this.spinnerService.hide();
                this._sharedService.catchHttpResponseError(response);
            },
            () => {

            });
    }

    private cleanActions() {
        this.PostBusqueda = false;
        this.GetIntercambio = false;
        this.GetCSV = false;
        this.PostRetransmitir = false;
    }

    setCliente(cliente: any) {
        debugger
        this._clienteText = cliente.rfc;
        this._clienteTextDescripcion = cliente.nombre;
    }

    consultaDocumentos(indiceInicio: number) {
        debugger

        var folios: any[] = [];
        if (this.busquedaAvanzadaDDL.nativeElement.classList.contains('in')) {
            var menorA2 = false;
            let listaFolios = this.FoliosBusquedaAvanzada.split("\n");

            var listaFoliosClean = [];
            for (var i = 0; i < listaFolios.length; i++) {
                if (listaFolios[i])
                    listaFoliosClean.push(listaFolios[i]);
            }

            if (listaFoliosClean.length > 0) {

                if (listaFoliosClean.length > 500) {
                    this.toastr.error('Solo esta permitido consultar 500 documentos por petición', 'Error');
                    return false;
                }

                for (let folio of listaFoliosClean) {
                    var arrayData = folio.split(/\s+/);

                    if (arrayData.length != 2)
                        menorA2 = true;
                    else {
                        folios.push(
                            {
                                Serie: arrayData[0].trim(),
                                Numero: arrayData[1].trim()
                            });
                    }
                }

                if (menorA2) {
                    this.spinnerService.hide();
                    this.FoliosBusquedaAvanzada = '';
                    this.toastr.error('Tiene que colocar la informaci&oacute;n en el formato indicado [ Serie Folio ] ', 'Formato incorrecto');
                    return;
                }
            }
            else {
                this.toastr.error('Tiene que envíar un listado de folios', 'Error');
                return;
            }
        }

        this.dataSource = new MatTableDataSource<any>();
        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
        this.ShowTable = false;

        if (this._clienteText == '') {
            this.toastr.error('Para realizar la busqueda necesita elegir el cliente', 'Elegir Cliente');
            return;
        }

        if (this.busquedaAvanzadaDDL.nativeElement.classList.contains('in')) {
            this.busquedaAvanzada();
            this.busquedaAvanzadaDDL.nativeElement.className = "collapse";
        }

        debugger
        var inicio = moment(this.MesBusqueda_Inicial, "YYYY-MM-DD");
        var fin = moment(this.MesBusqueda_Final, "YYYY-MM-DD");
        var days = moment.duration(fin.diff(inicio)).asDays();

        if (!inicio.isValid() || !fin.isValid()) {
            this.toastr.error('Las fechas son datos requeridos', 'Error');
            return;
        }

        if (days < 0) {
            this.toastr.error('La fecha final tiene que ser mayor a la inicial', 'Error');
            return;
        }

        this.spinnerService.show();

        this._busquedaService.GetEnvios({ RfcReceptor: this._clienteText, FechaInicial: this.MesBusqueda_Inicial, FechaFinal: this.MesBusqueda_Final, IndiceInicio: indiceInicio, Folios: folios }).subscribe(
            (data) => {
                debugger

                if (Math.floor(Number(this.pagina)) != this.paginas || indiceInicio == 1) {
                    this.paginas = 0;
                    this.registrosPorMes = 0;
                    this.registrosPorPagina = data.length;
                }

                if (data.length > 0) {

                    this.ShowTable = true;
                    this.dataSource = new MatTableDataSource(data);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;

                    if (Math.floor(Number(this.pagina)) != this.paginas || indiceInicio == 1) {
                        this.registrosPorMes = data[0].TotalDoctos;
                        this.paginas = this.registrosPorMes == -666 ? 1 : Math.ceil(this.registrosPorMes / this.registrosPorPagina);
                    }
                }

                if (indiceInicio == 1)
                    this.toastr.success('Se encontraron [' + (this.registrosPorMes == -666 ? this.registrosPorPagina : this.registrosPorMes) + '] envíos con los parámetros de búsqueda ingresados', 'Busqueda De Envíos');
                else
                    this.toastr.info('Mostrando ' + data.length + ' registros en la página ' + this.pagina, 'Paginado');

                this.spinnerService.hide();
            },
            response => {
                this.ShowTable = false;
                this.spinnerService.hide();
                this._sharedService.catchHttpResponseError(response);
            },
            () => {
                
            });
    }

    descargaReporte() {
        debugger;

        this.spinnerService.show();

        let datosTablaResumen: any[] = [];
        var ids = '';

        datosTablaResumen.push({
            "RFC_Emisor": "Emisor",
            "Serie": "Serie",
            "Folio": "Folio",
            "FechaProceso": "Fecha Proceso",
            "Mensaje": "Mensaje",
            "Contenido": "Contenido"
        });

        if (this.selectionCheckBox.selected.length != this.dataSource.filteredData.length || this.registrosPorMes == -666) {
            for (let dato of this.selectionCheckBox.selected) {
                datosTablaResumen.push({
                    "RFC_Emisor": dato.RFC_Emisor,
                    "Serie": dato.SerieFolio.split('-')[0],
                    "Folio": dato.SerieFolio.split('-')[1],
                    "FechaProceso": dato.FechaProceso,
                    "Mensaje": dato.Mensaje,
                    "Contenido": dato.Contenido
                });
            }

            new Angular2Csv(datosTablaResumen, 'Resumen');

            this.spinnerService.hide();
        }
        else {
            this._busquedaService.GetDatosExcel({ RfcReceptor: this._clienteText, FechaInicial: this.MesBusqueda_Inicial, FechaFinal: this.MesBusqueda_Final, Ids: ids }).
                subscribe(
                    (d) => {
                        debugger;

                        for (let dato of d) {
                            datosTablaResumen.push({
                                "RFC_Emisor": dato.RFC_Emisor,
                                "Serie": dato.Serie,
                                "Folio": dato.Folio,
                                "FechaProceso": dato.FechaProceso,
                                "Mensaje": dato.Mensaje,
                                "Contenido": dato.Contenido
                            });
                        }

                        new Angular2Csv(datosTablaResumen, 'Resumen');
                    },
                    response => {
                        this.spinnerService.hide();
                        this._sharedService.catchHttpResponseError(response);
                    },
                    () => {
                        this.spinnerService.hide();
                    });
        }
    }

    onPageChange(e: any) {
        debugger

        if (this.registrosPorMes == -666) {
            this.pagina = '1';
            return false;
        }

        if (this.pagina != '') {
            var n = Math.floor(Number(this.pagina));
            if (n !== Infinity && String(n) === this.pagina && n >= 0) {
                if (n == 0)
                    this.pagina = '1';
                else {
                    if (Math.floor(Number(this.pagina)) > this.paginas)
                        this.pagina = this.paginas.toString();
                }
            }
            else
                this.pagina = '1';
        }

        if (e.key == 'Enter') {
            if (this.pagina == '')
                this.pagina = '1';

            this.consultaDocumentos(((Math.floor(Number(this.pagina)) * this.registrosPorPagina) - this.registrosPorPagina) + 1);
        }
    }
    
    paginado(metodo: string = '') {
        debugger

        if (this.registrosPorMes == -666)
            return false;

        if (Math.floor(Number(this.pagina)) == this.paginas && (metodo == '+1' || metodo == '+All'))
            return false;

        if (this.pagina == '1' && (metodo == '-1' || metodo == '-All'))
            return false;

        if (this.pagina == '')
            this.pagina = '1';

        switch (metodo) {
            case '-1':
                if (this.pagina != '1')
                    this.pagina = (Math.floor(Number(this.pagina)) - 1).toString();
                break;
            case '+1':
                if (Math.floor(Number(this.pagina)) != this.paginas)
                    this.pagina = (Math.floor(Number(this.pagina)) + 1).toString();
                break;
            case '-All':
                this.pagina = '1';
                break;
            case '+All':
                this.pagina = this.paginas.toString();
                break;
        }

        this.consultaDocumentos(((Math.floor(Number(this.pagina)) * this.registrosPorPagina) - this.registrosPorPagina) + 1);
    }

    busquedaAvanzada() {
        this.FoliosBusquedaAvanzada = '';
        debugger

        if (this.busquedaAvanzadaDDL.nativeElement.classList.contains('in')) {
            this.LeyendaBusquedaAvanzada = 'Busqueda Avanzada';
            if (this.dataSource.data.length > 0)
                this.ShowTable = true;
        }
        else {
            this.LeyendaBusquedaAvanzada = 'Ocultar Busqueda Avanzada';
            if (this.ShowTable && this.dataSource.data.length > 0)
                this.ShowTable = false;
        }
    }
    
    applyFilter(clearData: boolean) {
        if (clearData)
            this.filterValue = '';

        let valorFiltro = this.filterValue;

        valorFiltro = valorFiltro.trim();
        valorFiltro = valorFiltro.toLowerCase();
        this.dataSource.filter = valorFiltro;

        this.isSearchCleanVisible = valorFiltro != '' ? true : false;

        this.selectionCheckBox = new SelectionModel<any>(true, []);
        this.isActionButtonsVisible = false;
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionCheckBox.selected.length;
        const numRows = this.dataSource.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selectionCheckBox.clear() :
            this.dataSource.filteredData.forEach(row => this.selectionCheckBox.select(row));
    }

    clickCheck() {
        var clickInterval = setInterval(() => {
            this.isActionButtonsVisible = this.selectionCheckBox.selected.length > 0 ? true : false;
            clearInterval(clickInterval);
        }, 200);
    }
}