﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Soporte.HerdezV2.Controllers
{
    [Produces("application/json")]
    [Route("api/HistoricoTimbrados")]
    public class HistoricoTimbradosController : Controller
    {
        [Route("~/api/PostDocumentosHistorico")]
        [HttpPost]
        public dynamic PostDocumentosHistorico(string rfcEmisor, string rfcReceptor, string rfcPac, string serie, DateTime fechaInicial, DateTime fechaFinal)
        {
            Validates.BI.ValidateHistoricoTimbrados validateHistorico = new Validates.BI.ValidateHistoricoTimbrados();
            return validateHistorico.Get(rfcEmisor, rfcReceptor, rfcPac, serie, fechaInicial, fechaFinal);
        }
    }
}