﻿namespace Soporte.HerdezV2.Controllers
{
    using System.Collections;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI;

    [Authorize]
    [Produces("application/json")]
    [Route("api/TiposDeDocumentos")]
    public class TiposDeDocumentosController : Controller
    {
        [Route("~/api/TiposDeDocumentos")]
        [HttpGet]
        public IEnumerable Get()
        {
            ValidateTiposDeDocumentos validateTiposDeDocumentos = new ValidateTiposDeDocumentos();
            return validateTiposDeDocumentos.Get();
        }
    }
}
