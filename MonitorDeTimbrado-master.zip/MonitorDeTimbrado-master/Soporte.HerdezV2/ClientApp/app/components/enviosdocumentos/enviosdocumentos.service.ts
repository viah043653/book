﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Headers } from '@angular/http';

@Injectable()
export class EnviosDocumentosService {

    private baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }

    public GetEntrxFoli(cia: number, serie: string, folio: number) {
        let _headers = new HttpHeaders();
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostEntxFol?cia=${cia}&serie=${serie}&folio=${folio}`;

        return this.http.post<any>(postUrl, { headers: _headers });
    }

   
}