﻿namespace Soporte.HerdezV2.Controllers
{
    using System;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI;
    using Microsoft.AspNetCore.Authorization;

    [Authorize]
    [Produces("application/json")]
    [Route("api/ArchivosIntercambio")]
    public class ArchivosIntercambioController : Controller
    {
        ValidateArchivosIntercambio _validateArchivosIntercambio = new ValidateArchivosIntercambio();
        // POST api/values
        [Route("~/api/PostIntercambio")]
        [HttpPost]
        public dynamic PostByFolios()
        {
            var files = HttpContext.Request.Form.Files;
            string observaciones = HttpContext.Request.Form["Observaciones"];
            int idUsuario = Convert.ToInt16(HttpContext.Request.Form["Usuario"]);

            _validateArchivosIntercambio = new ValidateArchivosIntercambio();
            var result = this._validateArchivosIntercambio.PostFiles(files, observaciones, idUsuario);

            return result;
        }

        [Route("~/api/PostRegeneracion")]
        [HttpPost]
        public dynamic PostRegeneracion(string cia, string serie, long folio, int usuario, string observaciones)
        {
            _validateArchivosIntercambio = new ValidateArchivosIntercambio();
            var result = _validateArchivosIntercambio.PostRegeneracion(cia, serie, folio, usuario, observaciones);
            return result;
        }
    }
}