﻿using Hangfire;
using System;

namespace Soporte.HerdezV2.Models.Jobs.Cancelaciones
{
    public class SoapEnv
    {
        public string ClientID { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public string Domain { get; set; }
        public string Application { get; set; }
        public string Destination { get; set; }
        public string Reference { get; set; }
        public int Duplicates { get; set; }
        public string Transformation { get; set; }
        public string SchemaPostCancelacion { get; set; }
        public string SchemaGetRespuesta { get; set; }
        public string EndPoint { get; set; }
        public bool EsProduccion { get; set; }
        public string CarpetaDeTrabajo { get; set; }
        public string TimerPostCancelacion { get; private set; }
        public string TimerGetRespuestas { get; private set; }

        public void SetTimeSpan(string timerPost, string timerGet)
        {
            TimeSpan tmrPostCancelacion = TimeSpan.Parse(timerPost);
            TimeSpan tmrGetCancelacion = TimeSpan.Parse(timerGet);

            this.TimerPostCancelacion = tmrPostCancelacion.Hours > 0 ? Cron.HourInterval(tmrPostCancelacion.Hours) : tmrPostCancelacion.Minutes > 0 ? Cron.MinuteInterval(tmrPostCancelacion.Minutes) : Cron.MinuteInterval(1);
            this.TimerGetRespuestas = tmrGetCancelacion.Hours > 0 ? Cron.HourInterval(tmrGetCancelacion.Hours) : tmrGetCancelacion.Minutes > 0 ? Cron.MinuteInterval(tmrGetCancelacion.Minutes) : Cron.MinuteInterval(1);
        }
    }
}
