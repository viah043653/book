﻿namespace Soporte.HerdezV2.Validates.BI
{
    using Dapper;
    using Newtonsoft.Json;
    using Soporte.HerdezV2.Models.Generic;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.IO.Compression;
    using System.Net;

    public class ValidateBusquedas : Connect
    {
        ValidateShared vShared = new ValidateShared();
        List<dynamic> lstResultadosError = new List<dynamic>();

        public ValidateBusquedas()
        {
            lstResultadosError = new List<dynamic>();
        }

        public IEnumerable ConsultaEstatus(List<Documento> oConsulta, Concentrado oConcentrado)
        {
            try
            {
                List<SpBusquedadFolio> result = new List<SpBusquedadFolio>();

                string spName = string.Empty;
                var prms = new DynamicParameters();

                if (oConcentrado == null)
                {
                    Busqueda oBusqueda = new Busqueda();
                    oBusqueda.Documento = new List<BusquedaDocumento>();

                    foreach (var consulta in oConsulta)
                    {
                        var busquedaDocumento = new BusquedaDocumento();
                        busquedaDocumento.Cia = consulta.Cia;
                        busquedaDocumento.Folio = consulta.Folio;
                        busquedaDocumento.Serie = consulta.Serie;

                        oBusqueda.Documento.Add(busquedaDocumento);
                    }

                    string xml = oBusqueda.GetXml<Busqueda>(oBusqueda);
                    prms.Add("@Busqueda", xml, DbType.Xml);

                    //spName = "sp_ConsultaEstatusDocumentos";
                    spName = "sp_ConsultaEstatusDocumentos_V2";
                }
                else
                {
                    prms.Add("@Bodega", oConcentrado.Almacen, DbType.String);
                    prms.Add("@Tipo", oConcentrado.Tipo, DbType.String);
                    prms.Add("@Concentrado", oConcentrado.Numero, DbType.Int32);

                    spName = "sp_ConsultarEstatusDocumentosPorConcentrado";
                }

                using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                {
                    result = db.Query<SpBusquedadFolio>(spName, prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();
                }

                result.Select(f =>
                {
                    f.RutaReproceso = vShared.RutaReproceso(f.Cia, f.Serie, f.Folio);
                    return f;
                }).ToList();

                result.Select(f =>
                {
                    f.ClaseEstatus = f.Estatus == "Sin Txt Generado" ? "fa fa-bug bg-red" :
                                     f.Estatus == "Seguimiento" ? "fa fa-bug bg-red" :
                                     f.Estatus == "Timbrado" ? "fa fa-thumbs-o-up bg-green" : "fa fa-warning bg-yellow";
                    return f;
                }).ToList();

                return result;
            }
            catch (Exception ex)
            {
                _Mensaje.Exception = ex.ToString();
                _Mensaje.Descripcion = ex.Message;
                throw new ApplicationException(JsonConvert.SerializeObject(_Mensaje));
            }
        }

        internal IEnumerable CamEst(CamEst cambio)
        {
            throw new NotImplementedException();
        }

        public IEnumerable Reproceso(List<Reproceso> archivos, string observaciones, int usuario)
        {
            var outPaths = new List<string>();
            SearchFiles(archivos, true, ref outPaths, observaciones, usuario);

            return lstResultadosError;
        }

        public string GetZip(List<Reproceso> descargas, ref List<dynamic> outErrores)
        {
            try
            {
                string
                    nmFechaHoraSS = DateTime.Now.ToString("HHmmss"),
                    fullPathCarpeta = string.Format("{0}Intercambio{1}", this.RutaTemporal, nmFechaHoraSS),
                    fullPathZip = string.Format("{0}Intercambio{1}.zip", this.RutaTemporal, nmFechaHoraSS);

                var outPaths = new List<string>();
                SearchFiles(descargas, false, ref outPaths);

                if (!Directory.Exists(fullPathCarpeta))
                    Directory.CreateDirectory(fullPathCarpeta);

                if (outPaths.Count > 0)
                {
                    foreach (string path in outPaths)
                    {                        
                        string nombreArchivo = Path.GetFileName(path);
                        string fullPathArchivo = Path.Combine(fullPathCarpeta, nombreArchivo);

                        if (nombreArchivo.ToUpper().Contains(".GZ"))
                        {
                            FileInfo fileInfo = new FileInfo(path);
                            dynamic decFile = DecompressGzip(fileInfo);

                            fullPathArchivo = Path.Combine(fullPathCarpeta, decFile.Nombre);
                            nombreArchivo = decFile.Nombre;

                            File.WriteAllText(fullPathArchivo, decFile.Contenido);
                        }
                        else
                            File.Copy(path, fullPathArchivo, true);

                        var zipMode = File.Exists(fullPathZip) ? ZipArchiveMode.Update : ZipArchiveMode.Create;

                        using (ZipArchive archive = ZipFile.Open(fullPathZip, zipMode))
                            archive.CreateEntryFromFile(fullPathArchivo, $"{nombreArchivo}");
                    }
                }
                else
                    fullPathZip = string.Empty;

                DirectoryInfo dInfo = new DirectoryInfo(this.RutaTemporal);
                var archivos = dInfo.GetFiles("*.zip");

                foreach (var file in archivos.Where(a => a.CreationTime < DateTime.Now.AddMinutes(-3)).Select(a => a.FullName))
                    try { File.Delete(file); } catch { };

                outErrores = lstResultadosError;
                return fullPathZip;
            }
            catch (Exception ex)
            {
                File.WriteAllText(@"E:\PortalMT\asd.txt", ex.ToString());
                throw (ex);
            }
        }

        void SearchFiles(List<Reproceso> archivos, bool copyFiles, ref List<string> outFullPaths, string observaciones = "", int usuario = 0)
        {

            foreach (Reproceso archivo in archivos)
            {
                bool esError = false;
                var rutasPacs = this._pacsCompanias.Where(p => p.RfcCia == archivo.RfcCia).ToList();
                if (rutasPacs.Count > 0)
                {
                    var ruta = rutasPacs.Where(r => r.RfcPac == archivo.RfcPac).FirstOrDefault();
                    if(ruta == null)
                        ruta = rutasPacs.Where(r => r.RfcPac == "EME000602QR9").FirstOrDefault();

                    if (ruta != null)
                    {
                        FileInfo[] filesInfoData = null;
                        if (archivo.Estatus != "Con Txt Sin Envío a Timbrar")
                        {
                            filesInfoData = customSearch(archivo.RutaReproceso, ruta.RutaProcesados, Convert.ToDateTime(archivo.FechaEnvio), false);

                            if (filesInfoData == null)
                            {
                                filesInfoData = customSearch(archivo.RutaReproceso, ruta.RutaProcesados, Convert.ToDateTime(archivo.FechaTxt), false);
                                if (filesInfoData == null)
                                {
                                    esError = true;
                                    filesInfoData = customSearch(archivo.RutaReproceso, ruta.RutaErrores, Convert.ToDateTime(archivo.FechaEnvio), true);
                                }
                            }
                        }
                        else
                        {
                            esError = true;
                            filesInfoData = customSearch(archivo.RutaReproceso, ruta.RutaErrores, Convert.ToDateTime(archivo.FechaEnvio), true);
                            if (filesInfoData == null)
                            {
                                esError = false;
                                filesInfoData = customSearch(archivo.RutaReproceso, ruta.RutaProcesados, Convert.ToDateTime(archivo.FechaTxt), false);
                            }
                        }
                        
                        if (filesInfoData != null)
                        {
                            if (esError && !copyFiles)
                            {
                                foreach (var f in filesInfoData)
                                    intercambioBitacora(f.FullName, observaciones, usuario, string.Format("{0}{1}", ruta.RutaReprocesamiento, Path.GetFileName(f.FullName)), ref outFullPaths, copyFiles);
                            }
                            else if (esError && copyFiles)
                            {
                                lstResultadosError.Add(new { rfc = archivo.RfcCia, serie = archivo.Serie, folio = archivo.Folio, nombreArchivo = archivo.RutaReproceso, mensaje = "No se puedo reprocesar el archivo debido a que contiene errores", claseError = "fa fa-exclamation bg-yellow" });
                            }
                            else
                                intercambioBitacora(filesInfoData.OrderByDescending(f => f.CreationTime).FirstOrDefault().FullName, observaciones, usuario, string.Format("{0}{1}", ruta.RutaReprocesamiento, Path.GetFileName(archivo.RutaReproceso)), ref outFullPaths, copyFiles);
                        }
                        else
                            lstResultadosError.Add(new { rfc = archivo.RfcCia, serie = archivo.Serie, folio = archivo.Folio, nombreArchivo = archivo.RutaReproceso, mensaje = "No se pudo localizar el archivo", claseError = "fa fa-exclamation bg-yellow" });
                    }
                }
            }            
        }

        FileInfo[] customSearch(string nombreArchivo, string pathBase, DateTime fechaOrigen, bool esPosibleError, int dias = 0)
        {
            List<FileInfo> filesInfo = new List<FileInfo>();

            try
            {
                DateTime fechaCustom = fechaOrigen.AddDays(dias);

                string folder = string.Format("{0}\\{1}\\{2}", fechaCustom.Year, fechaCustom.Month.ToString("00"), fechaCustom.Day.ToString("00"));

                string pathBusqueda = esPosibleError ? pathBase : string.Format("{0}{1}", pathBase, folder);

                string fileName = nombreArchivo.Split('.')[0];
                filesInfo = new DirectoryInfo(pathBusqueda).GetFiles(fileName + "*.TXT*", SearchOption.AllDirectories).Where(f => f.Extension.ToUpper() == ".TXT").ToList();
            }
            catch (Exception ex)
            {
            }

            int countFiles = filesInfo.Count();
            if (countFiles > 0)
            {
                if (countFiles == 2 && esPosibleError)
                    return filesInfo.ToArray();
                else
                    return new FileInfo[1] { filesInfo.Where(f => new List<string>() { ".TXT", ".GZ" }.Contains(f.Extension.ToUpper())).OrderByDescending(f => f.CreationTime).FirstOrDefault() };
            }
            else if (countFiles == 0 && esPosibleError)
                return null;
            else
            {
                if (dias == 0 || (dias < 0 && dias > -4))
                    dias--;
                else if (dias < 4 && dias > 0)
                    dias++;
                else if (dias == -4)
                    dias = 1;

                if (dias == 4)
                    return null;
                else
                    return customSearch(nombreArchivo, pathBase, fechaOrigen, esPosibleError, dias);
            }
        }

        void intercambioBitacora(string pathOrigenOpcion, string observaciones, int usuario, string pathDestino, ref List<string> outFullPaths, bool copy)
        {
            ValidateArchivosIntercambio vIntercambio = new ValidateArchivosIntercambio();

            if (copy)
            {
                string _nombreArchivo = Path.GetFileName(pathOrigenOpcion);
                if (_nombreArchivo.ToUpper().Contains(".GZ"))
                {
                    FileInfo fileInfo = new FileInfo(pathOrigenOpcion);
                    dynamic decFile = DecompressGzip(fileInfo);
                    _nombreArchivo = Path.GetFileName(pathDestino);

                    File.WriteAllText(pathDestino, decFile.Contenido);
                }
                else
                    File.Copy(pathOrigenOpcion, pathDestino, true);

                int _cia = getCiaId(_nombreArchivo.Substring(0, 4));
                string _serie = _nombreArchivo.Substring(4, 1);
                long _folio = getFolio(_nombreArchivo);

                vIntercambio.SaveBitacora(_cia, _folio, _nombreArchivo, observaciones, _serie, usuario, "Retransmisión", false, "");
            }
            else
                outFullPaths.Add(pathOrigenOpcion);
        }

        long getFolio(string _nombreArchivo)
        {
            string _folioString = "";
            foreach (char c in _nombreArchivo.Substring(5, _nombreArchivo.IndexOf('.') - 5))
            {
                if (Char.IsLetter(c) || Char.IsSymbol(c) || Char.IsSeparator(c) || Char.IsPunctuation(c) || Char.IsWhiteSpace(c))
                    break;
                _folioString += c.ToString();
            }
            return Convert.ToInt64(_folioString);
        }

        int getCiaId(string cia)
        {
            switch (cia)
            {
                case "0920": return 92;
                case "0010": return 1;
                case "0600": return 60;
                case "0770": return 77;
                case "0950": return 95;
                default: return 0;
            }
        }

        dynamic DecompressGzip(FileInfo fileToDecompress)
        {
            string fileName = string.Empty;
            string fileContent = string.Empty;
            using (FileStream originalFileStream = fileToDecompress.OpenRead())
            {
                fileName = fileToDecompress.Name.Remove(fileToDecompress.Name.Length - fileToDecompress.Extension.Length);

                using (GZipStream decompressionStream = new GZipStream(originalFileStream, CompressionMode.Decompress))
                using (StreamReader decompressFile = new StreamReader(decompressionStream, System.Text.Encoding.UTF8))
                    fileContent = decompressFile.ReadToEnd();
            }
            return new
            {
                Nombre = fileName,
                Contenido = fileContent
            };
        }
    }
}