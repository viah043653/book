﻿namespace Soporte.HerdezV2.Validates.HangFire
{
    using Dapper;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Xml;

    public class ValidateHfLecturaXml : Connect
    {
        public void StartLecturaXml()
        {
            List<Repositorio> result = new List<Repositorio>();

            using (IDbConnection db = new SqlConnection("Data Source=HDZAWFE01;Initial Catalog=Facturacion; User Id=FactInterCompania;Password=FcTur@ci0n1n73Rcom94nia;Connection Timeout=1200; MultipleActiveResultSets=True"))
                result = db.Query<Repositorio>("BI_getPendientesRegerenciaNutrisa", null, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            foreach (var r in result)
            {
                string
                    numeroReferencia = string.Empty,
                    fullPathFile = string.Format("{0}.XML", r.rutaBase);

                XmlDocument xml = new XmlDocument();
                xml.Load(fullPathFile);

                foreach (XmlElement x in xml.GetElementsByTagName("cfdi:Addenda"))
                {
                    if (x.InnerXml.Contains("lev1add:EDCINVOICE"))
                    {
                        string segmento = x.InnerText.Split('\n').Where(s => s.Contains("H1C_Comprobante")).FirstOrDefault();

                        if (!string.IsNullOrEmpty(segmento))
                        {
                            string[] columnas = segmento.Split('|');
                            if (columnas.Length > 42)
                            {
                                int indexChar = columnas[42].IndexOf('[');
                                if (indexChar == -1)
                                    numeroReferencia = string.Empty;
                                else
                                    numeroReferencia = columnas[42].Substring(indexChar, columnas[42].Length - indexChar);
                            }
                        }
                        break;
                    }
                }

                r.numeroReferencia = numeroReferencia;
            }

            if (result.Count > 0)
                UpdateData(result);
        }

        void UpdateData(List<Repositorio> repositorios)
        {
            DataTable dt = new DataTable("MyTmpTable");
            dt = ToDataTable(repositorios);

            using (SqlConnection conn = new SqlConnection("Data Source=HDZAWFE01;Initial Catalog=Facturacion; User Id=FactInterCompania;Password=FcTur@ci0n1n73Rcom94nia;Connection Timeout=1200; MultipleActiveResultSets=True"))
            {
                using (SqlCommand command = new SqlCommand("", conn))
                {
                    try
                    {
                        conn.Open();

                        command.CommandText = "CREATE TABLE #TmpTable(cfdiId int, rutaBase nvarchar(max), numeroReferencia nvarchar(max))";
                        command.ExecuteNonQuery();

                        using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conn))
                        {
                            bulkcopy.BulkCopyTimeout = 660;
                            bulkcopy.DestinationTableName = "#TmpTable";
                            bulkcopy.WriteToServer(dt);
                            bulkcopy.Close();
                        }

                        command.CommandTimeout = 300;
                        command.CommandText = "UPDATE T SET T.numeroReferencia = Temp.numeroReferencia FROM DSCfdiRepositorio T INNER JOIN #TmpTable Temp ON T.cfdiId = Temp.cfdiId; DROP TABLE #TmpTable;";
                        command.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        DataTable ToDataTable(List<Repositorio> data)
        {
            PropertyDescriptorCollection props =
                TypeDescriptor.GetProperties(typeof(Repositorio));
            DataTable table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (Repositorio item in data)
            {
                for (int i = 0; i < values.Length; i++)
                    values[i] = props[i].GetValue(item);
                table.Rows.Add(values);
            }
            return table;
        }

        public class Repositorio
        {
            public int cfdiId { get; set; }
            public string rutaBase { get; set; }
            public string numeroReferencia { get; set; }
        }
    }
}