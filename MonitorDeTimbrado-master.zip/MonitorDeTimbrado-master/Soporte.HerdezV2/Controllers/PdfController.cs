﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using Soporte.HerdezV2.Validates.BI;
using static Soporte.HerdezV2.Validates.BI.ValidatePdf;
using System.IO;

namespace Soporte.HerdezV2.Controllers
{
    [Authorize]
    [Produces("application/json")]
    [Route("api/Pdf")]
    public class PdfController : Controller
    {
        // POST api/PostXmlToPdf
        [Route("~/api/PostXmlToPdf")]
        [HttpPost]
        public dynamic Post([FromBody]List<XmlBusquedaDocumento> documentos)
        {
            List<dynamic> outResultados = new List<dynamic>();

            ValidatePdf oPdf = new ValidatePdf();
            string rutaZip = oPdf.PostXmlToPdf(documentos, ref outResultados);

            const string contentType = "application/zip";
            HttpContext.Response.ContentType = contentType;
            HttpContext.Response.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");

            dynamic result = null;
            if (!string.IsNullOrEmpty(rutaZip))
                result = new FileContentResult(System.IO.File.ReadAllBytes(rutaZip), contentType)
                {
                    FileDownloadName = Path.GetFileName(rutaZip)
                };

            return new List<dynamic>() { new { archivo = result, respuestas = outResultados } };
        }

        // POST api/PostXmlToPdf
        [Route("~/api/PostXmlToPdfWithFile")]
        [HttpPost]
        public dynamic PostXmlToPdfWithFile()
        {
            var files = HttpContext.Request.Form.Files;

            List<dynamic> outResultados = new List<dynamic>();

            ValidatePdf oPdf = new ValidatePdf();
            string rutaZip = oPdf.PostXmlToPdfWithFile(files, ref outResultados);

            const string contentType = "application/zip";
            HttpContext.Response.ContentType = contentType;
            HttpContext.Response.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");

            dynamic result = null;
            if (!string.IsNullOrEmpty(rutaZip))
                result = new FileContentResult(System.IO.File.ReadAllBytes(rutaZip), contentType)
                {
                    FileDownloadName = Path.GetFileName(rutaZip)
                };

            return new List<dynamic>() { new { archivo = result, respuestas = outResultados } };
        }
    }
}
