﻿//import { Chart, ChartData, Point } from 'chart.js';

export class CiaEstatus {
    cia: string
    mes: string
    total: number
    timbrados: number
    noTimbrados: number
}

export class CiaDetalle {
    cia: string
    meses: Mes[]
}

export class Mes {
    nombre: string
    totalDocumentos: number
    totalTimbrados: number
    totalNoTimbrados: number
}

export class DetalleMes {
    
    noEnviado: number = 0
    noEnviadoPorcentaje: string = '0%'

    enviadoTimbrar: number = 0
    enviadoTimbrarPorcentaje: string = '0%'

    errorTimbrar: number = 0
    errorTimbrarPorcentaje: string = '0%'

    timbrado: number = 0
    timbradoPorcentaje: string = '0%'

    noIdentificado: number = 0
    noIdentificadoPorcentaje: string = '0%'

    totalMes: number = 0
}

export class Empresa {
    idCia: number = 0
    rfc: string = ''
    nombre: string = 'Cargando datos de compañia...'
    logo: string = ''
    dataConfig: any = {}
    muestraGrafico: boolean = true
    ultimoMes: string = ''
}