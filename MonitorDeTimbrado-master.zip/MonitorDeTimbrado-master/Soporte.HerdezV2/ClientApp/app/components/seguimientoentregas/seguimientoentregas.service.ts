﻿import { Injectable } from "@angular/core";
import { NgIf } from '@angular/common';
import { HttpClient, HttpHeaders } from "@angular/common/http";

import { Concentrado } from './seguimientoentregas.model';

@Injectable()
export class SeguimientoEntregasService {

    private baseUrl: string = '';

    constructor(private httpClient: HttpClient) {
        this.baseUrl = '/api/';
    }

    public GetEstatusFoliosByFolios(folios: any[]) {
        debugger
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any[]>(`${this.baseUrl}PostByFolios`, folios, { headers: headers });
    }

    public GetEstatusFoliosByConcentrado(concentrado: Concentrado) {
        var headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.httpClient.post<any[]>(`${this.baseUrl}PostByConcentrado`, concentrado, { headers: headers });
    }
}