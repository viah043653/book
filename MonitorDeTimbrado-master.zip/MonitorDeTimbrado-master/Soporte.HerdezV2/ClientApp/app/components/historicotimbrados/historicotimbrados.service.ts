﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Headers } from '@angular/http';

@Injectable()
export class HistoricoTimbradosService {

    private baseUrl: string = '';

    constructor(private http: HttpClient) {
        this.baseUrl = '/api/';
    }

    public PostBusqueda(rfcEmisor: string, rfcReceptor: string, rfcPac: string, serie: string, fechaInicial: Date, fechaFinal: Date) {
        let _headers = new HttpHeaders();
        debugger
        _headers.append('Content-Type', 'application/json; charset=utf-8');

        let postUrl = `${this.baseUrl}PostDocumentosHistorico?rfcEmisor=${rfcEmisor}&rfcReceptor=${rfcReceptor}&rfcPac=${rfcPac}&serie=${serie}&fechaInicial=${fechaInicial}&fechaFinal=${fechaFinal}`;

        return this.http.post<any>(postUrl, { headers: _headers });
    }
}