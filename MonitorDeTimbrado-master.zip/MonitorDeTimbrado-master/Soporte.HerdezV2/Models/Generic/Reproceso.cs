﻿namespace Soporte.HerdezV2.Models.Generic
{
    using System;
    using System.Collections.Generic;

    public class ReprocesoContent
    {
        public List<Reproceso> reprocesos { get; set; }
        public string observaciones { get; set; }
        public int usuario { get; set; }
    }
    
    public class Reproceso
    {
        public string RutaReproceso { get; set; }
        public int? Cia { get; set; }
        public string RfcCia { get; set; }
        public string RfcPac { get; set; }
        public string Serie { get; set; }
        public string Estatus { get; set; }
        public Int64? Folio { get; set; }
        public DateTime? FechaEnvio { get; set; }
        public DateTime? FechaTxt { get; set; }
    }
}
