﻿namespace Soporte.HerdezV2.Models.Tables.Catalogos
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("MotivosDeCancelacion", Schema = "CANCELACIONES")]
    public class MotivosDeCancelacion
    {
        [Key]
        [Required]
        public int IdMotivoDeCancelacion { get; set; }

        [Required]
        [MaxLength(100)]
        public string Descripcion { get; set; }

        [Required]
        public bool EsEstatusActivo { get; set; }
    }
}
