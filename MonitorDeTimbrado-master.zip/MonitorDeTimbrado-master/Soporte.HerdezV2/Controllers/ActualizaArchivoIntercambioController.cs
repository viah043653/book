﻿namespace Soporte.HerdezV2.Controllers
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates;

    [Authorize]
    [Produces("application/json")]
    [Route("api/ActualizaArchivoIntercambio")]
    public class ActualizaArchivoIntercambioController : Controller
    {
        // POST api/values
        [Route("~/api/PostActualizaIntercambioRfcGenerico")]
        [HttpPost]
        public dynamic PostByFolios(string cia, string serie, long folio, int usuario, string observaciones)
        {
            ValidateActualizaArchivoIntercambioRfc validateRfc = new ValidateActualizaArchivoIntercambioRfc();
            return validateRfc.PostRegeneracion(cia, serie, folio, usuario, observaciones);
        }
    }
}