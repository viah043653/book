﻿namespace Soporte.HerdezV2.Controllers
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Soporte.HerdezV2.Validates.BI;
    using System.Collections;
    using System.Collections.Generic;

    [Produces("application/json")]
    [Route("api/Refacturacion")]
    public class RefacturacionController : Controller
    {
        ValidateRefacturacion validateRefacturacion = new ValidateRefacturacion();

        [Route("~/api/PostRefacturacion")]
        [HttpPost]
        public dynamic PostRefacturacion(string cia, string serie, string folio, string observaciones, bool preparaDB, bool cancelaFolio, int idUsuario, int idMotivoDeCancelacion, bool esCancelacionMasiva)
        {
            validateRefacturacion = new ValidateRefacturacion();

            IFormFile formFile = null;
            if (esCancelacionMasiva)
                formFile = HttpContext.Request.Form.Files[0];
             
            return validateRefacturacion.PostDocumento(cia, serie, folio, observaciones, preparaDB, cancelaFolio, idUsuario, idMotivoDeCancelacion, esCancelacionMasiva, formFile);
        }

        [Route("~/api/GetHistoricoCancelaciones")]
        [HttpGet]
        public dynamic GetHistorico()
        {
            validateRefacturacion = new ValidateRefacturacion();
            return validateRefacturacion.GetHistorico();
        }

        [Route("~/api/GetMotivosDeCancelacionPorTipoDeDocumento")]
        [HttpGet]
        public IEnumerable GetMotivosDeCancelacionPorTipoDeDocumento()
        {
            validateRefacturacion = new ValidateRefacturacion();
            return validateRefacturacion.GetMotivosDeCancelacionPorTipoDeDocumento();
        }

        [Route("~/api/GetDocumentosPorSolicitud")]
        [HttpPost]
        public dynamic GetDocumentosPorSolicitud(long idSolicitud)
        {
            validateRefacturacion = new ValidateRefacturacion();
            return validateRefacturacion.GetDocumentosPorSolicitud(idSolicitud);
        }
    }
}