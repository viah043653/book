﻿namespace Soporte.HerdezV2.Validates.BI.Dashboard
{
    using System.Collections.Generic;
    using System.Linq;
    using Soporte.HerdezV2.Models.SP;
    using System.Data;
    using System.Data.SqlClient;
    using Dapper;
    using System.Collections;
    using System;

    public class ValidateSeguimiento : Connect
    {
        private string anioMes;
        ValidateShared vShared = new ValidateShared();

        public ValidateSeguimiento() { }

        public ValidateSeguimiento(string anio, string mes)
        {
            string[] anioMesSplit = mes.Split('-');

            int mesIndex = Array.FindIndex(this.NombresMeses, nombre => nombre == anioMesSplit[1].Trim()) + 1;
            anioMes = string.Format("{0}{1}", anioMesSplit[0].Trim(), mesIndex.ToString("00"));
        }

        public IEnumerable<dynamic> GetTimbradosCiaGrp()
        {
            IEnumerable<dynamic> resultado;
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                resultado = db.Query<dynamic>("sp_ObtieneTimbradosPorCia", null, commandType: CommandType.StoredProcedure, commandTimeout: 260);
            return resultado;
        }

        public IEnumerable<dynamic> GetConteoCiaSerie(int idCia, string serie)
        {
            List<dynamic> resultado = new List<dynamic>();

            var prms = new DynamicParameters();
            prms.Add("@Cia", idCia, DbType.Int32);
            prms.Add("@Serie", serie, DbType.String);
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                resultado = db.Query<dynamic>("sp_ConsultaTimbradosCiaSerie", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            var dynPacMes = resultado.GroupBy(r => r.Anio).
                Select(r =>
                {
                    var anio = r.Key;
                    var mes = new int[12] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
                    var mesesPac = r.GroupBy(p => p.Pac).Select(p =>
                    {
                        var dynMesTimbre = new List<dynamic>();
                        foreach (var ms in mes)
                        {
                            var byMs = p.Where(pc => pc.Mes == ms).FirstOrDefault();
                            if (byMs == null)
                                dynMesTimbre.Add( new { _Mes = ms, Timbrados = 0 });
                            else
                                dynMesTimbre.Add(new { _Mes = ms, Timbrados = byMs.Timbrados });
                        }

                        return new
                        {
                            Pac = p.Key,
                            Meses = dynMesTimbre.OrderBy(o => o._Mes).ToList()
                        };
                    }).ToList();

                    return new { Anio = anio, MesesPac = mesesPac };
                }).ToList();

            return dynPacMes;
        }

        public IEnumerable<DashboardPrincipal> GetDetalles()
        {
            IEnumerable<DashboardTimbrados> resultado;
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                resultado = db.Query<DashboardTimbrados>("sp_ObtenerDatosDashboardTimbrados", null, commandType: CommandType.StoredProcedure, commandTimeout: 260);

            var grpByCia = resultado.GroupBy(c => c.IdCia).Select(g => new DashboardPrincipal()
            {
                IdCia = g.Key,
                RfcCia = g.FirstOrDefault().RfcCia,
                Nombre = g.FirstOrDefault().Nombre,
                Logo = g.FirstOrDefault().Logo,
                Meses = g.Select(m => new Mes()
                {
                    Numero = int.Parse(m.Mes),
                    //Nombre = m.Anio + " - " + m.Mes.PadLeft(2, '0'),
                    Nombre = m.Anio + " - " + this.NombresMeses[int.Parse(m.Mes) - 1],
                    TotalDocumentos = m.Total,
                    TotalTimbrados = m.Timbrados,
                    TotalNoTimbrados = m.NoTimbrados
                })
            });

            return grpByCia;
        }

        public IEnumerable GetConteoPorMes(int idCia)
        {
            IEnumerable resultado;

            var prms = new DynamicParameters();
            prms.Add("@FechaConteo", anioMes, DbType.String);
            prms.Add("@IdCia", idCia, DbType.Int16);
            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                resultado = db.Query("sp_ObtenerConteoEstatusPorMes", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260);

            return resultado;
        }

        public IEnumerable GetMesEstatus(int idCia, int idEstatus)
        {
            List<Documento> resultado = new List<Documento>();

            var prms = new DynamicParameters();
            prms.Add("@Cia", idCia, DbType.Int16);
            prms.Add("@Fecha", anioMes, DbType.String);
            prms.Add("@Estatus", idEstatus, DbType.Int16);

            using (IDbConnection db = new SqlConnection(ConnectionStringSoporte))
                resultado = db.Query<Documento>("sp_ObtenerDetallesPorEstatus", prms, commandType: CommandType.StoredProcedure, commandTimeout: 260).ToList();

            var resultFormat = resultado.Select(r => new
            {
                IsSelected = false,
                r.Serie,
                r.IdArchivo,
                r.Folio,
                r.FechaAlta,
                r.DescripcionEstatus,
                Historico = HistoricoDocumento(r.DescripcionEstatus, r.FechaProceso, r.Mensaje, r.Contenido).ToList(),
                r.ClaveEstatus,
                RutaReproceso = vShared.RutaReproceso(idCia, r.Serie, r.Folio)
            });

            return resultFormat;
        }

        IEnumerable<dynamic> HistoricoDocumento(string estatus, DateTime fechaProceso, string mensaje, string contenido)
        {
            yield return new
            {

                IdHistorico = 0,
                ClaseEstatus = claseEstatus(estatus),
                Estatus = estatus,
                FechaProceso = fechaProceso,
                Mensaje = mensaje,
                Contenido = contenido
            };
        }

        string claseEstatus(string estatus)
        {
            string clase = string.Empty;
            switch (estatus)
            {
                case "No enviado":
                    clase = "fa fa-warning bg-yellow";
                    break;
                case "Enviado a timbrar":
                    clase = "fa fa-send bg-blue";
                    break;
                case "Error al timbrar":
                    clase = "fa fa-bug bg-red";
                    break;
                case "Timbrado":
                    clase = "fa fa-thumbs-o-up bg-green";
                    break;
                case "No Identificado":
                    clase = "fa fa-user bg-aqua";
                    break;
            }
            return clase;
        }
    }
}